﻿Public Class Form1
    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub btnValidate_Click(sender As Object, e As EventArgs) Handles btnValidate.Click

    End Sub
    Function IsValid(ByVal intTestvalue As Integer) As Boolean
        'invalid accepts 1 argument
        Dim intValue1 As Integer

        If Integer.TryParse(intTestvalue, intValue1) Then
            Return True
        Else
            Return False

        End If


    End Function
End Class
