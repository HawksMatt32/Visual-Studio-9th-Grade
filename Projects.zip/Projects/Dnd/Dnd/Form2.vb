﻿Public Class Form2
    Dim intCounter As Integer
    Private Sub Form2_Close()
        While 1 = 1
            MessageBox.Show("You Can't get out")

        End While
    End Sub
    Private Sub Form1_Close()
        While 1 = 1
            MessageBox.Show("You Can't get out")
        End While
    End Sub
    Private Sub Form2_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Form1.Hide()

    End Sub

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        While 1 = 1
            MessageBox.Show("You Can't get out")
            intCounter += 1
            If intCounter = 50 Then
                MessageBox.Show("Omg u got out")

                Me.Close()
                Form1.Close()
                Close()




            End If

        End While
    End Sub
End Class