﻿Public Class Form1
    Private intSeconds As Integer
    Private Sub Form1_Close()
        While 1 = 1
            MessageBox.Show("You Can't get out")
        End While
    End Sub
    Private Sub Form2_Close()
        While 1 = 1
            MessageBox.Show("You Can't get out")
        End While
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub
    Sub EpicPoggers()


    End Sub

    Private Sub epicPog_Tick(sender As Object, e As EventArgs) Handles epicPog.Tick
        intSeconds += 1
        If intSeconds = 100 Then
            Form2.Show()

        End If

    End Sub
End Class
