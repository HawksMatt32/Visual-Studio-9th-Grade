﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub
    Private Sub btnShowGreeting_Click(sender As Object, e As EventArgs) Handles btnShowGreeting.Click
        'outputs greetings + name
        lblOutput.Text = "Greetings " & txtName.Text
    End Sub

    Private Sub lblEnter_Click(sender As Object, e As EventArgs) Handles lblEnter.Click

    End Sub

    Private Sub txtName_TextChanged(sender As Object, e As EventArgs) Handles txtName.TextChanged

    End Sub

    Private Sub lblOutput_Click(sender As Object, e As EventArgs) Handles lblOutput.Click

    End Sub
End Class
