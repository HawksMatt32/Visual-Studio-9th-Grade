﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.picFifty = New System.Windows.Forms.PictureBox()
        Me.picTwenty = New System.Windows.Forms.PictureBox()
        Me.picTen = New System.Windows.Forms.PictureBox()
        Me.picFive = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label3 = New System.Windows.Forms.Label()
        CType(Me.picFifty, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTwenty, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picFive, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(270, 445)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(89, 21)
        Me.lblTotal.TabIndex = 0
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(223, 26)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(76, 13)
        Me.lbl1.TabIndex = 1
        Me.lbl1.Text = "Click the coins"
        '
        'picFifty
        '
        Me.picFifty.Image = CType(resources.GetObject("picFifty.Image"), System.Drawing.Image)
        Me.picFifty.Location = New System.Drawing.Point(386, 235)
        Me.picFifty.Name = "picFifty"
        Me.picFifty.Size = New System.Drawing.Size(125, 181)
        Me.picFifty.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picFifty.TabIndex = 2
        Me.picFifty.TabStop = False
        '
        'picTwenty
        '
        Me.picTwenty.Image = CType(resources.GetObject("picTwenty.Image"), System.Drawing.Image)
        Me.picTwenty.Location = New System.Drawing.Point(136, 235)
        Me.picTwenty.Name = "picTwenty"
        Me.picTwenty.Size = New System.Drawing.Size(125, 181)
        Me.picTwenty.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picTwenty.TabIndex = 3
        Me.picTwenty.TabStop = False
        '
        'picTen
        '
        Me.picTen.Image = CType(resources.GetObject("picTen.Image"), System.Drawing.Image)
        Me.picTen.Location = New System.Drawing.Point(261, 102)
        Me.picTen.Name = "picTen"
        Me.picTen.Size = New System.Drawing.Size(125, 181)
        Me.picTen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picTen.TabIndex = 4
        Me.picTen.TabStop = False
        '
        'picFive
        '
        Me.picFive.Image = CType(resources.GetObject("picFive.Image"), System.Drawing.Image)
        Me.picFive.Location = New System.Drawing.Point(11, 102)
        Me.picFive.Name = "picFive"
        Me.picFive.Size = New System.Drawing.Size(125, 181)
        Me.picFive.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.picFive.TabIndex = 5
        Me.picFive.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(224, 485)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 6
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(164, 443)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 7
        Me.Label3.Text = "Total:"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(521, 521)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.picFive)
        Me.Controls.Add(Me.picTen)
        Me.Controls.Add(Me.picTwenty)
        Me.Controls.Add(Me.picFifty)
        Me.Controls.Add(Me.lbl1)
        Me.Controls.Add(Me.lblTotal)
        Me.Name = "Form1"
        Me.Text = "Change"
        CType(Me.picFifty, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTwenty, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picFive, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTotal As Label
    Friend WithEvents lbl1 As Label
    Friend WithEvents picFifty As PictureBox
    Friend WithEvents picTwenty As PictureBox
    Friend WithEvents picTen As PictureBox
    Friend WithEvents picFive As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents Label3 As Label
End Class
