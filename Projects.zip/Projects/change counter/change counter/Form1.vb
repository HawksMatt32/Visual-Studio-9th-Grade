﻿Public Class Form1
    'class level constants
    Dim decFIVE_CENTS_VALUE As Decimal = 0.05D
    Dim decTEN_CENTS_VALUE As Decimal = 0.1D
    Dim decTWENTY_FIVE_CENTS_VALUE As Decimal = 0.25D
    Dim decFIFTY_CENTS_VALUE As Decimal = 0.5D
    'Class Level variable to hold the total
    'init with 0
    Dim decTotal As Decimal = 0.0D
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles picTwenty.Click
        ' add the value of 25 cents to the toal 
        decTotal = decTotal + decTWENTY_FIVE_CENTS_VALUE

        'display total as currency
        lblTotal.Text = decTotal.ToString("c")
    End Sub

    Private Sub picFive_Click(sender As Object, e As EventArgs) Handles picFive.Click
        ' add the value of 5 cents to the toal 
        decTotal = decTotal + decFIVE_CENTS_VALUE

        'display total as currency
        lblTotal.Text = decTotal.ToString("c")
    End Sub

    Private Sub picFifty_Click(sender As Object, e As EventArgs) Handles picFifty.Click
        ' add the value of 50 cents to the toal 
        decTotal = decTotal + decFIFTY_CENTS_VALUE

        'display total as currency
        lblTotal.Text = decTotal.ToString("c")
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub picTen_Click(sender As Object, e As EventArgs) Handles picTen.Click
        ' add the value of 10 cents to the toal 
        decTotal = decTotal + decTEN_CENTS_VALUE

        'display total as currency
        lblTotal.Text = decTotal.ToString("c")
    End Sub
End Class
