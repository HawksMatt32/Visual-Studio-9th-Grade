﻿Module FunkyTime
    Dim frmMain As New Main
    Dim rand As New Random
    Public g_intBestGame As Integer = 9999
    Public g_intWorstGame As Integer = 0
    Public Function RollDie() As Integer
        Dim intDie As Integer
        intDie = rand.Next(6) + 1
        Return intDie
    End Function
    Public Function FirstRoll() As Integer()
        Dim index As Integer
        Const intMAX_SUBSCRIPT As Integer = 11
        Dim intDice(intMAX_SUBSCRIPT) As Integer
        For index = 0 To 11
            intDice(index) = RollDie()
        Next
        Return intDice
    End Function
    Public Function CountFrequency(ByVal intDice As Integer(), intNumber As Integer) As Integer
        Dim intFrequency As Integer
        For Each die In intDice
            If die = intNumber Then
                intFrequency += 1
            End If
        Next
        Return intFrequency
    End Function
    Public Function FindMode(ByVal intDice As Integer()) As Integer
        Dim intMode As Integer
        Dim intRecord As Integer = 0
        Dim intDieNumber As Integer
        For Each intDieNumber In {1, 2, 3, 4, 5, 6}
            If CountFrequency(intDice, intDieNumber) > intRecord Then
                intRecord = CountFrequency(intDice, intDieNumber)
                intMode = intDieNumber
            End If
        Next
        Return intMode
    End Function
    Public Function ListUnmatchedDice(ByVal intDice As Integer()) As Integer()
        Dim intMode = FindMode(intDice)
        Dim intUnmatched(12 - CountFrequency(intDice, intMode) - 1) As Integer
        Dim intIndex As Integer = 0
        For intCount = 0 To (intDice.Length - 1)
            If intDice(intCount) <> intMode Then
                intUnmatched(intIndex) = intCount
                intIndex += 1
            End If
        Next
        Return intUnmatched
    End Function
    Public Function RerollOne(ByVal intDice As Integer(), intIndex As Integer) As Integer()
        intDice(intIndex) = RollDie()
        Return intDice
    End Function
    Public Sub RerollMany(ByVal intDice As Integer(), ByRef intCounter As Integer)
        Dim intNumberOfRolls As Integer = 1
        Dim intMode As Integer = FindMode(intDice)
        Dim intNewDice(11) As Integer
        Dim intUnmatched() As Integer = ListUnmatchedDice(intDice)
        Dim intNumberMatched = 0
        For intCount = 0 To (intDice.Length - 1)
            intNewDice(intCount) = intDice(intCount)
        Next
        Do While intNumberMatched < 12
            For Each index In intUnmatched
                intNewDice = RerollOne(intNewDice, index)
            Next
            For Each die In intNewDice
                intMode = FindMode(intNewDice)
                If die = intMode Then
                    intNumberMatched += 1
                Else
                    intNumberMatched = 0
                End If
            Next
            ReDim intUnmatched(ListUnmatchedDice(intNewDice).Length - 1)
            intUnmatched = ListUnmatchedDice(intNewDice)
            intNumberOfRolls += 1
            OutputDice(intNewDice)
        Loop
        Main.lstGameRolls.Items.Add("Number of Rolls: " & intNumberOfRolls)
        Main.lstGameRolls.Items.Add("Games so Far: " & intCounter)
        If intNumberOfRolls <= g_intBestGame Then
            g_intBestGame = intNumberOfRolls
        End If
        If intNumberOfRolls >= g_intWorstGame Then
            g_intWorstGame = intNumberOfRolls
        End If
        Main.lblBestGame.Text = g_intBestGame.ToString
        Main.lblWorstGame.Text = g_intWorstGame.ToString
        Main.lblNumberOfRolls.Text = intNumberOfRolls.ToString
    End Sub
    Sub ResetAll()
        Main.lblConsole.Text = String.Empty
        Main.lblNumberOfRolls.Text = String.Empty
        Main.lstGameRolls.Items.Clear()
        Main.txtNumberOfGamesToPlay.Focus()
        Main.lblBestGame.Text = String.Empty
        Main.lblWorstGame.Text = String.Empty
    End Sub
    Public Sub StartGame()
        ResetAll()
        Dim intGames As Integer = CInt(Main.txtNumberOfGamesToPlay.Text)
        Dim intCounter As Integer = 0
        Dim intTotalGamesPlayed As Integer = 0
        Dim intDice As Integer() = FirstRoll()
        Dim intNumberOfRolls As Integer = 0
        While intCounter < intGames
            intCounter += 1
            OutputDice(intDice)
            RerollMany(intDice, intCounter)
        End While
    End Sub
    Public Sub OutputDice(ByVal intDice As Integer())
        Dim strDice As String = String.Empty
        For Each die As Integer In intDice
            strDice &= die.ToString
            strDice &= "------"
        Next
        Main.lstGameRolls.Items.Add(strDice)
    End Sub
End Module