﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lstGameRolls = New System.Windows.Forms.ListBox()
        Me.lblBestGame = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblWorstGame = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblNumberOfRolls = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtNumberOfGamesToPlay = New System.Windows.Forms.TextBox()
        Me.btnPlay = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblConsole = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.lblClock = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'lstGameRolls
        '
        Me.lstGameRolls.FormattingEnabled = True
        Me.lstGameRolls.Location = New System.Drawing.Point(203, 38)
        Me.lstGameRolls.Name = "lstGameRolls"
        Me.lstGameRolls.Size = New System.Drawing.Size(1155, 589)
        Me.lstGameRolls.TabIndex = 0
        '
        'lblBestGame
        '
        Me.lblBestGame.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBestGame.Location = New System.Drawing.Point(46, 168)
        Me.lblBestGame.Name = "lblBestGame"
        Me.lblBestGame.Size = New System.Drawing.Size(100, 23)
        Me.lblBestGame.TabIndex = 1
        Me.lblBestGame.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(46, 284)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 27)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Number of Games to Play"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(67, 136)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(59, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Best Game"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblWorstGame
        '
        Me.lblWorstGame.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblWorstGame.Location = New System.Drawing.Point(46, 242)
        Me.lblWorstGame.Name = "lblWorstGame"
        Me.lblWorstGame.Size = New System.Drawing.Size(100, 23)
        Me.lblWorstGame.TabIndex = 4
        Me.lblWorstGame.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(63, 210)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(66, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Worst Game"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblNumberOfRolls
        '
        Me.lblNumberOfRolls.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblNumberOfRolls.Location = New System.Drawing.Point(46, 94)
        Me.lblNumberOfRolls.Name = "lblNumberOfRolls"
        Me.lblNumberOfRolls.Size = New System.Drawing.Size(100, 23)
        Me.lblNumberOfRolls.TabIndex = 6
        Me.lblNumberOfRolls.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(55, 62)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(82, 13)
        Me.Label7.TabIndex = 7
        Me.Label7.Text = "Number of Rolls"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txtNumberOfGamesToPlay
        '
        Me.txtNumberOfGamesToPlay.Location = New System.Drawing.Point(46, 330)
        Me.txtNumberOfGamesToPlay.Name = "txtNumberOfGamesToPlay"
        Me.txtNumberOfGamesToPlay.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberOfGamesToPlay.TabIndex = 8
        '
        'btnPlay
        '
        Me.btnPlay.Location = New System.Drawing.Point(27, 458)
        Me.btnPlay.Name = "btnPlay"
        Me.btnPlay.Size = New System.Drawing.Size(119, 51)
        Me.btnPlay.TabIndex = 9
        Me.btnPlay.Text = "&Play"
        Me.btnPlay.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(27, 551)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(119, 51)
        Me.btnReset.TabIndex = 10
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(27, 375)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(119, 51)
        Me.btnExit.TabIndex = 11
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblConsole})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 727)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1370, 22)
        Me.StatusStrip1.TabIndex = 12
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblConsole
        '
        Me.lblConsole.Name = "lblConsole"
        Me.lblConsole.Size = New System.Drawing.Size(125, 17)
        Me.lblConsole.Text = "Welcome to the Game"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 2
        '
        'lblClock
        '
        Me.lblClock.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClock.Font = New System.Drawing.Font("Wide Latin", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClock.Location = New System.Drawing.Point(27, 631)
        Me.lblClock.Name = "lblClock"
        Me.lblClock.Size = New System.Drawing.Size(100, 23)
        Me.lblClock.TabIndex = 13
        Me.lblClock.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(24, 618)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(122, 13)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Time I Have Been Alive:"
        '
        'Main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lblClock)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnPlay)
        Me.Controls.Add(Me.txtNumberOfGamesToPlay)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.lblNumberOfRolls)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.lblWorstGame)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblBestGame)
        Me.Controls.Add(Me.lstGameRolls)
        Me.Name = "Main"
        Me.Text = "Ezee"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstGameRolls As ListBox
    Friend WithEvents lblBestGame As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblWorstGame As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents lblNumberOfRolls As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtNumberOfGamesToPlay As TextBox
    Friend WithEvents btnPlay As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents StatusStrip1 As StatusStrip
    Friend WithEvents lblConsole As ToolStripStatusLabel
    Friend WithEvents Timer1 As Timer
    Friend WithEvents lblClock As Label
    Friend WithEvents Label4 As Label
End Class
