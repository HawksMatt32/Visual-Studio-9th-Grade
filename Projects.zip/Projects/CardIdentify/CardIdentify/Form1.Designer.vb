﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.pic8 = New System.Windows.Forms.PictureBox()
        Me.pic2 = New System.Windows.Forms.PictureBox()
        Me.picK = New System.Windows.Forms.PictureBox()
        Me.picAce = New System.Windows.Forms.PictureBox()
        Me.picJoke = New System.Windows.Forms.PictureBox()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblPick = New System.Windows.Forms.Label()
        Me.lblOut = New System.Windows.Forms.Label()
        CType(Me.pic8, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picK, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAce, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picJoke, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'pic8
        '
        Me.pic8.Image = CType(resources.GetObject("pic8.Image"), System.Drawing.Image)
        Me.pic8.Location = New System.Drawing.Point(26, 105)
        Me.pic8.Name = "pic8"
        Me.pic8.Size = New System.Drawing.Size(105, 143)
        Me.pic8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.pic8.TabIndex = 0
        Me.pic8.TabStop = False
        '
        'pic2
        '
        Me.pic2.Image = CType(resources.GetObject("pic2.Image"), System.Drawing.Image)
        Me.pic2.Location = New System.Drawing.Point(150, 105)
        Me.pic2.Name = "pic2"
        Me.pic2.Size = New System.Drawing.Size(105, 143)
        Me.pic2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pic2.TabIndex = 1
        Me.pic2.TabStop = False
        '
        'picK
        '
        Me.picK.Image = CType(resources.GetObject("picK.Image"), System.Drawing.Image)
        Me.picK.Location = New System.Drawing.Point(274, 105)
        Me.picK.Name = "picK"
        Me.picK.Size = New System.Drawing.Size(105, 143)
        Me.picK.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picK.TabIndex = 2
        Me.picK.TabStop = False
        '
        'picAce
        '
        Me.picAce.Image = CType(resources.GetObject("picAce.Image"), System.Drawing.Image)
        Me.picAce.Location = New System.Drawing.Point(398, 105)
        Me.picAce.Name = "picAce"
        Me.picAce.Size = New System.Drawing.Size(105, 143)
        Me.picAce.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAce.TabIndex = 3
        Me.picAce.TabStop = False
        '
        'picJoke
        '
        Me.picJoke.Image = CType(resources.GetObject("picJoke.Image"), System.Drawing.Image)
        Me.picJoke.Location = New System.Drawing.Point(522, 105)
        Me.picJoke.Name = "picJoke"
        Me.picJoke.Size = New System.Drawing.Size(105, 143)
        Me.picJoke.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picJoke.TabIndex = 4
        Me.picJoke.TabStop = False
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(287, 314)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 5
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblPick
        '
        Me.lblPick.AutoSize = True
        Me.lblPick.Location = New System.Drawing.Point(256, 31)
        Me.lblPick.Name = "lblPick"
        Me.lblPick.Size = New System.Drawing.Size(137, 13)
        Me.lblPick.TabIndex = 6
        Me.lblPick.Text = "Pick a card to see it's name"
        '
        'lblOut
        '
        Me.lblOut.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom), System.Windows.Forms.AnchorStyles)
        Me.lblOut.AutoSize = True
        Me.lblOut.Location = New System.Drawing.Point(293, 279)
        Me.lblOut.Name = "lblOut"
        Me.lblOut.Size = New System.Drawing.Size(0, 13)
        Me.lblOut.TabIndex = 7
        Me.lblOut.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(649, 349)
        Me.Controls.Add(Me.lblOut)
        Me.Controls.Add(Me.lblPick)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.picJoke)
        Me.Controls.Add(Me.picAce)
        Me.Controls.Add(Me.picK)
        Me.Controls.Add(Me.pic2)
        Me.Controls.Add(Me.pic8)
        Me.Name = "Form1"
        Me.Text = "Card Identifier"
        CType(Me.pic8, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pic2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picK, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAce, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picJoke, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents pic8 As PictureBox
    Friend WithEvents pic2 As PictureBox
    Friend WithEvents picK As PictureBox
    Friend WithEvents picAce As PictureBox
    Friend WithEvents picJoke As PictureBox
    Friend WithEvents btnExit As Button
    Friend WithEvents lblPick As Label
    Friend WithEvents lblOut As Label
End Class
