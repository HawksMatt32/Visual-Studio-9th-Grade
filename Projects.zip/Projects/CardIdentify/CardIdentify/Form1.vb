﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes program
        Me.Close()

    End Sub

    Private Sub lblOut_Click(sender As Object, e As EventArgs) Handles lblOut.Click

    End Sub

    Private Sub pic8_Click(sender As Object, e As EventArgs) Handles pic8.Click
        'outputs name of card to label
        lblOut.Text = "Eight of Hearts"
    End Sub

    Private Sub pic2_Click(sender As Object, e As EventArgs) Handles pic2.Click
        'outputs name of card to label
        lblOut.Text = "Two of Clubs"
    End Sub

    Private Sub picK_Click(sender As Object, e As EventArgs) Handles picK.Click
        'outputs name of card to label
        lblOut.Text = "King of Spades"
    End Sub

    Private Sub picAce_Click(sender As Object, e As EventArgs) Handles picAce.Click
        'outputs name of card to label
        lblOut.Text = "Ace of Diamonds"
    End Sub

    Private Sub picJoke_Click(sender As Object, e As EventArgs) Handles picJoke.Click
        'outputs name of card to label
        lblOut.Text = "Black Joker"
    End Sub
End Class
