﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class bruh
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(bruh))
        Me.btnBruh = New System.Windows.Forms.Button()
        Me.lblBruh = New System.Windows.Forms.Label()
        Me.picBruh = New System.Windows.Forms.PictureBox()
        CType(Me.picBruh, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnBruh
        '
        Me.btnBruh.Location = New System.Drawing.Point(302, 249)
        Me.btnBruh.Name = "btnBruh"
        Me.btnBruh.Size = New System.Drawing.Size(75, 23)
        Me.btnBruh.TabIndex = 0
        Me.btnBruh.Text = "bruh"
        Me.btnBruh.UseVisualStyleBackColor = True
        '
        'lblBruh
        '
        Me.lblBruh.AutoSize = True
        Me.lblBruh.Location = New System.Drawing.Point(299, 233)
        Me.lblBruh.Name = "lblBruh"
        Me.lblBruh.Size = New System.Drawing.Size(85, 13)
        Me.lblBruh.TabIndex = 1
        Me.lblBruh.Text = "click me for bruh"
        '
        'picBruh
        '
        Me.picBruh.Image = CType(resources.GetObject("picBruh.Image"), System.Drawing.Image)
        Me.picBruh.Location = New System.Drawing.Point(0, 0)
        Me.picBruh.Name = "picBruh"
        Me.picBruh.Size = New System.Drawing.Size(711, 505)
        Me.picBruh.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picBruh.TabIndex = 2
        Me.picBruh.TabStop = False
        Me.picBruh.Visible = False
        '
        'bruh
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(706, 495)
        Me.Controls.Add(Me.picBruh)
        Me.Controls.Add(Me.lblBruh)
        Me.Controls.Add(Me.btnBruh)
        Me.Name = "bruh"
        Me.Text = "bruh"
        CType(Me.picBruh, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnBruh As Button
    Friend WithEvents lblBruh As Label
    Friend WithEvents picBruh As PictureBox
End Class
