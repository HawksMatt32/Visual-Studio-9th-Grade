﻿Public Class bruh
    Private Sub btnBruh_Click(sender As Object, e As EventArgs) Handles btnBruh.Click
        picBruh.Visible = True
    End Sub
End Class
