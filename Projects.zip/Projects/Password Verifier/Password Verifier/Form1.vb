﻿Public Class Form1
    'global variable
    Dim StrIn As String
    Dim intCounter As Integer = 0

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles Label1.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnTry_Click(sender As Object, e As EventArgs) Handles btnTry.Click
        'start error handling

        'if functions are true call
        'if contains a letter
        If IsAlp(txtIn.Text) = True Then
                'if contains a number
                If IsNumber(txtIn.Text) = True Then
                    'if longer than 6
                    If txtIn.Text.Length >= 6 Then
                        MessageBox.Show("You're in.")
                    Else
                        MessageBox.Show("y'all best scramble like an egg before i fold u like an omelet")
                    End If


                Else
                    MessageBox.Show("youz done for now")
                End If

            Else
                MessageBox.Show("YOUZ OUT!")
            End If


    End Sub
    'if txtIn is number return true
    Function IsNumber(ByVal StrIn As String) As Boolean
        'reset counter
        Try
            intCounter = 0
            ' do until i see a number
            Do Until intCounter = CInt(txtIn.Text.Length) + 1
                If IsNumeric(txtIn.Text.Chars(intCounter)) Then
                    Return True

                Else

                    intCounter += 1
                End If

            Loop
        Catch ex As Exception
            MessageBox.Show("u best have letters AND numbers")
        End Try




    End Function
    'if txtIn is NOT number return true


    Function IsAlp(ByVal StrIn As String) As Boolean
        'reset counter
        intCounter = 0
        'do until i see a letter
        Try
            intCounter = 0
            Do Until intCounter = CInt(txtIn.Text.Length) + 1
                If Not IsNumeric((txtIn.Text.Chars(intCounter))) Then
                    Return True

                Else
                    intCounter += 1
                End If
            Loop
        Catch ex As Exception

        End Try

    End Function

    Private Sub btnOut_Click(sender As Object, e As EventArgs) Handles btnOut.Click
        'closes form
        Me.Close()
    End Sub
    Function isValid() As Boolean


    End Function

End Class
