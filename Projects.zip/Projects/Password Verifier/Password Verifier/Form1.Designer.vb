﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.btnTry = New System.Windows.Forms.Button()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(50, 78)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(301, 20)
        Me.txtIn.TabIndex = 0
        '
        'btnTry
        '
        Me.btnTry.Location = New System.Drawing.Point(78, 121)
        Me.btnTry.Name = "btnTry"
        Me.btnTry.Size = New System.Drawing.Size(75, 23)
        Me.btnTry.TabIndex = 1
        Me.btnTry.Text = "Try"
        Me.btnTry.UseVisualStyleBackColor = True
        '
        'btnOut
        '
        Me.btnOut.Location = New System.Drawing.Point(212, 121)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(75, 23)
        Me.btnOut.TabIndex = 2
        Me.btnOut.Text = "Out"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(126, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(147, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Password for getting into Club"
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(64, 34)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(271, 41)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Must have one alphanumeric digit and numerical digit and be at least 6 digits lon" &
    "g."
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(401, 165)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.btnTry)
        Me.Controls.Add(Me.txtIn)
        Me.Name = "Form1"
        Me.Text = "Password Verifier"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtIn As TextBox
    Friend WithEvents btnTry As Button
    Friend WithEvents btnOut As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
