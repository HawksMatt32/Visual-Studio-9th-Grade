﻿Public Class Form1
    Private Sub Label13_Click(sender As Object, e As EventArgs) Handles Label13.Click, Label17.Click

    End Sub

    Private Sub Label14_Click(sender As Object, e As EventArgs) Handles Label14.Click

    End Sub

    Private Sub Label15_Click(sender As Object, e As EventArgs) Handles Label15.Click

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        Try
            'call and calculate variables for sales
            Dim decAdultSales As Decimal = CDec(txtAdultPrice.Text) * CDec(txtAdultSold.Text)
            Dim decChildSales As Decimal = CDec(txtChildPrice.Text) * CDec(txtChildSold.Text)
            Dim decTotalSales As Decimal = decAdultSales + decChildSales
            'show text as calculations
            lblAdultSalesGross.Text = decAdultSales.ToString("C")
            lblChildSalesGross.Text = decChildSales.ToString("C")
            lblGross.Text = decTotalSales.ToString("C")
            'call and calculate variables for profit
            Dim decAdultProfit As Decimal = decAdultSales - 10
            Dim decChildProfit As Decimal = decChildSales - 10
            Dim decTotalProfit As Decimal = decAdultProfit + decChildProfit
            'show text as calculations
            lblAdultProfit.Text = decAdultProfit.ToString("C")
            lblChildProfit.Text = decChildProfit.ToString("C")
            lblTotalProfit.Text = decTotalProfit.ToString("C")
        Catch ex As Exception
            MessageBox.Show("invalid input")
        End Try


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears input and output
        txtAdultPrice.Clear()
        txtAdultSold.Clear()
        txtChildPrice.Clear()
        txtChildSold.Clear()
        lblAdultProfit.Text = ""
        lblAdultSalesGross.Text = ""
        lblAdultProfit.Text = ""
        lblChildProfit.Text = ""
        lblChildSalesGross.Text = ""
        lblGross.Text = ""
        lblTotalProfit.Text = ""
    End Sub
End Class
