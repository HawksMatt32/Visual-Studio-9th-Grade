﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btn15_Click(sender As Object, e As EventArgs) Handles btn15.Click
        'variable declarations
        Dim dblBill As Double = 0.0
        Dim dblTip As Double = 0.0

        'get amount of bill
        dblBill = CDbl(txtBillTotal.Text)

        'calculate 15% tip
        dblTip = dblBill * 0.15

        'display tip
        lblTip.Text = dblTip.ToString("c")

    End Sub

    Private Sub btn20_Click(sender As Object, e As EventArgs) Handles btn20.Click
        'variable declarations
        Dim dblBill As Double = 0.0
        Dim dblTip As Double = 0.0

        'get amount of bill
        dblBill = CDbl(txtBillTotal.Text)

        'calculate 20% tip
        dblTip = dblBill * 0.2

        'display tip
        lblTip.Text = dblTip.ToString("c")
    End Sub

    Private Sub btn25_Click(sender As Object, e As EventArgs) Handles btn25.Click
        'variable declarations
        Dim dblBill As Double = 0.0
        Dim dblTip As Double = 0.0

        'get amount of bill
        dblBill = CDbl(txtBillTotal.Text)

        'calculate 25% tip
        dblTip = dblBill * 0.25

        'display tip
        lblTip.Text = dblTip.ToString("c")
    End Sub
End Class
