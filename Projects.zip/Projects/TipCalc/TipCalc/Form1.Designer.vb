﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btn15 = New System.Windows.Forms.Button()
        Me.btn20 = New System.Windows.Forms.Button()
        Me.btn25 = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblTipAmount = New System.Windows.Forms.Label()
        Me.lblBillTotal = New System.Windows.Forms.Label()
        Me.txtBillTotal = New System.Windows.Forms.TextBox()
        Me.lblTip = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn15
        '
        Me.btn15.Location = New System.Drawing.Point(30, 54)
        Me.btn15.Name = "btn15"
        Me.btn15.Size = New System.Drawing.Size(75, 23)
        Me.btn15.TabIndex = 0
        Me.btn15.Text = "15%"
        Me.btn15.UseVisualStyleBackColor = True
        '
        'btn20
        '
        Me.btn20.Location = New System.Drawing.Point(127, 54)
        Me.btn20.Name = "btn20"
        Me.btn20.Size = New System.Drawing.Size(75, 23)
        Me.btn20.TabIndex = 1
        Me.btn20.Text = "20%"
        Me.btn20.UseVisualStyleBackColor = True
        '
        'btn25
        '
        Me.btn25.Location = New System.Drawing.Point(224, 54)
        Me.btn25.Name = "btn25"
        Me.btn25.Size = New System.Drawing.Size(75, 23)
        Me.btn25.TabIndex = 2
        Me.btn25.Text = "25%"
        Me.btn25.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(124, 140)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 3
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblTipAmount
        '
        Me.lblTipAmount.AutoSize = True
        Me.lblTipAmount.Location = New System.Drawing.Point(78, 106)
        Me.lblTipAmount.Name = "lblTipAmount"
        Me.lblTipAmount.Size = New System.Drawing.Size(76, 13)
        Me.lblTipAmount.TabIndex = 4
        Me.lblTipAmount.Text = "Amount to Tip:"
        '
        'lblBillTotal
        '
        Me.lblBillTotal.AutoSize = True
        Me.lblBillTotal.Location = New System.Drawing.Point(70, 26)
        Me.lblBillTotal.Name = "lblBillTotal"
        Me.lblBillTotal.Size = New System.Drawing.Size(85, 13)
        Me.lblBillTotal.TabIndex = 5
        Me.lblBillTotal.Text = "Amount of Total:"
        '
        'txtBillTotal
        '
        Me.txtBillTotal.Location = New System.Drawing.Point(160, 23)
        Me.txtBillTotal.Name = "txtBillTotal"
        Me.txtBillTotal.Size = New System.Drawing.Size(100, 20)
        Me.txtBillTotal.TabIndex = 7
        '
        'lblTip
        '
        Me.lblTip.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTip.Location = New System.Drawing.Point(160, 101)
        Me.lblTip.Name = "lblTip"
        Me.lblTip.Size = New System.Drawing.Size(100, 23)
        Me.lblTip.TabIndex = 8
        Me.lblTip.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(329, 205)
        Me.Controls.Add(Me.lblTip)
        Me.Controls.Add(Me.txtBillTotal)
        Me.Controls.Add(Me.lblBillTotal)
        Me.Controls.Add(Me.lblTipAmount)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btn25)
        Me.Controls.Add(Me.btn20)
        Me.Controls.Add(Me.btn15)
        Me.Name = "Form1"
        Me.Text = "Tip Graphing Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn15 As Button
    Friend WithEvents btn20 As Button
    Friend WithEvents btn25 As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblTipAmount As Label
    Friend WithEvents lblBillTotal As Label
    Friend WithEvents txtBillTotal As TextBox
    Friend WithEvents lblTip As Label
End Class
