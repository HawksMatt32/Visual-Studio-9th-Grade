﻿Public Class Form1
    Private Sub picCardFront_Click(sender As Object, e As EventArgs) Handles picCardFront.Click

    End Sub

    Private Sub picCardBack_Click(sender As Object, e As EventArgs) Handles picCardBack.Click

    End Sub

    Private Sub btnShowBack_Click(sender As Object, e As EventArgs) Handles btnShowBack.Click
        picCardBack.Visible = True
        picCardFront.Visible = False

    End Sub

    Private Sub btnShowFront_Click(sender As Object, e As EventArgs) Handles btnShowFront.Click
        picCardFront.Visible = True
        picCardBack.Visible = False
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
