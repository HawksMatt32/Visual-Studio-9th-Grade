﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnShowFront = New System.Windows.Forms.Button()
        Me.btnShowBack = New System.Windows.Forms.Button()
        Me.picCardBack = New System.Windows.Forms.PictureBox()
        Me.picCardFront = New System.Windows.Forms.PictureBox()
        CType(Me.picCardBack, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picCardFront, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnShowFront
        '
        Me.btnShowFront.Location = New System.Drawing.Point(169, 189)
        Me.btnShowFront.Name = "btnShowFront"
        Me.btnShowFront.Size = New System.Drawing.Size(75, 41)
        Me.btnShowFront.TabIndex = 0
        Me.btnShowFront.Text = "Show the card front"
        Me.btnShowFront.UseVisualStyleBackColor = True
        '
        'btnShowBack
        '
        Me.btnShowBack.Location = New System.Drawing.Point(41, 189)
        Me.btnShowBack.Name = "btnShowBack"
        Me.btnShowBack.Size = New System.Drawing.Size(75, 41)
        Me.btnShowBack.TabIndex = 1
        Me.btnShowBack.Text = "Show the card back"
        Me.btnShowBack.UseVisualStyleBackColor = True
        '
        'picCardBack
        '
        Me.picCardBack.Image = CType(resources.GetObject("picCardBack.Image"), System.Drawing.Image)
        Me.picCardBack.Location = New System.Drawing.Point(28, 12)
        Me.picCardBack.Name = "picCardBack"
        Me.picCardBack.Size = New System.Drawing.Size(100, 135)
        Me.picCardBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picCardBack.TabIndex = 2
        Me.picCardBack.TabStop = False
        Me.picCardBack.Visible = False
        '
        'picCardFront
        '
        Me.picCardFront.Image = CType(resources.GetObject("picCardFront.Image"), System.Drawing.Image)
        Me.picCardFront.Location = New System.Drawing.Point(156, 12)
        Me.picCardFront.Name = "picCardFront"
        Me.picCardFront.Size = New System.Drawing.Size(100, 135)
        Me.picCardFront.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.picCardFront.TabIndex = 3
        Me.picCardFront.TabStop = False
        Me.picCardFront.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.picCardFront)
        Me.Controls.Add(Me.picCardBack)
        Me.Controls.Add(Me.btnShowBack)
        Me.Controls.Add(Me.btnShowFront)
        Me.Name = "Form1"
        Me.Text = "Card Flip"
        CType(Me.picCardBack, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picCardFront, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnShowFront As Button
    Friend WithEvents btnShowBack As Button
    Friend WithEvents picCardBack As PictureBox
    Friend WithEvents picCardFront As PictureBox
End Class
