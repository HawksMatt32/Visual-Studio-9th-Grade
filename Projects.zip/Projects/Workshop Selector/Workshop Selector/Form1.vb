﻿Public Class Form1
    Dim intPlaceHolder As Integer
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub ListBox1_SelectedIndexChanged(sender As Object, e As EventArgs) Handles lstWorkShop.SelectedIndexChanged

    End Sub

    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'integrr variables
        Dim intTotalCosts As Integer = 0
        Dim intDays As Integer = 0
        Dim intFee As Integer = 0
        Dim intLodging As Integer = 0
        'string vatiables
        Dim strWorkShopSelected As String = String.Empty
        Dim strLocationSelected As String = String.Empty
        Try
            'sum built in error handlin'
            If lstLocation.SelectedIndex = -1 Then
                MessageBox.Show("Please click a location AND workshop")
            ElseIf lstLocation.SelectedIndex = -1 Then
                MessageBox.Show("Please click a location AND workshop")
            Else
                'set days and registraion costs NERD
                SetDaysAndRegistrationFee(intDays, intFee, strWorkShopSelected)
                'tests for which lodging is used
                SetLodingFeePerDay(intLodging, strLocationSelected)
                'set list costs output to fee + (lodging * days) and sum formatting
                Dim strCostsOutputTop As String = strWorkShopSelected + " fee for $" + CStr(intFee) + ".00 + Lodging fee for $" + CStr(intLodging * intDays) + ".00"
                lstCosts.Items.Add(strCostsOutputTop)
                intTotalCosts += intFee + (intLodging * intDays)
                intPlaceHolder += intTotalCosts
            End If
        Catch ex As Exception
            MessageBox.Show("Error")
        End Try




    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'display total costs
        lblOut.Text = intPlaceHolder.ToString("C")
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        intPlaceHolder = 0 'clear lists and labels
        lblOut.Text = String.Empty
        lstCosts.Items.Clear()
        lstLocation.ClearSelected()
        lstWorkShop.ClearSelected()


    End Sub
    Sub SetDaysAndRegistrationFee(ByRef intDays As Integer, ByRef intFee As Integer, ByRef strWorkshopSelected As String)
        If lstWorkShop.SelectedIndex = 0 Then   'handling stress
            'sets ddays and fee
            intDays = 3
            intFee = 595
            strWorkshopSelected = "Handling Stress"
        End If
        If lstWorkShop.SelectedIndex = 1 Then   'time management
            intDays = 3
            intFee = 695
            strWorkshopSelected = "Time Management"

        End If
        If lstWorkShop.SelectedIndex = 2 Then   'supervision skills
            intDays = 3
            intFee = 995
            strWorkshopSelected = "Supervision Skills"
        End If
        If lstWorkShop.SelectedIndex = 3 Then   'negotiation
            intDays = 5
            intFee = 1295
            strWorkshopSelected = "Negotiaion"
        End If
        If lstWorkShop.SelectedIndex = 4 Then   'how to interview
            intDays = 1
            intFee = 395
            strWorkshopSelected = "How to Interview"
        End If
    End Sub
    Sub SetLodingFeePerDay(ByRef intLodging As Integer, ByRef strLocationSelected As String)
        If lstLocation.SelectedIndex = 0 Then    'austin
            intLodging = 95
            strLocationSelected = "Austin"

        End If
        If lstLocation.SelectedIndex = 1 Then    'Chicago
            intLodging = 125
            strLocationSelected = "Chicago"
        End If
        If lstLocation.SelectedIndex = 2 Then    'Dalass
            intLodging = 110
            strLocationSelected = "Dallas"
        End If
        If lstLocation.SelectedIndex = 3 Then    'Orlando
            intLodging = 100
            strLocationSelected = "Orlando"
        End If
        If lstLocation.SelectedIndex = 4 Then    'Phoenix
            intLodging = 92
            strLocationSelected = "Phoenix"
        End If
        If lstLocation.SelectedIndex = 5 Then    'Raleigh
            intLodging = 90
            strLocationSelected = "Raleigh"
        End If
    End Sub
End Class
