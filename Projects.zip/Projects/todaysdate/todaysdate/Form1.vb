﻿Public Class Form1
    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblDate.Click


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'get date
        Dim dtmSystemDate = Today
        'display date
        lblDate.Text = dtmSystemDate.ToString("d")
    End Sub
End Class
