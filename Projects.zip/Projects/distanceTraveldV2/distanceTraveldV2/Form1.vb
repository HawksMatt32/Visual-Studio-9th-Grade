﻿Public Class Form1
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'setup input boxes / variabe deckaration
        Dim strHoursDriven As String = InputBox("What are your hours Driven?", "Input", "Input")
        Dim strSpeed As String = InputBox("How fast will you be Driving?", "Input", "Input")
        'variable delaration
        Dim intCounter As Integer = 0
        'show speed and distance
        lst.Items(0) = "Vehichle Speed: " + strSpeed
        lst.Items(1) = "Time Travelled: " + strHoursDriven
        lst.Items(2) = "Speed   Time Travelled"
        lst.Items(3) = "----------------------"
        'loop while counter is less than or equal to hours (goal)
        Do While intCounter <= CInt(strHoursDriven)
            'output the hours driven and distane for that hour
            lst.Items(intCounter + 3) = (intCounter * CInt(strSpeed))
            intCounter += 1
        Loop
        'some formatting and final output
        lst.Items(intCounter + 2) = "Total Distance Travelled:"
        lst.Items(intCounter + 3) = CInt(strSpeed) * CInt(strHoursDriven)

    End Sub
End Class