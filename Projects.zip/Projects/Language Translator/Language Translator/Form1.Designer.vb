﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.lblTranslation = New System.Windows.Forms.Label()
        Me.btnSpanish = New System.Windows.Forms.Button()
        Me.btnItalian = New System.Windows.Forms.Button()
        Me.btnRussian = New System.Windows.Forms.Button()
        Me.btnClearTranslation = New System.Windows.Forms.Button()
        Me.BtnName = New System.Windows.Forms.Button()
        Me.txtNameBox = New System.Windows.Forms.TextBox()
        Me.lblName = New System.Windows.Forms.Label()
        Me.btnLooksGood = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(273, 53)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(318, 26)
        Me.lbl1.TabIndex = 0
        Me.lbl1.Text = "Select language and I will say your name in the selected language" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.lbl1.Visible = False
        '
        'lblTranslation
        '
        Me.lblTranslation.AutoSize = True
        Me.lblTranslation.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTranslation.Location = New System.Drawing.Point(387, 115)
        Me.lblTranslation.Name = "lblTranslation"
        Me.lblTranslation.Size = New System.Drawing.Size(126, 17)
        Me.lblTranslation.TabIndex = 1
        Me.lblTranslation.Text = "Translation Line"
        Me.lblTranslation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblTranslation.Visible = False
        '
        'btnSpanish
        '
        Me.btnSpanish.Location = New System.Drawing.Point(418, 188)
        Me.btnSpanish.Name = "btnSpanish"
        Me.btnSpanish.Size = New System.Drawing.Size(75, 23)
        Me.btnSpanish.TabIndex = 2
        Me.btnSpanish.Text = "Spanish"
        Me.btnSpanish.UseVisualStyleBackColor = True
        Me.btnSpanish.Visible = False
        '
        'btnItalian
        '
        Me.btnItalian.Location = New System.Drawing.Point(284, 188)
        Me.btnItalian.Name = "btnItalian"
        Me.btnItalian.Size = New System.Drawing.Size(75, 23)
        Me.btnItalian.TabIndex = 3
        Me.btnItalian.Text = "Italian"
        Me.btnItalian.UseVisualStyleBackColor = True
        Me.btnItalian.Visible = False
        '
        'btnRussian
        '
        Me.btnRussian.Location = New System.Drawing.Point(552, 188)
        Me.btnRussian.Name = "btnRussian"
        Me.btnRussian.Size = New System.Drawing.Size(75, 23)
        Me.btnRussian.TabIndex = 4
        Me.btnRussian.Text = "Russian"
        Me.btnRussian.UseVisualStyleBackColor = True
        Me.btnRussian.Visible = False
        '
        'btnClearTranslation
        '
        Me.btnClearTranslation.Location = New System.Drawing.Point(385, 242)
        Me.btnClearTranslation.Name = "btnClearTranslation"
        Me.btnClearTranslation.Size = New System.Drawing.Size(130, 23)
        Me.btnClearTranslation.TabIndex = 5
        Me.btnClearTranslation.Text = "Clear Translation Line"
        Me.btnClearTranslation.UseVisualStyleBackColor = True
        Me.btnClearTranslation.Visible = False
        '
        'BtnName
        '
        Me.BtnName.Location = New System.Drawing.Point(418, 27)
        Me.BtnName.Name = "BtnName"
        Me.BtnName.Size = New System.Drawing.Size(75, 23)
        Me.BtnName.TabIndex = 6
        Me.BtnName.Text = "Set Name"
        Me.BtnName.UseVisualStyleBackColor = True
        '
        'txtNameBox
        '
        Me.txtNameBox.Location = New System.Drawing.Point(400, 176)
        Me.txtNameBox.Name = "txtNameBox"
        Me.txtNameBox.Size = New System.Drawing.Size(100, 20)
        Me.txtNameBox.TabIndex = 7
        '
        'lblName
        '
        Me.lblName.AutoSize = True
        Me.lblName.Location = New System.Drawing.Point(450, 79)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(0, 13)
        Me.lblName.TabIndex = 8
        '
        'btnLooksGood
        '
        Me.btnLooksGood.Location = New System.Drawing.Point(398, 112)
        Me.btnLooksGood.Name = "btnLooksGood"
        Me.btnLooksGood.Size = New System.Drawing.Size(105, 23)
        Me.btnLooksGood.TabIndex = 9
        Me.btnLooksGood.Text = "Looks Good!"
        Me.btnLooksGood.UseVisualStyleBackColor = True
        Me.btnLooksGood.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(901, 319)
        Me.Controls.Add(Me.btnLooksGood)
        Me.Controls.Add(Me.lblName)
        Me.Controls.Add(Me.txtNameBox)
        Me.Controls.Add(Me.BtnName)
        Me.Controls.Add(Me.btnClearTranslation)
        Me.Controls.Add(Me.btnRussian)
        Me.Controls.Add(Me.btnItalian)
        Me.Controls.Add(Me.btnSpanish)
        Me.Controls.Add(Me.lblTranslation)
        Me.Controls.Add(Me.lbl1)
        Me.Name = "Form1"
        Me.Text = "Language Translator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lbl1 As Label
    Friend WithEvents lblTranslation As Label
    Friend WithEvents btnSpanish As Button
    Friend WithEvents btnItalian As Button
    Friend WithEvents btnRussian As Button
    Friend WithEvents btnClearTranslation As Button
    Friend WithEvents BtnName As Button
    Friend WithEvents txtNameBox As TextBox
    Friend WithEvents lblName As Label
    Friend WithEvents btnLooksGood As Button
End Class
