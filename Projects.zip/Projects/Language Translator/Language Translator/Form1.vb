﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblTranslation_Click(sender As Object, e As EventArgs) Handles lblTranslation.Click

    End Sub

    Private Sub lbl1_Click(sender As Object, e As EventArgs) Handles lbl1.Click

    End Sub

    Private Sub btnItalian_Click(sender As Object, e As EventArgs) Handles btnItalian.Click
        lblTranslation.Text = "Il tuo nome"
    End Sub

    Private Sub btnSpanish_Click(sender As Object, e As EventArgs) Handles btnSpanish.Click
        lblTranslation.Text = "Tu nombre"
    End Sub

    Private Sub btnRussian_Click(sender As Object, e As EventArgs) Handles btnRussian.Click
        lblTranslation.Text = "Vashe imya"
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClearTranslation.Click
        lblTranslation.Text = ""
    End Sub

    Private Sub BtnName_Click(sender As Object, e As EventArgs) Handles BtnName.Click
        lblName.Text = txtNameBox.Text
        btnLooksGood.Visible = True

    End Sub

    Private Sub Label1_Click(sender As Object, e As EventArgs) Handles lblName.Click

    End Sub

    Private Sub btnLooksGood_Click(sender As Object, e As EventArgs) Handles btnLooksGood.Click
        btnLooksGood.Visible = False
        lblName.Visible = False
        txtNameBox.Visible = False
        BtnName.Visible = False
        btnRussian.Visible = True
        btnSpanish.Visible = True
        btnRussian.Visible = True
        btnClearTranslation.Visible = True
        lblTranslation.Visible = True
        lbl1.Visible = True
        btnItalian.Visible = True

    End Sub
End Class
