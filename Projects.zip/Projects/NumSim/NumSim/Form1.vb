﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub pic5_Click(sender As Object, e As EventArgs) Handles pic5.Click
        'sets lblOut to #
        lblOut.Text = "Five"
    End Sub

    Private Sub pic4_Click(sender As Object, e As EventArgs) Handles pic4.Click
        'sets lblOut to #
        lblOut.Text = "Four"
    End Sub

    Private Sub pic3_Click(sender As Object, e As EventArgs) Handles pic3.Click
        'sets lblOut to #
        lblOut.Text = "Three"
    End Sub

    Private Sub pic2_Click(sender As Object, e As EventArgs) Handles pic2.Click
        'sets lblOut to #
        lblOut.Text = "Two"
    End Sub

    Private Sub pic1_Click(sender As Object, e As EventArgs) Handles pic1.Click
        'sets lblOut to #
        lblOut.Text = "One"
    End Sub
End Class
