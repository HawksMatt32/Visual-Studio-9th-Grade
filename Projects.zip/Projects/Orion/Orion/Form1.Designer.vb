﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.btnHide = New System.Windows.Forms.Button()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.lblBetelgeuse = New System.Windows.Forms.Label()
        Me.lblMeissa = New System.Windows.Forms.Label()
        Me.lblAlnitak = New System.Windows.Forms.Label()
        Me.lblAlnilam = New System.Windows.Forms.Label()
        Me.lblMintaka = New System.Windows.Forms.Label()
        Me.lblSaiph = New System.Windows.Forms.Label()
        Me.lblRigel = New System.Windows.Forms.Label()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(455, 153)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(455, 214)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(75, 23)
        Me.btnShow.TabIndex = 1
        Me.btnShow.Text = "Show stars"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'btnHide
        '
        Me.btnHide.Location = New System.Drawing.Point(455, 274)
        Me.btnHide.Name = "btnHide"
        Me.btnHide.Size = New System.Drawing.Size(75, 23)
        Me.btnHide.TabIndex = 2
        Me.btnHide.Text = "Hide stars"
        Me.btnHide.UseVisualStyleBackColor = True
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(12, 9)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(402, 430)
        Me.PictureBox1.TabIndex = 3
        Me.PictureBox1.TabStop = False
        '
        'lblBetelgeuse
        '
        Me.lblBetelgeuse.AutoSize = True
        Me.lblBetelgeuse.Location = New System.Drawing.Point(45, 44)
        Me.lblBetelgeuse.Name = "lblBetelgeuse"
        Me.lblBetelgeuse.Size = New System.Drawing.Size(60, 13)
        Me.lblBetelgeuse.TabIndex = 4
        Me.lblBetelgeuse.Text = "Betelgeuse"
        '
        'lblMeissa
        '
        Me.lblMeissa.AutoSize = True
        Me.lblMeissa.Location = New System.Drawing.Point(290, 65)
        Me.lblMeissa.Name = "lblMeissa"
        Me.lblMeissa.Size = New System.Drawing.Size(40, 13)
        Me.lblMeissa.TabIndex = 5
        Me.lblMeissa.Text = "Meissa"
        '
        'lblAlnitak
        '
        Me.lblAlnitak.AutoSize = True
        Me.lblAlnitak.Location = New System.Drawing.Point(90, 256)
        Me.lblAlnitak.Name = "lblAlnitak"
        Me.lblAlnitak.Size = New System.Drawing.Size(39, 13)
        Me.lblAlnitak.TabIndex = 6
        Me.lblAlnitak.Text = "Alnitak"
        '
        'lblAlnilam
        '
        Me.lblAlnilam.AutoSize = True
        Me.lblAlnilam.Location = New System.Drawing.Point(180, 240)
        Me.lblAlnilam.Name = "lblAlnilam"
        Me.lblAlnilam.Size = New System.Drawing.Size(40, 13)
        Me.lblAlnilam.TabIndex = 7
        Me.lblAlnilam.Text = "Alnilum"
        '
        'lblMintaka
        '
        Me.lblMintaka.AutoSize = True
        Me.lblMintaka.Location = New System.Drawing.Point(249, 214)
        Me.lblMintaka.Name = "lblMintaka"
        Me.lblMintaka.Size = New System.Drawing.Size(45, 13)
        Me.lblMintaka.TabIndex = 8
        Me.lblMintaka.Text = "Mintaka"
        '
        'lblSaiph
        '
        Me.lblSaiph.AutoSize = True
        Me.lblSaiph.Location = New System.Drawing.Point(90, 401)
        Me.lblSaiph.Name = "lblSaiph"
        Me.lblSaiph.Size = New System.Drawing.Size(34, 13)
        Me.lblSaiph.TabIndex = 9
        Me.lblSaiph.Text = "Saiph"
        '
        'lblRigel
        '
        Me.lblRigel.AutoSize = True
        Me.lblRigel.Location = New System.Drawing.Point(290, 368)
        Me.lblRigel.Name = "lblRigel"
        Me.lblRigel.Size = New System.Drawing.Size(31, 13)
        Me.lblRigel.TabIndex = 10
        Me.lblRigel.Text = "Rigel"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(583, 451)
        Me.Controls.Add(Me.lblRigel)
        Me.Controls.Add(Me.lblSaiph)
        Me.Controls.Add(Me.lblMintaka)
        Me.Controls.Add(Me.lblAlnilam)
        Me.Controls.Add(Me.lblAlnitak)
        Me.Controls.Add(Me.lblMeissa)
        Me.Controls.Add(Me.lblBetelgeuse)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnHide)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "Form1"
        Me.Text = "Orion Constellation"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnShow As Button
    Friend WithEvents btnHide As Button
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents lblBetelgeuse As Label
    Friend WithEvents lblMeissa As Label
    Friend WithEvents lblAlnitak As Label
    Friend WithEvents lblAlnilam As Label
    Friend WithEvents lblMintaka As Label
    Friend WithEvents lblSaiph As Label
    Friend WithEvents lblRigel As Label
End Class
