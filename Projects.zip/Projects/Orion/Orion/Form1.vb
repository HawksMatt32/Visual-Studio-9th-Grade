﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'Exits form
        Me.Close()

    End Sub

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        'makes all labels on image visible
        lblAlnilam.Visible = True
        lblAlnitak.Visible = True
        lblBetelgeuse.Visible = True
        lblMeissa.Visible = True
        lblRigel.Visible = True
        lblSaiph.Visible = True
        lblMintaka.Visible = True

    End Sub

    Private Sub btnHide_Click(sender As Object, e As EventArgs) Handles btnHide.Click
        'hides all labels what are on the image
        lblSaiph.Visible = False
        lblBetelgeuse.Visible = False
        lblAlnitak.Visible = False
        lblAlnilam.Visible = False
        lblRigel.Visible = False
        lblMeissa.Visible = False
        lblMintaka.Visible = False


    End Sub
End Class
