﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblDateStr = New System.Windows.Forms.Label()
        Me.lblYear = New System.Windows.Forms.Label()
        Me.lblDayOfMonth = New System.Windows.Forms.Label()
        Me.lblMonth = New System.Windows.Forms.Label()
        Me.lblDayOfWeek = New System.Windows.Forms.Label()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.txtYear = New System.Windows.Forms.TextBox()
        Me.txtDayOfMonth = New System.Windows.Forms.TextBox()
        Me.txtMonth = New System.Windows.Forms.TextBox()
        Me.txtDayOfWeek = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'lblDateStr
        '
        Me.lblDateStr.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDateStr.Location = New System.Drawing.Point(8, 178)
        Me.lblDateStr.Name = "lblDateStr"
        Me.lblDateStr.Size = New System.Drawing.Size(269, 23)
        Me.lblDateStr.TabIndex = 0
        Me.lblDateStr.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblYear
        '
        Me.lblYear.Location = New System.Drawing.Point(12, 130)
        Me.lblYear.Name = "lblYear"
        Me.lblYear.Size = New System.Drawing.Size(144, 23)
        Me.lblYear.TabIndex = 1
        Me.lblYear.Text = "Year:"
        Me.lblYear.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDayOfMonth
        '
        Me.lblDayOfMonth.Location = New System.Drawing.Point(12, 90)
        Me.lblDayOfMonth.Name = "lblDayOfMonth"
        Me.lblDayOfMonth.Size = New System.Drawing.Size(144, 23)
        Me.lblDayOfMonth.TabIndex = 2
        Me.lblDayOfMonth.Text = "Day of Current Month:"
        Me.lblDayOfMonth.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblMonth
        '
        Me.lblMonth.Location = New System.Drawing.Point(12, 48)
        Me.lblMonth.Name = "lblMonth"
        Me.lblMonth.Size = New System.Drawing.Size(144, 23)
        Me.lblMonth.TabIndex = 3
        Me.lblMonth.Text = "Month:"
        Me.lblMonth.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblDayOfWeek
        '
        Me.lblDayOfWeek.Location = New System.Drawing.Point(12, 13)
        Me.lblDayOfWeek.Name = "lblDayOfWeek"
        Me.lblDayOfWeek.Size = New System.Drawing.Size(144, 23)
        Me.lblDayOfWeek.TabIndex = 4
        Me.lblDayOfWeek.Text = "Day of Week:"
        Me.lblDayOfWeek.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(8, 209)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(75, 23)
        Me.btnShow.TabIndex = 5
        Me.btnShow.Text = "Show Date"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(105, 209)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 6
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(202, 209)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 7
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'txtYear
        '
        Me.txtYear.Location = New System.Drawing.Point(162, 130)
        Me.txtYear.Name = "txtYear"
        Me.txtYear.Size = New System.Drawing.Size(100, 20)
        Me.txtYear.TabIndex = 8
        '
        'txtDayOfMonth
        '
        Me.txtDayOfMonth.Location = New System.Drawing.Point(162, 90)
        Me.txtDayOfMonth.Name = "txtDayOfMonth"
        Me.txtDayOfMonth.Size = New System.Drawing.Size(100, 20)
        Me.txtDayOfMonth.TabIndex = 9
        '
        'txtMonth
        '
        Me.txtMonth.Location = New System.Drawing.Point(162, 51)
        Me.txtMonth.Name = "txtMonth"
        Me.txtMonth.Size = New System.Drawing.Size(100, 20)
        Me.txtMonth.TabIndex = 10
        '
        'txtDayOfWeek
        '
        Me.txtDayOfWeek.Location = New System.Drawing.Point(162, 21)
        Me.txtDayOfWeek.Name = "txtDayOfWeek"
        Me.txtDayOfWeek.Size = New System.Drawing.Size(100, 20)
        Me.txtDayOfWeek.TabIndex = 11
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.txtDayOfWeek)
        Me.Controls.Add(Me.txtMonth)
        Me.Controls.Add(Me.txtDayOfMonth)
        Me.Controls.Add(Me.txtYear)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.lblDayOfWeek)
        Me.Controls.Add(Me.lblMonth)
        Me.Controls.Add(Me.lblDayOfMonth)
        Me.Controls.Add(Me.lblYear)
        Me.Controls.Add(Me.lblDateStr)
        Me.Name = "Form1"
        Me.Text = "Date String"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblDateStr As Label
    Friend WithEvents lblYear As Label
    Friend WithEvents lblDayOfMonth As Label
    Friend WithEvents lblMonth As Label
    Friend WithEvents lblDayOfWeek As Label
    Friend WithEvents btnShow As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents txtYear As TextBox
    Friend WithEvents txtDayOfMonth As TextBox
    Friend WithEvents txtMonth As TextBox
    Friend WithEvents txtDayOfWeek As TextBox
End Class
