﻿Public Class Form1
    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        'concatenate the input and build the date string
        lblDateStr.Text = txtDayOfWeek.Text & ", " & txtMonth.Text & ", " & txtDayOfMonth.Text & ", " & txtYear.Text

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears text boxes and output
        lblDateStr.Text = String.Empty
        txtDayOfMonth.Clear()
        txtDayOfWeek.Clear()
        txtMonth.Clear()
        txtYear.Clear()



    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles txtDayOfWeek.TextChanged

    End Sub

    Private Sub lblMonth_Click(sender As Object, e As EventArgs) Handles lblMonth.Click

    End Sub

    Private Sub lblYear_Click(sender As Object, e As EventArgs) Handles lblYear.Click

    End Sub

    Private Sub lblDayOfMonth_Click(sender As Object, e As EventArgs) Handles lblDayOfMonth.Click

    End Sub

    Private Sub lblDayOfWeek_Click(sender As Object, e As EventArgs) Handles lblDayOfWeek.Click

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class
