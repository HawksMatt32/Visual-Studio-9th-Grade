﻿Public Class Form1
    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        'Shows math answer
        lblMath.Text = "6 + 4 = 10"
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'exits program
        Me.Close()
    End Sub
End Class
