﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        'built in error handling
        If lstOut.Items.Count > 10 Then
            MessageBox.Show("You already see the numbers buddy.")
        Else
            'variable declaration
            Dim lngA As Long = 0
            Dim lngB As Long = 1
            Dim lngFib As Long
            'displays some output
            lstOut.Items.Add("1")
            'while number less than target then continue adding
            Do While lngFib < 12586269025
                lngFib = lngA + lngB
                lngA = lngB
                lngB = lngFib
                'display
                lstOut.Items.Add(CStr(lngFib))

            Loop
        End If


    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears list box
        lstOut.Items.Clear()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub
End Class