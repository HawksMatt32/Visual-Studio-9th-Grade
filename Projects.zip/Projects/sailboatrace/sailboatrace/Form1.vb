﻿Public Class Form1
    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        Try
            'tie handling    testing if textboxes are equal
            If txt11.Text = txt21.Text Or txt21.Text = txt31.Text Or txt31.Text = txt11.Text Then
                If txt12.Text = txt22.Text Or txt22.Text = txt32.Text Or txt32.Text = txt12.Text Then
                    If txt13.Text = txt23.Text Or txt23.Text = txt33.Text Or txt33.Text = txt13.Text Then
                        If txt14.Text = txt24.Text Or txt24.Text = txt34.Text Or txt34.Text = txt14.Text Then
                            lblRank1.BackColor = Color.Red
                            lblRank2.BackColor = Color.Red
                            lblRank3.BackColor = Color.Red
                        End If
                    End If
                End If
            End If
            'var9able calling and some math

            Dim intBoatOneTotal As Integer = CInt(txt11.Text) + CInt(txt12.Text) + CInt(txt13.Text) + CInt(txt14.Text)
            Dim intBoatTwoTotal As Integer = CInt(txt21.Text) + CInt(txt22.Text) + CInt(txt23.Text) + CInt(txt24.Text)
            Dim intBoatThreeTotal As Integer = CInt(txt31.Text) + CInt(txt32.Text) + CInt(txt33.Text) + CInt(txt34.Text)
            'show math
            lblOneTotal.Text = intBoatOneTotal.ToString
            lblTwoTotal.Text = intBoatTwoTotal.ToString
            lblThreeTotal.Text = intBoatThreeTotal.ToString
            'more variable calling
            Dim int11 As Integer
            Dim int21 As Integer
            Dim int31 As Integer
            Dim int12 As Integer
            Dim int22 As Integer
            Dim int32 As Integer
            Dim int13 As Integer
            Dim int23 As Integer
            Dim int33 As Integer
            Dim int14 As Integer
            Dim int24 As Integer
            Dim int34 As Integer
            'pogger parsing
            If Integer.TryParse(txt11.Text, int11) Then
                If Integer.TryParse(txt21.Text, int21) Then
                    If Integer.TryParse(txt31.Text, int31) Then
                        If Integer.TryParse(txt12.Text, int12) Then
                            If Integer.TryParse(txt22.Text, int22) Then
                                If Integer.TryParse(txt32.Text, int32) Then
                                    If Integer.TryParse(txt13.Text, int13) Then
                                        If Integer.TryParse(txt23.Text, int23) Then
                                            If Integer.TryParse(txt33.Text, int33) Then
                                                If Integer.TryParse(txt14.Text, int14) Then
                                                    If Integer.TryParse(txt24.Text, int24) Then
                                                        If Integer.TryParse(txt34.Text, int34) Then
                                                            'tests if row affs to 6
                                                            If int11 + int21 + int31 = 6 Then
                                                                MessageBox.Show("first phase completed")
                                                                If int12 + int22 + int32 = 6 Then
                                                                    MessageBox.Show("second phase completed")
                                                                    If int13 + int23 + int33 = 6 Then
                                                                        MessageBox.Show("third phase completed")
                                                                        If int14 + int24 + int34 = 6 Then
                                                                            MessageBox.Show("fourth phase completed")
                                                                            'sorting apparatus zed then it shows it
                                                                            If intBoatOneTotal > intBoatTwoTotal And intBoatTwoTotal > intBoatThreeTotal Then '
                                                                                lblRank1.Text = "3"
                                                                                If intBoatOneTotal > intBoatThreeTotal Then
                                                                                    lblRank2.Text = "2"
                                                                                    lblRank3.Text = "1"

                                                                                End If
                                                                            End If
                                                                            If intBoatTwoTotal > intBoatThreeTotal And intBoatThreeTotal > intBoatOneTotal Then
                                                                                lblRank2.Text = "3"
                                                                                If intBoatTwoTotal > intBoatOneTotal Then
                                                                                    lblRank1.Text = "1"
                                                                                    lblRank3.Text = "2"
                                                                                End If

                                                                            End If
                                                                            If intBoatThreeTotal > intBoatOneTotal And intBoatOneTotal > intBoatTwoTotal Then
                                                                                lblRank3.Text = "3"
                                                                                If intBoatThreeTotal > intBoatTwoTotal Then
                                                                                    lblRank2.Text = "1"
                                                                                    lblRank1.Text = "2"
                                                                                End If
                                                                            End If
                                                                        Else
                                                                            'apparatus one its just sorting it mannnn
                                                                            'shows its a tie
                                                                            sts.Text = "tie"
                                                                            lblRank1.BackColor = Color.Red
                                                                            lblRank2.BackColor = Color.Red
                                                                            lblRank3.BackColor = Color.Red
                                                                            If intBoatOneTotal > intBoatTwoTotal And intBoatTwoTotal > intBoatThreeTotal Then '
                                                                                lblRank1.Text = "3"
                                                                                If intBoatOneTotal > intBoatThreeTotal Then
                                                                                    lblRank2.Text = "2"
                                                                                    lblRank3.Text = "1"

                                                                                End If
                                                                            End If
                                                                            If intBoatTwoTotal > intBoatThreeTotal And intBoatThreeTotal > intBoatOneTotal Then
                                                                                lblRank2.Text = "3"
                                                                                If intBoatTwoTotal > intBoatOneTotal Then
                                                                                    lblRank1.Text = "1"
                                                                                    lblRank3.Text = "2"
                                                                                End If

                                                                            End If
                                                                            If intBoatThreeTotal > intBoatOneTotal And intBoatOneTotal > intBoatTwoTotal Then
                                                                                lblRank3.Text = "3"
                                                                                If intBoatThreeTotal > intBoatTwoTotal Then
                                                                                    lblRank2.Text = "1"
                                                                                    lblRank1.Text = "2"
                                                                                End If
                                                                            End If
                                                                        End If


                                                                    Else
                                                                        'apparatus two its just sorting it mannnn
                                                                        'shows its a tie
                                                                        sts.Text = "tie"
                                                                        lblRank1.BackColor = Color.Red
                                                                        lblRank2.BackColor = Color.Red
                                                                        lblRank3.BackColor = Color.Red
                                                                        If intBoatOneTotal > intBoatTwoTotal And intBoatTwoTotal > intBoatThreeTotal Then '
                                                                            lblRank1.Text = "3"
                                                                            If intBoatOneTotal > intBoatThreeTotal Then
                                                                                lblRank2.Text = "2"
                                                                                lblRank3.Text = "1"

                                                                            End If
                                                                        End If
                                                                        If intBoatTwoTotal > intBoatThreeTotal And intBoatThreeTotal > intBoatOneTotal Then
                                                                            lblRank2.Text = "3"
                                                                            If intBoatTwoTotal > intBoatOneTotal Then
                                                                                lblRank1.Text = "1"
                                                                                lblRank3.Text = "2"
                                                                            End If

                                                                        End If
                                                                        If intBoatThreeTotal > intBoatOneTotal And intBoatOneTotal > intBoatTwoTotal Then
                                                                            lblRank3.Text = "3"
                                                                            If intBoatThreeTotal > intBoatTwoTotal Then
                                                                                lblRank2.Text = "1"
                                                                                lblRank1.Text = "2"
                                                                            End If
                                                                        End If
                                                                    End If
                                                                Else
                                                                    'apparatus three its just sorting it mannnn
                                                                    'shows its a tie
                                                                    sts.Text = "tie"
                                                                    lblRank1.BackColor = Color.Red
                                                                    lblRank2.BackColor = Color.Red
                                                                    lblRank3.BackColor = Color.Red
                                                                    If intBoatOneTotal > intBoatTwoTotal And intBoatTwoTotal > intBoatThreeTotal Then '
                                                                        lblRank1.Text = "3"
                                                                        If intBoatOneTotal > intBoatThreeTotal Then
                                                                            lblRank2.Text = "2"
                                                                            lblRank3.Text = "1"

                                                                        End If
                                                                    End If
                                                                    If intBoatTwoTotal > intBoatThreeTotal And intBoatThreeTotal > intBoatOneTotal Then
                                                                        lblRank2.Text = "3"
                                                                        If intBoatTwoTotal > intBoatOneTotal Then
                                                                            lblRank1.Text = "1"
                                                                            lblRank3.Text = "2"
                                                                        End If

                                                                    End If
                                                                    If intBoatThreeTotal > intBoatOneTotal And intBoatOneTotal > intBoatTwoTotal Then
                                                                        lblRank3.Text = "3"
                                                                        If intBoatThreeTotal > intBoatTwoTotal Then
                                                                            lblRank2.Text = "1"
                                                                            lblRank1.Text = "2"
                                                                        End If
                                                                    End If
                                                                End If
                                                            Else
                                                                'apparatus four its just sorting it mannnn
                                                                'shows its a tie
                                                                sts.Text = "tie"
                                                                lblRank1.BackColor = Color.Red
                                                                lblRank2.BackColor = Color.Red
                                                                lblRank3.BackColor = Color.Red
                                                                If intBoatOneTotal > intBoatTwoTotal And intBoatTwoTotal > intBoatThreeTotal Then '
                                                                    lblRank1.Text = "3"
                                                                    If intBoatOneTotal > intBoatThreeTotal Then
                                                                        lblRank2.Text = "2"
                                                                        lblRank3.Text = "1"

                                                                    End If
                                                                End If
                                                                If intBoatTwoTotal > intBoatThreeTotal And intBoatThreeTotal > intBoatOneTotal Then
                                                                    lblRank2.Text = "3"
                                                                    If intBoatTwoTotal > intBoatOneTotal Then
                                                                        lblRank1.Text = "1"
                                                                        lblRank3.Text = "2"
                                                                    End If

                                                                End If
                                                                If intBoatThreeTotal > intBoatOneTotal And intBoatOneTotal > intBoatTwoTotal Then
                                                                    lblRank3.Text = "3"
                                                                    If intBoatThreeTotal > intBoatTwoTotal Then
                                                                        lblRank2.Text = "1"
                                                                        lblRank1.Text = "2"
                                                                    End If
                                                                End If
                                                            End If
                                                        End If
                                                    End If
                                                End If
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                        End If
                    End If
                End If
            End If

        Catch ex As Exception
            sts.Text = "Invalid input"

        End Try
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears input and output
        txt11.Clear()
        txt12.Clear()
        txt13.Clear()
        txt14.Clear()
        txt21.Clear()
        txt22.Clear()
        txt23.Clear()
        txt24.Clear()
        txt31.Clear()
        txt32.Clear()
        txt33.Clear()
        txt34.Clear()
        lblOneTotal.Text = ""
        lblTwoTotal.Text = ""
        lblThreeTotal.Text = ""
        lblRank1.Text = ""
        lblRank2.Text = ""
        lblRank3.Text = ""

        lblRank3.BackColor = Color.Transparent
        lblRank2.BackColor = Color.Transparent
        lblRank1.BackColor = Color.Transparent
        sts.Text = String.Empty



    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class
