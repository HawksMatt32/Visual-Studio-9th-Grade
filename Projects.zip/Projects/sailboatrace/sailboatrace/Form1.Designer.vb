﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.lblRank3 = New System.Windows.Forms.Label()
        Me.lblRank2 = New System.Windows.Forms.Label()
        Me.lblRank1 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.stsError = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.sts = New System.Windows.Forms.ToolStripStatusLabel()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.lblOneTotal = New System.Windows.Forms.Label()
        Me.lblTwoTotal = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblThreeTotal = New System.Windows.Forms.Label()
        Me.txt14 = New System.Windows.Forms.TextBox()
        Me.txt24 = New System.Windows.Forms.TextBox()
        Me.txt34 = New System.Windows.Forms.TextBox()
        Me.txt13 = New System.Windows.Forms.TextBox()
        Me.txt23 = New System.Windows.Forms.TextBox()
        Me.txt33 = New System.Windows.Forms.TextBox()
        Me.txt12 = New System.Windows.Forms.TextBox()
        Me.txt22 = New System.Windows.Forms.TextBox()
        Me.txt32 = New System.Windows.Forms.TextBox()
        Me.txt11 = New System.Windows.Forms.TextBox()
        Me.txt31 = New System.Windows.Forms.TextBox()
        Me.txt21 = New System.Windows.Forms.TextBox()
        Me.GroupBox1.SuspendLayout()
        Me.stsError.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.GroupBox1.Controls.Add(Me.lblRank3)
        Me.GroupBox1.Controls.Add(Me.lblRank2)
        Me.GroupBox1.Controls.Add(Me.lblRank1)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.stsError)
        Me.GroupBox1.Controls.Add(Me.btnShow)
        Me.GroupBox1.Controls.Add(Me.btnClear)
        Me.GroupBox1.Controls.Add(Me.btnClose)
        Me.GroupBox1.Controls.Add(Me.lblOneTotal)
        Me.GroupBox1.Controls.Add(Me.lblTwoTotal)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.lblThreeTotal)
        Me.GroupBox1.Controls.Add(Me.txt14)
        Me.GroupBox1.Controls.Add(Me.txt24)
        Me.GroupBox1.Controls.Add(Me.txt34)
        Me.GroupBox1.Controls.Add(Me.txt13)
        Me.GroupBox1.Controls.Add(Me.txt23)
        Me.GroupBox1.Controls.Add(Me.txt33)
        Me.GroupBox1.Controls.Add(Me.txt12)
        Me.GroupBox1.Controls.Add(Me.txt22)
        Me.GroupBox1.Controls.Add(Me.txt32)
        Me.GroupBox1.Controls.Add(Me.txt11)
        Me.GroupBox1.Controls.Add(Me.txt31)
        Me.GroupBox1.Controls.Add(Me.txt21)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(0, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(549, 219)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Race Results"
        '
        'lblRank3
        '
        Me.lblRank3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank3.Location = New System.Drawing.Point(386, 118)
        Me.lblRank3.Name = "lblRank3"
        Me.lblRank3.Size = New System.Drawing.Size(58, 23)
        Me.lblRank3.TabIndex = 1
        '
        'lblRank2
        '
        Me.lblRank2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank2.Location = New System.Drawing.Point(386, 92)
        Me.lblRank2.Name = "lblRank2"
        Me.lblRank2.Size = New System.Drawing.Size(58, 23)
        Me.lblRank2.TabIndex = 2
        '
        'lblRank1
        '
        Me.lblRank1.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.lblRank1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRank1.Location = New System.Drawing.Point(386, 66)
        Me.lblRank1.Name = "lblRank1"
        Me.lblRank1.Size = New System.Drawing.Size(58, 23)
        Me.lblRank1.TabIndex = 3
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(383, 46)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(37, 13)
        Me.Label12.TabIndex = 4
        Me.Label12.Text = "Rank"
        '
        'stsError
        '
        Me.stsError.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.sts})
        Me.stsError.Location = New System.Drawing.Point(3, 194)
        Me.stsError.Name = "stsError"
        Me.stsError.Size = New System.Drawing.Size(543, 22)
        Me.stsError.TabIndex = 26
        Me.stsError.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(0, 17)
        '
        'sts
        '
        Me.sts.Name = "sts"
        Me.sts.Size = New System.Drawing.Size(0, 17)
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(63, 167)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(75, 23)
        Me.btnShow.TabIndex = 12
        Me.btnShow.Text = "Show Totals"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(200, 167)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 13
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(325, 167)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 14
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'lblOneTotal
        '
        Me.lblOneTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOneTotal.Location = New System.Drawing.Point(325, 66)
        Me.lblOneTotal.Name = "lblOneTotal"
        Me.lblOneTotal.Size = New System.Drawing.Size(58, 23)
        Me.lblOneTotal.TabIndex = 22
        '
        'lblTwoTotal
        '
        Me.lblTwoTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTwoTotal.Location = New System.Drawing.Point(325, 92)
        Me.lblTwoTotal.Name = "lblTwoTotal"
        Me.lblTwoTotal.Size = New System.Drawing.Size(58, 23)
        Me.lblTwoTotal.TabIndex = 21
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(267, 46)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 20
        Me.Label9.Text = "Race 4"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(211, 46)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 19
        Me.Label8.Text = "Race 3"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(322, 46)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(36, 13)
        Me.Label7.TabIndex = 18
        Me.Label7.Text = "Total"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(43, 75)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Boat 1"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(155, 46)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(48, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Race 2"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(99, 46)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(48, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Race 1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(43, 101)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(44, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Boat 2"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(43, 127)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(44, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Boat 3"
        '
        'lblThreeTotal
        '
        Me.lblThreeTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblThreeTotal.Location = New System.Drawing.Point(325, 118)
        Me.lblThreeTotal.Name = "lblThreeTotal"
        Me.lblThreeTotal.Size = New System.Drawing.Size(58, 23)
        Me.lblThreeTotal.TabIndex = 12
        '
        'txt14
        '
        Me.txt14.Location = New System.Drawing.Point(256, 72)
        Me.txt14.Name = "txt14"
        Me.txt14.Size = New System.Drawing.Size(50, 20)
        Me.txt14.TabIndex = 9
        '
        'txt24
        '
        Me.txt24.Location = New System.Drawing.Point(256, 98)
        Me.txt24.Name = "txt24"
        Me.txt24.Size = New System.Drawing.Size(50, 20)
        Me.txt24.TabIndex = 10
        '
        'txt34
        '
        Me.txt34.Location = New System.Drawing.Point(256, 124)
        Me.txt34.Name = "txt34"
        Me.txt34.Size = New System.Drawing.Size(50, 20)
        Me.txt34.TabIndex = 11
        '
        'txt13
        '
        Me.txt13.Location = New System.Drawing.Point(200, 72)
        Me.txt13.Name = "txt13"
        Me.txt13.Size = New System.Drawing.Size(50, 20)
        Me.txt13.TabIndex = 6
        '
        'txt23
        '
        Me.txt23.Location = New System.Drawing.Point(200, 98)
        Me.txt23.Name = "txt23"
        Me.txt23.Size = New System.Drawing.Size(50, 20)
        Me.txt23.TabIndex = 7
        '
        'txt33
        '
        Me.txt33.Location = New System.Drawing.Point(200, 124)
        Me.txt33.Name = "txt33"
        Me.txt33.Size = New System.Drawing.Size(50, 20)
        Me.txt33.TabIndex = 8
        '
        'txt12
        '
        Me.txt12.Location = New System.Drawing.Point(144, 72)
        Me.txt12.Name = "txt12"
        Me.txt12.Size = New System.Drawing.Size(50, 20)
        Me.txt12.TabIndex = 3
        '
        'txt22
        '
        Me.txt22.Location = New System.Drawing.Point(144, 98)
        Me.txt22.Name = "txt22"
        Me.txt22.Size = New System.Drawing.Size(50, 20)
        Me.txt22.TabIndex = 4
        '
        'txt32
        '
        Me.txt32.Location = New System.Drawing.Point(144, 124)
        Me.txt32.Name = "txt32"
        Me.txt32.Size = New System.Drawing.Size(50, 20)
        Me.txt32.TabIndex = 5
        '
        'txt11
        '
        Me.txt11.Location = New System.Drawing.Point(88, 72)
        Me.txt11.Name = "txt11"
        Me.txt11.Size = New System.Drawing.Size(50, 20)
        Me.txt11.TabIndex = 0
        '
        'txt31
        '
        Me.txt31.Location = New System.Drawing.Point(88, 124)
        Me.txt31.Name = "txt31"
        Me.txt31.Size = New System.Drawing.Size(50, 20)
        Me.txt31.TabIndex = 2
        '
        'txt21
        '
        Me.txt21.Location = New System.Drawing.Point(88, 98)
        Me.txt21.Name = "txt21"
        Me.txt21.Size = New System.Drawing.Size(50, 20)
        Me.txt21.TabIndex = 1
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(548, 223)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "sailboat"
        Me.TopMost = True
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.stsError.ResumeLayout(False)
        Me.stsError.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents stsError As StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As ToolStripStatusLabel
    Friend WithEvents btnShow As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents lblOneTotal As Label
    Friend WithEvents lblTwoTotal As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblThreeTotal As Label
    Friend WithEvents txt14 As TextBox
    Friend WithEvents txt24 As TextBox
    Friend WithEvents txt34 As TextBox
    Friend WithEvents txt13 As TextBox
    Friend WithEvents txt23 As TextBox
    Friend WithEvents txt33 As TextBox
    Friend WithEvents txt12 As TextBox
    Friend WithEvents txt22 As TextBox
    Friend WithEvents txt32 As TextBox
    Friend WithEvents txt11 As TextBox
    Friend WithEvents txt31 As TextBox
    Friend WithEvents txt21 As TextBox
    Friend WithEvents sts As ToolStripStatusLabel
    Friend WithEvents lblRank3 As Label
    Friend WithEvents lblRank2 As Label
    Friend WithEvents lblRank1 As Label
    Friend WithEvents Label12 As Label
End Class
