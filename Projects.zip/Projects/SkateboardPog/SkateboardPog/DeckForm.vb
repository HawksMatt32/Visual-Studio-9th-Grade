﻿Public Class DeckForm
    Private Sub btnDictatorOfGrind_CheckedChanged(sender As Object, e As EventArgs) Handles radDictatorOfGrind.CheckedChanged

    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If radDictatorOfGrind.Checked = True Or radMasterThrasher.Checked = True Or radStreetKing.Checked = True Then
            TruckForm.ShowDialog()
        Else
            MessageBox.Show("click one")
        End If
    End Sub
End Class