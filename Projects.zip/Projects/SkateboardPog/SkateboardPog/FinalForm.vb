﻿Public Class FinalForm
    Private Sub FinalForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        decTotal = 0
        decMisctotal = 0
        decDeckTotal = 0
        decTruckTotal = 0
        decWheelTotal = 0
        decTax = 0
        decSubtotal = 0
        CalcDeckTotal()
        CalcMiscTotal()
        CalcTruckTotal()
        CalcWheelTotal()
        decSubtotal = decDeckTotal + decMisctotal + decWheelTotal + decTruckTotal
        decTax = decSubtotal * decTAX_RATE
        decTotal = decTax + decSubtotal
        lblSubtotal.Text = decSubtotal.ToString("C")
        lblTax.Text = decTax.ToString("C")
        lblTotal.Text = decTotal.ToString("C")
    End Sub

    Private Sub btnRestart_Click(sender As Object, e As EventArgs) Handles btnRestart.Click
        MiscForm.Close()
        DeckForm.Close()
        TruckForm.Close()
        WheelForm.Close()
        Me.Close()

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        MiscForm.Close()
        DeckForm.Close()
        TruckForm.Close()
        WheelForm.Close()
        MainForm.Close()
        Me.Close()

    End Sub
End Class