﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class WheelForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rad55mm = New System.Windows.Forms.RadioButton()
        Me.rad51mm = New System.Windows.Forms.RadioButton()
        Me.rad58mm = New System.Windows.Forms.RadioButton()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.rad61mm = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'rad55mm
        '
        Me.rad55mm.AutoSize = True
        Me.rad55mm.Location = New System.Drawing.Point(8, 31)
        Me.rad55mm.Name = "rad55mm"
        Me.rad55mm.Size = New System.Drawing.Size(53, 17)
        Me.rad55mm.TabIndex = 0
        Me.rad55mm.TabStop = True
        Me.rad55mm.Text = "55mm"
        Me.rad55mm.UseVisualStyleBackColor = True
        '
        'rad51mm
        '
        Me.rad51mm.AutoSize = True
        Me.rad51mm.Location = New System.Drawing.Point(8, 8)
        Me.rad51mm.Name = "rad51mm"
        Me.rad51mm.Size = New System.Drawing.Size(53, 17)
        Me.rad51mm.TabIndex = 1
        Me.rad51mm.TabStop = True
        Me.rad51mm.Text = "51mm"
        Me.rad51mm.UseVisualStyleBackColor = True
        '
        'rad58mm
        '
        Me.rad58mm.AutoSize = True
        Me.rad58mm.Location = New System.Drawing.Point(8, 54)
        Me.rad58mm.Name = "rad58mm"
        Me.rad58mm.Size = New System.Drawing.Size(53, 17)
        Me.rad58mm.TabIndex = 2
        Me.rad58mm.TabStop = True
        Me.rad58mm.Text = "58mm"
        Me.rad58mm.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(138, 38)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(75, 23)
        Me.btnNext.TabIndex = 3
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'rad61mm
        '
        Me.rad61mm.AutoSize = True
        Me.rad61mm.Location = New System.Drawing.Point(8, 77)
        Me.rad61mm.Name = "rad61mm"
        Me.rad61mm.Size = New System.Drawing.Size(53, 17)
        Me.rad61mm.TabIndex = 4
        Me.rad61mm.TabStop = True
        Me.rad61mm.Text = "61mm"
        Me.rad61mm.UseVisualStyleBackColor = True
        '
        'WheelForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(243, 100)
        Me.Controls.Add(Me.rad61mm)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.rad58mm)
        Me.Controls.Add(Me.rad51mm)
        Me.Controls.Add(Me.rad55mm)
        Me.Name = "WheelForm"
        Me.Text = "Drip out those wheels"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rad55mm As RadioButton
    Friend WithEvents rad51mm As RadioButton
    Friend WithEvents rad58mm As RadioButton
    Friend WithEvents btnNext As Button
    Friend WithEvents rad61mm As RadioButton
End Class
