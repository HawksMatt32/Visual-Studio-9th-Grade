﻿Module EpicFun
    Public Const decTAX_RATE As Decimal = 0.06D
    Public decMisctotal As Decimal
    Public decDeckTotal As Decimal
    Public decTruckTotal As Decimal
    Public decWheelTotal As Decimal
    Public decSubtotal As Decimal
    Public decTax As Decimal
    Public decTotal As Decimal
    Sub CalcMiscTotal()
        If MiscForm.chkGripTape.Checked = True Then
            decMisctotal += 10
        End If
        If MiscForm.chkBearings.Checked = True Then
            decMisctotal += 30
        End If
        If MiscForm.chkRiserPads.Checked = True Then
            decMisctotal += 2
        End If
        If MiscForm.chkNutsAndBoltsKit.Checked = True Then
            decMisctotal += 3
        End If
        If MiscForm.chkAssembly.Checked = True Then
            decMisctotal += 10
        End If
    End Sub
    Sub CalcDeckTotal()
        If DeckForm.radMasterThrasher.Checked Then
            decDeckTotal += 60
        End If
        If DeckForm.radDictatorOfGrind.Checked Then
            decDeckTotal += 45
        End If
        If DeckForm.radStreetKing.Checked Then
            decDeckTotal += 50
        End If
    End Sub
    Sub CalcTruckTotal()
        If TruckForm.rad775.Checked Then
            decTruckTotal += 35
        End If
        If TruckForm.rad8.Checked Then
            decTruckTotal += 40
        End If
        If TruckForm.rad85.Checked Then
            decTruckTotal += 45
        End If
    End Sub
    Sub CalcWheelTotal()
        If WheelForm.rad51mm.Checked Then
            decWheelTotal += 20
        End If
        If WheelForm.rad55mm.Checked Then
            decWheelTotal += 22
        End If
        If WheelForm.rad58mm.Checked Then
            decWheelTotal += 24
        End If
        If WheelForm.rad61mm.Checked Then
            decWheelTotal += 28
        End If
    End Sub

End Module
