﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TruckForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.rad775 = New System.Windows.Forms.RadioButton()
        Me.rad8 = New System.Windows.Forms.RadioButton()
        Me.rad85 = New System.Windows.Forms.RadioButton()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'rad775
        '
        Me.rad775.AutoSize = True
        Me.rad775.Location = New System.Drawing.Point(12, 9)
        Me.rad775.Name = "rad775"
        Me.rad775.Size = New System.Drawing.Size(69, 17)
        Me.rad775.TabIndex = 0
        Me.rad775.TabStop = True
        Me.rad775.Text = "7.75 Axle"
        Me.rad775.UseVisualStyleBackColor = True
        '
        'rad8
        '
        Me.rad8.AutoSize = True
        Me.rad8.Location = New System.Drawing.Point(12, 32)
        Me.rad8.Name = "rad8"
        Me.rad8.Size = New System.Drawing.Size(54, 17)
        Me.rad8.TabIndex = 1
        Me.rad8.TabStop = True
        Me.rad8.Text = "8 Axle"
        Me.rad8.UseVisualStyleBackColor = True
        '
        'rad85
        '
        Me.rad85.AutoSize = True
        Me.rad85.Location = New System.Drawing.Point(12, 55)
        Me.rad85.Name = "rad85"
        Me.rad85.Size = New System.Drawing.Size(63, 17)
        Me.rad85.TabIndex = 2
        Me.rad85.TabStop = True
        Me.rad85.Text = "8.5 Axle"
        Me.rad85.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(149, 29)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(75, 23)
        Me.btnNext.TabIndex = 3
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'TruckForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(246, 82)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.rad85)
        Me.Controls.Add(Me.rad8)
        Me.Controls.Add(Me.rad775)
        Me.Name = "TruckForm"
        Me.Text = "Customize your truck"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents rad775 As RadioButton
    Friend WithEvents rad8 As RadioButton
    Friend WithEvents rad85 As RadioButton
    Friend WithEvents btnNext As Button
End Class
