﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DeckForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.radMasterThrasher = New System.Windows.Forms.RadioButton()
        Me.radStreetKing = New System.Windows.Forms.RadioButton()
        Me.radDictatorOfGrind = New System.Windows.Forms.RadioButton()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'radMasterThrasher
        '
        Me.radMasterThrasher.AutoSize = True
        Me.radMasterThrasher.Location = New System.Drawing.Point(12, 6)
        Me.radMasterThrasher.Name = "radMasterThrasher"
        Me.radMasterThrasher.Size = New System.Drawing.Size(124, 17)
        Me.radMasterThrasher.TabIndex = 0
        Me.radMasterThrasher.TabStop = True
        Me.radMasterThrasher.Text = "The Master Thrasher"
        Me.radMasterThrasher.UseVisualStyleBackColor = True
        '
        'radStreetKing
        '
        Me.radStreetKing.AutoSize = True
        Me.radStreetKing.Location = New System.Drawing.Point(12, 29)
        Me.radStreetKing.Name = "radStreetKing"
        Me.radStreetKing.Size = New System.Drawing.Size(99, 17)
        Me.radStreetKing.TabIndex = 1
        Me.radStreetKing.TabStop = True
        Me.radStreetKing.Text = "The Street King"
        Me.radStreetKing.UseVisualStyleBackColor = True
        '
        'radDictatorOfGrind
        '
        Me.radDictatorOfGrind.AutoSize = True
        Me.radDictatorOfGrind.Location = New System.Drawing.Point(12, 52)
        Me.radDictatorOfGrind.Name = "radDictatorOfGrind"
        Me.radDictatorOfGrind.Size = New System.Drawing.Size(124, 17)
        Me.radDictatorOfGrind.TabIndex = 2
        Me.radDictatorOfGrind.TabStop = True
        Me.radDictatorOfGrind.Text = "The Dictator of Grind"
        Me.radDictatorOfGrind.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(169, 25)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(75, 23)
        Me.btnNext.TabIndex = 3
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'DeckForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(256, 72)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.radDictatorOfGrind)
        Me.Controls.Add(Me.radStreetKing)
        Me.Controls.Add(Me.radMasterThrasher)
        Me.Name = "DeckForm"
        Me.Text = "Customize your deck"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents radMasterThrasher As RadioButton
    Friend WithEvents radStreetKing As RadioButton
    Friend WithEvents radDictatorOfGrind As RadioButton
    Friend WithEvents btnNext As Button
End Class
