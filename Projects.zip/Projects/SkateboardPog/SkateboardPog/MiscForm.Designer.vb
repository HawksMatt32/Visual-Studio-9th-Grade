﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MiscForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkGripTape = New System.Windows.Forms.CheckBox()
        Me.chkBearings = New System.Windows.Forms.CheckBox()
        Me.chkAssembly = New System.Windows.Forms.CheckBox()
        Me.chkRiserPads = New System.Windows.Forms.CheckBox()
        Me.chkNutsAndBoltsKit = New System.Windows.Forms.CheckBox()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'chkGripTape
        '
        Me.chkGripTape.AutoSize = True
        Me.chkGripTape.Location = New System.Drawing.Point(12, 12)
        Me.chkGripTape.Name = "chkGripTape"
        Me.chkGripTape.Size = New System.Drawing.Size(73, 17)
        Me.chkGripTape.TabIndex = 0
        Me.chkGripTape.Text = "Grip Tape"
        Me.chkGripTape.UseVisualStyleBackColor = True
        '
        'chkBearings
        '
        Me.chkBearings.AutoSize = True
        Me.chkBearings.Location = New System.Drawing.Point(12, 35)
        Me.chkBearings.Name = "chkBearings"
        Me.chkBearings.Size = New System.Drawing.Size(67, 17)
        Me.chkBearings.TabIndex = 1
        Me.chkBearings.Text = "Bearings"
        Me.chkBearings.UseVisualStyleBackColor = True
        '
        'chkAssembly
        '
        Me.chkAssembly.AutoSize = True
        Me.chkAssembly.Location = New System.Drawing.Point(12, 104)
        Me.chkAssembly.Name = "chkAssembly"
        Me.chkAssembly.Size = New System.Drawing.Size(70, 17)
        Me.chkAssembly.TabIndex = 2
        Me.chkAssembly.Text = "Assembly"
        Me.chkAssembly.UseVisualStyleBackColor = True
        '
        'chkRiserPads
        '
        Me.chkRiserPads.AutoSize = True
        Me.chkRiserPads.Location = New System.Drawing.Point(12, 58)
        Me.chkRiserPads.Name = "chkRiserPads"
        Me.chkRiserPads.Size = New System.Drawing.Size(77, 17)
        Me.chkRiserPads.TabIndex = 3
        Me.chkRiserPads.Text = "Riser Pads"
        Me.chkRiserPads.UseVisualStyleBackColor = True
        '
        'chkNutsAndBoltsKit
        '
        Me.chkNutsAndBoltsKit.AutoSize = True
        Me.chkNutsAndBoltsKit.Location = New System.Drawing.Point(12, 81)
        Me.chkNutsAndBoltsKit.Name = "chkNutsAndBoltsKit"
        Me.chkNutsAndBoltsKit.Size = New System.Drawing.Size(98, 17)
        Me.chkNutsAndBoltsKit.TabIndex = 4
        Me.chkNutsAndBoltsKit.Text = "Nuts && Bolts Kit"
        Me.chkNutsAndBoltsKit.UseVisualStyleBackColor = True
        '
        'btnNext
        '
        Me.btnNext.Location = New System.Drawing.Point(167, 52)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(75, 23)
        Me.btnNext.TabIndex = 5
        Me.btnNext.Text = "Next"
        Me.btnNext.UseVisualStyleBackColor = True
        '
        'MiscForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 133)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.chkNutsAndBoltsKit)
        Me.Controls.Add(Me.chkRiserPads)
        Me.Controls.Add(Me.chkAssembly)
        Me.Controls.Add(Me.chkBearings)
        Me.Controls.Add(Me.chkGripTape)
        Me.Name = "MiscForm"
        Me.Text = "Miscellaneous"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents chkGripTape As CheckBox
    Friend WithEvents chkBearings As CheckBox
    Friend WithEvents chkAssembly As CheckBox
    Friend WithEvents chkRiserPads As CheckBox
    Friend WithEvents chkNutsAndBoltsKit As CheckBox
    Friend WithEvents btnNext As Button
End Class
