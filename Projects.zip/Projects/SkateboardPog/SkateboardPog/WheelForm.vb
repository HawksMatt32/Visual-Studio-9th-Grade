﻿Public Class WheelForm
    Private Sub rad55mm_CheckedChanged(sender As Object, e As EventArgs) Handles rad55mm.CheckedChanged

    End Sub

    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        If rad51mm.Checked = True Or rad55mm.Checked = True Or rad58mm.Checked = True Or rad61mm.Checked = True Then
            FinalForm.ShowDialog()
        Else
            MessageBox.Show("click one")
        End If
    End Sub
End Class