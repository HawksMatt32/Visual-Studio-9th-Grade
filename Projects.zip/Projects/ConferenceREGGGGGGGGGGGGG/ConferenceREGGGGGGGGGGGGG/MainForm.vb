﻿Public Class MainForm
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'close form
        Me.Close()

    End Sub

    Private Sub btnOptions_Click(sender As Object, e As EventArgs) Handles btnOptions.Click
        If ValidateInputs() Then
            Dim frmButt As New ConferenceOptions
            frmButt.ShowDialog()
        End If
    End Sub
    Function ValidateInputs() As Boolean
        If txtName.Text.Length > 0 Then
            If txtAddress.Text.Length > 0 Then
                If txtCity.Text.Length > 0 Then
                    If txtEmail.Text.Length > 0 Then
                        If txtPhone.Text.Length > 0 And IsNumeric(txtPhone.Text) Then
                            If txtState.Text.Length > 0 Then
                                If txtZip.Text.Length > 0 And IsNumeric(txtZip.Text) Then
                                    Return True
                                Else
                                    MessageBox.Show("error")
                                    Return False
                                End If
                            Else
                                MessageBox.Show("error")
                                Return False
                            End If
                        Else
                            MessageBox.Show("error")
                            Return False
                        End If
                    Else
                        MessageBox.Show("error")
                        Return False
                    End If
                Else
                    MessageBox.Show("error")
                    Return False
                End If
            Else
                MessageBox.Show("error")
                Return False
            End If
        Else
            MessageBox.Show("error")
            Return False
        End If
    End Function
End Class
