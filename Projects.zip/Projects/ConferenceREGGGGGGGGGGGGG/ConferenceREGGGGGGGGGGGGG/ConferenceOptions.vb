﻿Public Class ConferenceOptions
    Private Sub btnContinue_Click(sender As Object, e As EventArgs) Handles btnContinue.Click
        Dim decTotal As Decimal
        Dim boolDinner As Boolean = chkConference.Checked
        Dim boolConference As Boolean = chkDinner.Checked
        Dim intIndex As Integer = lstWorkshops.SelectedIndex
        Try
            decTotal = CDec(CalcTotal(intIndex, boolDinner, boolConference))
            MessageBox.Show(decTotal.ToString())
            MainForm.lblTotal.Text = decTotal.ToString("C")
            Me.Close()
        Catch ex As Exception
            MessageBox.Show("error like how>>??")
        End Try
    End Sub
End Class