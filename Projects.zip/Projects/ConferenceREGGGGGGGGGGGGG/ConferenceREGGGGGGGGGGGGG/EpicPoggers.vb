﻿Module EpicPoggers
    Dim decTotal As Decimal
    Function CalcTotal(ByRef intIndex As Integer, ByRef boolDinner As Boolean, ByRef boolConference As Boolean) As Decimal
        decTotal = 0
        If boolDinner = True Then
            decTotal += 895
        End If
        If boolConference = True Then
            decTotal += 30
        End If
        MessageBox.Show(intIndex.ToString)
        If intIndex = 0 Then
            decTotal += 295
        ElseIf intIndex = 1 Then
            decTotal += 295
        ElseIf intIndex = 2 Then
            decTotal += 395
        ElseIf intIndex = 3 Then
            decTotal += 395
        Else
            MessageBox.Show("error module line 21")
        End If
        Return decTotal
    End Function
End Module
