﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub lblSalePrice_Click(sender As Object, e As EventArgs) Handles lblSalePrice.Click

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decOriginalPrice As Decimal = 0  ' og price
        Dim decDiscountPercentage As Decimal = 0 ' discount percentage
        Dim decDiscountAmount As Decimal = 0 ' Amount of Discount
        Dim decSalePrice As Decimal = 0 ' SalePrice

        Try

            ' get item og price
            decOriginalPrice = CDec(txtOriginalPrice.Text)

            'get discount percentage
            decDiscountPercentage = CDec(txtDiscountPercentage.Text)

        Catch ex As Exception
            MessageBox.Show("Please enter only integer values")
        End Try



        ' move the percentages decimals point to 2 spaces
        decDiscountPercentage = decDiscountPercentage / 100

        'calculate discount
        decDiscountAmount = decOriginalPrice * decDiscountPercentage

        ' Calculate sale price
        decSalePrice = decOriginalPrice - decDiscountAmount

        ' display sale price
        lblSalePrice.Text = decSalePrice.ToString("c")



    End Sub

    Private Sub lblStatus_Click(sender As Object, e As EventArgs) Handles lblStatus.Click
        Dim dtmCurrent As Date = Now
        lblStatus.Text = dtmCurrent.ToString






    End Sub

    Private Sub StatusStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles StatusStrip1.ItemClicked

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnTime.Click
        Dim dtmCurrent As Date = Now
        lblStatus.Text = dtmCurrent.ToString
    End Sub
End Class
