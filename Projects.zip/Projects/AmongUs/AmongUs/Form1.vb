﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        picCox.Location = New Point(picCox.Location.X + 5, picCox.Location.Y)
    End Sub
End Class
