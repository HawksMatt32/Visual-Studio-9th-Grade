﻿Public Class Form1
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' initialize class variables

        Dim intA As Integer
        Dim intB As Integer
        Dim intC As Integer

        'start exception handling
        Try
            ' does big brain math and shows it

            'Class A
            intA = CInt(txtA.Text)
            lblA.Text = CInt(intA * 15).ToString("C")

            'Class B
            intB = CInt(txtB.Text)
            lblB.Text = CInt(intB * 12).ToString("C")

            'Class C
            intC = CInt(txtC.Text)
            lblC.Text = CInt(intC * 9).ToString("C")

            'Total
            lblTotal.Text = (CInt(lblA.Text) + CInt(lblB.Text) + CInt(lblC.Text)).ToString("C")

        Catch ex As Exception
            'error handling
            MessageBox.Show("Please input valid numeric values")

        End Try

        'end of exception handling

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnClear.Click

        'clears text boxes
        txtA.Clear()
        txtB.Clear()
        txtC.Clear()

        'clears labels
        lblA.Text = String.Empty
        lblB.Text = String.Empty
        lblC.Text = String.Empty
        lblTotal.Text = String.Empty

    End Sub
End Class
