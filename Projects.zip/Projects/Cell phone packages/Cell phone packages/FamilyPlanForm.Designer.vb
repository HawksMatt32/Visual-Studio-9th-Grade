﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FamilyPlanForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.rad600 = New System.Windows.Forms.RadioButton()
        Me.radT1000 = New System.Windows.Forms.RadioButton()
        Me.rad101 = New System.Windows.Forms.RadioButton()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.lblTotalMonthly = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.lblSubtotal = New System.Windows.Forms.Label()
        Me.lblTax = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblPhoneTotal = New System.Windows.Forms.Label()
        Me.lblOptions = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblPackageCharge = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.chkText = New System.Windows.Forms.CheckBox()
        Me.chkEmail = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.rad1500Minutes = New System.Windows.Forms.RadioButton()
        Me.rad800Minutes = New System.Windows.Forms.RadioButton()
        Me.radUnlimitedMinutes = New System.Windows.Forms.RadioButton()
        Me.txtNumberOfPhones = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(27, 288)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(211, 49)
        Me.btnClose.TabIndex = 19
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(27, 221)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(211, 49)
        Me.btnCalculate.TabIndex = 20
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.rad600)
        Me.GroupBox2.Controls.Add(Me.radT1000)
        Me.GroupBox2.Controls.Add(Me.rad101)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 27)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(249, 100)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Cyberdyne Phone Systems"
        '
        'rad600
        '
        Me.rad600.AutoSize = True
        Me.rad600.Location = New System.Drawing.Point(6, 42)
        Me.rad600.Name = "rad600"
        Me.rad600.Size = New System.Drawing.Size(75, 17)
        Me.rad600.TabIndex = 1
        Me.rad600.TabStop = True
        Me.rad600.Text = "Model 600"
        Me.rad600.UseVisualStyleBackColor = True
        '
        'radT1000
        '
        Me.radT1000.AutoSize = True
        Me.radT1000.Location = New System.Drawing.Point(6, 65)
        Me.radT1000.Name = "radT1000"
        Me.radT1000.Size = New System.Drawing.Size(91, 17)
        Me.radT1000.TabIndex = 2
        Me.radT1000.TabStop = True
        Me.radT1000.Text = "Model T-1000"
        Me.radT1000.UseVisualStyleBackColor = True
        '
        'rad101
        '
        Me.rad101.AutoSize = True
        Me.rad101.Location = New System.Drawing.Point(6, 19)
        Me.rad101.Name = "rad101"
        Me.rad101.Size = New System.Drawing.Size(75, 17)
        Me.rad101.TabIndex = 3
        Me.rad101.TabStop = True
        Me.rad101.Text = "Model 101"
        Me.rad101.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.lblTotalMonthly)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.lblSubtotal)
        Me.GroupBox3.Controls.Add(Me.lblTax)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Controls.Add(Me.lblPhoneTotal)
        Me.GroupBox3.Controls.Add(Me.lblOptions)
        Me.GroupBox3.Controls.Add(Me.Label1)
        Me.GroupBox3.Controls.Add(Me.lblPackageCharge)
        Me.GroupBox3.Controls.Add(Me.Label2)
        Me.GroupBox3.Location = New System.Drawing.Point(274, 137)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(249, 200)
        Me.GroupBox3.TabIndex = 16
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Totals"
        '
        'lblTotalMonthly
        '
        Me.lblTotalMonthly.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalMonthly.Location = New System.Drawing.Point(130, 161)
        Me.lblTotalMonthly.Name = "lblTotalMonthly"
        Me.lblTotalMonthly.Size = New System.Drawing.Size(100, 23)
        Me.lblTotalMonthly.TabIndex = 12
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(11, 45)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(25, 13)
        Me.Label11.TabIndex = 11
        Me.Label11.Text = "Tax"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(11, 74)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(65, 13)
        Me.Label10.TabIndex = 10
        Me.Label10.Text = "Phone Total"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(11, 161)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(108, 13)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Total Monthly Charge"
        '
        'lblSubtotal
        '
        Me.lblSubtotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSubtotal.Location = New System.Drawing.Point(130, 15)
        Me.lblSubtotal.Name = "lblSubtotal"
        Me.lblSubtotal.Size = New System.Drawing.Size(100, 23)
        Me.lblSubtotal.TabIndex = 8
        '
        'lblTax
        '
        Me.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTax.Location = New System.Drawing.Point(130, 44)
        Me.lblTax.Name = "lblTax"
        Me.lblTax.Size = New System.Drawing.Size(100, 23)
        Me.lblTax.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(11, 132)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Package Charge"
        '
        'lblPhoneTotal
        '
        Me.lblPhoneTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPhoneTotal.Location = New System.Drawing.Point(130, 73)
        Me.lblPhoneTotal.Name = "lblPhoneTotal"
        Me.lblPhoneTotal.Size = New System.Drawing.Size(100, 23)
        Me.lblPhoneTotal.TabIndex = 6
        '
        'lblOptions
        '
        Me.lblOptions.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOptions.Location = New System.Drawing.Point(130, 102)
        Me.lblOptions.Name = "lblOptions"
        Me.lblOptions.Size = New System.Drawing.Size(100, 23)
        Me.lblOptions.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(43, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Options"
        '
        'lblPackageCharge
        '
        Me.lblPackageCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPackageCharge.Location = New System.Drawing.Point(130, 131)
        Me.lblPackageCharge.Name = "lblPackageCharge"
        Me.lblPackageCharge.Size = New System.Drawing.Size(100, 23)
        Me.lblPackageCharge.TabIndex = 4
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(11, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(80, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Phone Subtotal"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.chkText)
        Me.GroupBox4.Controls.Add(Me.chkEmail)
        Me.GroupBox4.Location = New System.Drawing.Point(12, 137)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(249, 76)
        Me.GroupBox4.TabIndex = 17
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Select Options"
        '
        'chkText
        '
        Me.chkText.AutoSize = True
        Me.chkText.Location = New System.Drawing.Point(15, 46)
        Me.chkText.Name = "chkText"
        Me.chkText.Size = New System.Drawing.Size(101, 17)
        Me.chkText.TabIndex = 2
        Me.chkText.Text = "Text Messaging"
        Me.chkText.UseVisualStyleBackColor = True
        '
        'chkEmail
        '
        Me.chkEmail.AutoSize = True
        Me.chkEmail.Location = New System.Drawing.Point(15, 23)
        Me.chkEmail.Name = "chkEmail"
        Me.chkEmail.Size = New System.Drawing.Size(54, 17)
        Me.chkEmail.TabIndex = 1
        Me.chkEmail.Text = "E-mail"
        Me.chkEmail.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.rad1500Minutes)
        Me.GroupBox1.Controls.Add(Me.rad800Minutes)
        Me.GroupBox1.Controls.Add(Me.radUnlimitedMinutes)
        Me.GroupBox1.Location = New System.Drawing.Point(277, 27)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(249, 100)
        Me.GroupBox1.TabIndex = 18
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Select a Package"
        '
        'rad1500Minutes
        '
        Me.rad1500Minutes.AutoSize = True
        Me.rad1500Minutes.Location = New System.Drawing.Point(6, 42)
        Me.rad1500Minutes.Name = "rad1500Minutes"
        Me.rad1500Minutes.Size = New System.Drawing.Size(140, 17)
        Me.rad1500Minutes.TabIndex = 4
        Me.rad1500Minutes.TabStop = True
        Me.rad1500Minutes.Text = "1500 Minutes per Month"
        Me.rad1500Minutes.UseVisualStyleBackColor = True
        '
        'rad800Minutes
        '
        Me.rad800Minutes.AutoSize = True
        Me.rad800Minutes.Location = New System.Drawing.Point(6, 19)
        Me.rad800Minutes.Name = "rad800Minutes"
        Me.rad800Minutes.Size = New System.Drawing.Size(134, 17)
        Me.rad800Minutes.TabIndex = 6
        Me.rad800Minutes.TabStop = True
        Me.rad800Minutes.Text = "800 Minutes per Month"
        Me.rad800Minutes.UseVisualStyleBackColor = True
        '
        'radUnlimitedMinutes
        '
        Me.radUnlimitedMinutes.AutoSize = True
        Me.radUnlimitedMinutes.Location = New System.Drawing.Point(6, 65)
        Me.radUnlimitedMinutes.Name = "radUnlimitedMinutes"
        Me.radUnlimitedMinutes.Size = New System.Drawing.Size(159, 17)
        Me.radUnlimitedMinutes.TabIndex = 5
        Me.radUnlimitedMinutes.TabStop = True
        Me.radUnlimitedMinutes.Text = "Unlimited Minutes per Month"
        Me.radUnlimitedMinutes.UseVisualStyleBackColor = True
        '
        'txtNumberOfPhones
        '
        Me.txtNumberOfPhones.Location = New System.Drawing.Point(228, 5)
        Me.txtNumberOfPhones.Name = "txtNumberOfPhones"
        Me.txtNumberOfPhones.Size = New System.Drawing.Size(100, 20)
        Me.txtNumberOfPhones.TabIndex = 21
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(127, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(98, 13)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "Number of Phones:"
        '
        'FamilyPlanForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(551, 348)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtNumberOfPhones)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FamilyPlanForm"
        Me.Text = "Family Packages"
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnClose As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents rad600 As RadioButton
    Friend WithEvents radT1000 As RadioButton
    Friend WithEvents rad101 As RadioButton
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents lblTotalMonthly As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents lblSubtotal As Label
    Friend WithEvents lblTax As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents lblPhoneTotal As Label
    Friend WithEvents lblOptions As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents lblPackageCharge As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents chkText As CheckBox
    Friend WithEvents chkEmail As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents rad1500Minutes As RadioButton
    Friend WithEvents rad800Minutes As RadioButton
    Friend WithEvents radUnlimitedMinutes As RadioButton
    Friend WithEvents txtNumberOfPhones As TextBox
    Friend WithEvents Label4 As Label
End Class
