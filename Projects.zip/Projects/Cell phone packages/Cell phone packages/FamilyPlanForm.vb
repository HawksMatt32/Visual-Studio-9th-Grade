﻿Public Class FamilyPlanForm
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Try
            Dim intPhone As Integer
            Dim intPackage As Integer
            Dim boolEmail As Boolean = chkEmail.Checked
            Dim boolUnlimitedText As Boolean = chkText.Checked
            Dim intNumberOfPhones As Integer = CInt(txtNumberOfPhones.Text)
            If rad101.Checked = True Then
                intPhone = 1
            ElseIf rad600.Checked = True Then
                intPhone = 2
            ElseIf radT1000.Checked = True Then
                intPhone = 3
            Else

            End If
            If rad800Minutes.Checked = True Then
                intPackage = 1
            ElseIf rad1500Minutes.Checked = True Then
                intPackage = 2
            ElseIf radUnlimitedMinutes.Checked = True Then
                intPackage = 3
            Else

            End If
            CalcPhone(intPhone, intPackage, boolEmail, boolUnlimitedText, intNumberOfPhones)
        Catch ex As Exception
            MessageBox.Show("error")
        End Try

    End Sub
End Class