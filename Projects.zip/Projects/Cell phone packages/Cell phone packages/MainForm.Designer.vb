﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileReset = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPlans = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPlansFamily = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuPlansIndividual = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnIndividual = New System.Windows.Forms.Button()
        Me.btnFamily = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuPlans, Me.mnuHelp})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(423, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileReset, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "File"
        '
        'mnuFileReset
        '
        Me.mnuFileReset.Name = "mnuFileReset"
        Me.mnuFileReset.Size = New System.Drawing.Size(152, 22)
        Me.mnuFileReset.Text = "Reset"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(152, 22)
        Me.mnuFileExit.Text = "Exit"
        '
        'mnuPlans
        '
        Me.mnuPlans.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuPlansFamily, Me.mnuPlansIndividual})
        Me.mnuPlans.Name = "mnuPlans"
        Me.mnuPlans.Size = New System.Drawing.Size(47, 20)
        Me.mnuPlans.Text = "Plans"
        '
        'mnuPlansFamily
        '
        Me.mnuPlansFamily.Name = "mnuPlansFamily"
        Me.mnuPlansFamily.Size = New System.Drawing.Size(152, 22)
        Me.mnuPlansFamily.Text = "Family"
        '
        'mnuPlansIndividual
        '
        Me.mnuPlansIndividual.Name = "mnuPlansIndividual"
        Me.mnuPlansIndividual.Size = New System.Drawing.Size(152, 22)
        Me.mnuPlansIndividual.Text = "Individual"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpInfo})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Text = "Help"
        '
        'mnuHelpInfo
        '
        Me.mnuHelpInfo.Name = "mnuHelpInfo"
        Me.mnuHelpInfo.Size = New System.Drawing.Size(152, 22)
        Me.mnuHelpInfo.Text = "Info"
        '
        'btnIndividual
        '
        Me.btnIndividual.Location = New System.Drawing.Point(256, 39)
        Me.btnIndividual.Name = "btnIndividual"
        Me.btnIndividual.Size = New System.Drawing.Size(147, 48)
        Me.btnIndividual.TabIndex = 1
        Me.btnIndividual.Text = "Individual Plan"
        Me.btnIndividual.UseVisualStyleBackColor = True
        '
        'btnFamily
        '
        Me.btnFamily.Location = New System.Drawing.Point(256, 97)
        Me.btnFamily.Name = "btnFamily"
        Me.btnFamily.Size = New System.Drawing.Size(147, 48)
        Me.btnFamily.TabIndex = 2
        Me.btnFamily.Text = "Family Plan"
        Me.btnFamily.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(19, 40)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(191, 47)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "The individual plan provides one cell phone and a variety of monthly plans."
        '
        'Label2
        '
        Me.Label2.Location = New System.Drawing.Point(19, 98)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(191, 47)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "The family plan allows you to purchase multiple cell phones, with each phone shar" &
    "ing one monthly package."
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(423, 165)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnFamily)
        Me.Controls.Add(Me.btnIndividual)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MainForm"
        Me.Text = "Cell Phone Packages"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuFileReset As ToolStripMenuItem
    Friend WithEvents mnuFileExit As ToolStripMenuItem
    Friend WithEvents mnuPlans As ToolStripMenuItem
    Friend WithEvents mnuPlansFamily As ToolStripMenuItem
    Friend WithEvents mnuPlansIndividual As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents mnuHelpInfo As ToolStripMenuItem
    Friend WithEvents btnIndividual As Button
    Friend WithEvents btnFamily As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
