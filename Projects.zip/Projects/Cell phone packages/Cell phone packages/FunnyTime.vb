﻿Module FunnyTime
    Sub CalcPhone(ByRef intPhone As Integer, ByRef intPackage As Integer, ByRef boolEmail As Boolean, ByRef boolUnlimitedText As Boolean, ByRef intNumberOfPhones As Integer)
        Try
            Dim decPhoneSubtotal As Decimal
            Dim decOptionsCost As Decimal
            Dim decPackagesCost As Decimal
            Dim decMonthlyCost As Decimal
            Dim decTax As Decimal
            Dim decPhoneTotal As Decimal
            Const decTAX_RATE As Decimal = 0.06D
            If intPhone = 1 Then
                decPhoneSubtotal = 29.95D
            ElseIf intPhone = 2 Then
                decPhoneSubtotal = 49.95D
            ElseIf intPhone = 3 Then
                decPhoneSubtotal = 99.95D
            Else
                Try
                    MessageBox.Show("error module code0_3_intPhoneUnknownInt. intPhone = " + CStr(intPhone))
                Catch ex As Exception
                End Try
            End If
            If intPackage = 1 Then
                decPackagesCost = 45D
            ElseIf intPackage = 2 Then
                decPackagesCost = 65D
            ElseIf intPackage = 3 Then
                decPackagesCost = 99D
            Else
                Try
                    MessageBox.Show("error module code0_3_intPackageUnknown. intPackage = " + CStr(intPackage))
                Catch ex As Exception
                End Try
            End If
            If boolEmail = True Then
                decOptionsCost = 25
            End If
            If boolUnlimitedText = True Then
                decOptionsCost += 10
            End If
            If intNumberOfPhones > 1 Then
                decPhoneSubtotal *= intNumberOfPhones
                decTax = decTAX_RATE * decPhoneSubtotal
                decMonthlyCost = decPackagesCost + decOptionsCost
                decMonthlyCost *= intNumberOfPhones
                decPhoneTotal = decTax + decPhoneSubtotal
                FamilyPlanForm.lblSubtotal.Text = decPhoneSubtotal.ToString("C")
                FamilyPlanForm.lblTax.Text = decTax.ToString("C")
                FamilyPlanForm.lblPhoneTotal.Text = decPhoneTotal.ToString("C")
                FamilyPlanForm.lblOptions.Text = decOptionsCost.ToString("C")
                FamilyPlanForm.lblPackageCharge.Text = decPackagesCost.ToString("C")
                FamilyPlanForm.lblTotalMonthly.Text = decMonthlyCost.ToString("C")
            Else
                decTax = decTAX_RATE * decPhoneSubtotal
                decMonthlyCost = decPackagesCost + decOptionsCost
                decPhoneTotal = decTax + decPhoneSubtotal
                IndividualPlanForm.lblSubtotal.Text = decPhoneSubtotal.ToString("C")
                IndividualPlanForm.lblTax.Text = decTax.ToString("C")
                IndividualPlanForm.lblPhoneTotal.Text = decPhoneTotal.ToString("C")
                IndividualPlanForm.lblOptions.Text = decOptionsCost.ToString("C")
                IndividualPlanForm.lblPackageCharge.Text = decPackagesCost.ToString("C")
                IndividualPlanForm.lblTotalMonthly.Text = decMonthlyCost.ToString("C")
            End If
        Catch ex As Exception
            MessageBox.Show("module error")
        End Try
    End Sub
End Module
'end