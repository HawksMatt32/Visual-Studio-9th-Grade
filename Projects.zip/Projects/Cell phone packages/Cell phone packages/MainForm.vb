﻿Public Class MainForm
    Private Sub btnFamily_Click(sender As Object, e As EventArgs) Handles btnFamily.Click
        FamilyPlanForm.ShowDialog()
    End Sub
    Private Sub btnIndividual_click(sender As Object, e As EventArgs) Handles btnIndividual.Click
        IndividualPlanForm.ShowDialog()
    End Sub

    Private Sub mnuFileReset_Click(sender As Object, e As EventArgs) Handles mnuFileReset.Click
        FamilyPlanForm.Close()
        IndividualPlanForm.Close()
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        FamilyPlanForm.Close()
        IndividualPlanForm.Close()
        Me.Close()
    End Sub

    Private Sub mnuPlansFamily_Click(sender As Object, e As EventArgs) Handles mnuPlansFamily.Click
        FamilyPlanForm.ShowDialog()
    End Sub

    Private Sub mnuPlansIndividual_Click(sender As Object, e As EventArgs) Handles mnuPlansIndividual.Click
        IndividualPlanForm.ShowDialog()
    End Sub

    Private Sub mnuHelpInfo_Click(sender As Object, e As EventArgs) Handles mnuHelpInfo.Click
        MessageBox.Show("CRAZY RADICAL POGG!!!!!!!!!!!")
    End Sub
End Class
