﻿Public Class Form1
    Private Sub btnConvert_Click(sender As Object, e As EventArgs) Handles btnConvert.Click
        'start of error handling
        Try
            'conditional to decide if they inputted a number 1-8
            If IsNumeric(txtInput.Text) Then
                If CInt(txtInput.Text) > 0 Then
                    'case statement to decide what to output
                    Select Case CInt(txtInput.Text)
                        Case 1
                            lblOutput.Text = "I"
                        Case 2
                            lblOutput.Text = "II"
                        Case 3
                            lblOutput.Text = "III"
                        Case 4
                            lblOutput.Text = "IV"
                        Case 5
                            lblOutput.Text = "V"
                        Case 6
                            lblOutput.Text = "VI"
                        Case 7
                            lblOutput.Text = "VII"
                        Case 8
                            lblOutput.Text = "VIII"
                        Case Else
                            lblOutput.Text = "More than VIII"
                    End Select
                Else
                    'built in error handling
                    MessageBox.Show("Please input a numeric value 1-8")
                    txtInput.Text = ""
                End If




            Else
                'built in error handling
                MessageBox.Show("Please input a numeric value 1-8")
                txtInput.Text = ""
            End If
        Catch ex As Exception
            MessageBox.Show("unknown error")
            txtInput.Text = ""
        End Try

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub
End Class