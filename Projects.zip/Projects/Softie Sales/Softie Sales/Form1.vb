﻿Public Class Form1
    'global var
    Dim intL3Cost As Integer = 3500
    Dim intOnSiteCost As Integer = 2000
    Dim intCloudCost As Integer = 300
    Dim intTotalOptionalCost As Integer = 0
    Dim intTotalSoft As Integer = 0

    Private Sub GroupBox2_Enter(sender As Object, e As EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'checkbox if checked then add cost
        If chkL3.Checked = True Then
            intTotalOptionalCost += intL3Cost

        End If
        If chkOnSite.Checked = True Then
            intTotalOptionalCost += intOnSiteCost

        End If
        If chkCloudBackup.Checked = True Then
            intTotalOptionalCost += intCloudCost
            'radiobutton if check then add cost
        End If
        If radOneTime.Checked Then
            intTotalSoft = 20000
        ElseIf radYearly.Checked Then
            intTotalSoft = 5000
        End If
        'shows output
        lblOptOut.Text = intTotalOptionalCost.ToString("C")
        lblSoftOut.Text = intTotalSoft.ToString("C")

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'uncheck things and empty things
        radOneTime.Checked = False
        radYearly.Checked = False
        lblSoftOut.Text = String.Empty
        lblOptOut.Text = String.Empty
        chkCloudBackup.Checked = False
        chkL3.Checked = False
        chkOnSite.Checked = False
        'reset var
        intTotalSoft = 0
        intTotalOptionalCost = 0


    End Sub

    Private Sub chkOnSite_CheckedChanged(sender As Object, e As EventArgs) Handles chkOnSite.CheckedChanged

    End Sub
End Class
