﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.radYearly = New System.Windows.Forms.RadioButton()
        Me.radOneTime = New System.Windows.Forms.RadioButton()
        Me.chkCloudBackup = New System.Windows.Forms.CheckBox()
        Me.chkOnSite = New System.Windows.Forms.CheckBox()
        Me.chkL3 = New System.Windows.Forms.CheckBox()
        Me.lblSoftOut = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblOptOut = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Output = New System.Windows.Forms.GroupBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.Output.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox1.Controls.Add(Me.radOneTime)
        Me.GroupBox1.Controls.Add(Me.radYearly)
        Me.GroupBox1.Location = New System.Drawing.Point(60, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Licensing Options"
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.SystemColors.ControlLight
        Me.GroupBox2.Controls.Add(Me.chkCloudBackup)
        Me.GroupBox2.Controls.Add(Me.chkOnSite)
        Me.GroupBox2.Controls.Add(Me.chkL3)
        Me.GroupBox2.Location = New System.Drawing.Point(320, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(200, 100)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Optional Features (yearly)"
        '
        'radYearly
        '
        Me.radYearly.AutoSize = True
        Me.radYearly.Location = New System.Drawing.Point(6, 19)
        Me.radYearly.Name = "radYearly"
        Me.radYearly.Size = New System.Drawing.Size(94, 17)
        Me.radYearly.TabIndex = 0
        Me.radYearly.TabStop = True
        Me.radYearly.Text = "Yearly License"
        Me.radYearly.UseVisualStyleBackColor = True
        '
        'radOneTime
        '
        Me.radOneTime.AutoSize = True
        Me.radOneTime.Location = New System.Drawing.Point(6, 57)
        Me.radOneTime.Name = "radOneTime"
        Me.radOneTime.Size = New System.Drawing.Size(119, 17)
        Me.radOneTime.TabIndex = 1
        Me.radOneTime.TabStop = True
        Me.radOneTime.Text = "One-Time Purchase"
        Me.radOneTime.UseVisualStyleBackColor = True
        '
        'chkCloudBackup
        '
        Me.chkCloudBackup.AutoSize = True
        Me.chkCloudBackup.Location = New System.Drawing.Point(6, 65)
        Me.chkCloudBackup.Name = "chkCloudBackup"
        Me.chkCloudBackup.Size = New System.Drawing.Size(93, 17)
        Me.chkCloudBackup.TabIndex = 2
        Me.chkCloudBackup.Text = "Cloud Backup"
        Me.chkCloudBackup.UseVisualStyleBackColor = True
        '
        'chkOnSite
        '
        Me.chkOnSite.AutoSize = True
        Me.chkOnSite.Location = New System.Drawing.Point(6, 42)
        Me.chkOnSite.Name = "chkOnSite"
        Me.chkOnSite.Size = New System.Drawing.Size(100, 17)
        Me.chkOnSite.TabIndex = 3
        Me.chkOnSite.Text = "On-site Training"
        Me.chkOnSite.UseVisualStyleBackColor = True
        '
        'chkL3
        '
        Me.chkL3.AutoSize = True
        Me.chkL3.Location = New System.Drawing.Point(6, 19)
        Me.chkL3.Name = "chkL3"
        Me.chkL3.Size = New System.Drawing.Size(129, 17)
        Me.chkL3.TabIndex = 4
        Me.chkL3.Text = "Level 3 Tech Support"
        Me.chkL3.UseVisualStyleBackColor = True
        '
        'lblSoftOut
        '
        Me.lblSoftOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSoftOut.Location = New System.Drawing.Point(158, 17)
        Me.lblSoftOut.Name = "lblSoftOut"
        Me.lblSoftOut.Size = New System.Drawing.Size(100, 23)
        Me.lblSoftOut.TabIndex = 5
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(19, 17)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(133, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Cost of Software Licensing"
        '
        'lblOptOut
        '
        Me.lblOptOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOptOut.Location = New System.Drawing.Point(158, 64)
        Me.lblOptOut.Name = "lblOptOut"
        Me.lblOptOut.Size = New System.Drawing.Size(100, 23)
        Me.lblOptOut.TabIndex = 7
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(19, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(126, 13)
        Me.Label4.TabIndex = 8
        Me.Label4.Text = "Cost of Optional Features"
        '
        'Output
        '
        Me.Output.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Output.Controls.Add(Me.lblOptOut)
        Me.Output.Controls.Add(Me.Label4)
        Me.Output.Controls.Add(Me.Label2)
        Me.Output.Controls.Add(Me.lblSoftOut)
        Me.Output.Location = New System.Drawing.Point(149, 137)
        Me.Output.Name = "Output"
        Me.Output.Size = New System.Drawing.Size(283, 100)
        Me.Output.TabIndex = 9
        Me.Output.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(386, 274)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 2
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(120, 274)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(75, 23)
        Me.btnCalc.TabIndex = 3
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(253, 274)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 23)
        Me.btnClear.TabIndex = 4
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(580, 326)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.Output)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Software Sales"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.Output.ResumeLayout(False)
        Me.Output.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents radOneTime As RadioButton
    Friend WithEvents radYearly As RadioButton
    Friend WithEvents chkCloudBackup As CheckBox
    Friend WithEvents chkOnSite As CheckBox
    Friend WithEvents chkL3 As CheckBox
    Friend WithEvents lblSoftOut As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblOptOut As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Output As GroupBox
    Friend WithEvents btnClose As Button
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
End Class
