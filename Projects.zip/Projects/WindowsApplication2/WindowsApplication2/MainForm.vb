﻿Public Class MainForm
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim frmErrorForm As New ErrorForm
        frmErrorForm.Show()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Hide()
        start.Hide()
        MessageBox.Show("pp")
    End Sub
End Class
