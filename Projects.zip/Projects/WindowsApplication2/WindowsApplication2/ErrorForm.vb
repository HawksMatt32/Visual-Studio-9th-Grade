﻿Public Class ErrorForm
    Private Sub ErrorForm_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub ErrorForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        If MessageBox.Show("are you sure?", "confirm", MessageBoxButtons.YesNo) = DialogResult.Yes Then
            e.Cancel = False
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub ErrorForm_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        Dim frmMainForm As New MainForm
        frmMainForm.lblStuff.Text = "nerd alert!!1@"
    End Sub
End Class