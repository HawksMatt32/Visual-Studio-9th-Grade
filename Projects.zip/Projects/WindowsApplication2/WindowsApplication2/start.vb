﻿Public Class start
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim frmMainForm As New MainForm
        frmMainForm.ShowDialog()

    End Sub
End Class