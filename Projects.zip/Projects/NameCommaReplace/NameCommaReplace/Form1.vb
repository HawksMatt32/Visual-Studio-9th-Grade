﻿Public Class Form1
    Private Sub btnTransform_Click(sender As Object, e As EventArgs) Handles btnTransform.Click
        'declares variables and slight formatting
        Dim strFirstName As String
        Dim strLastName As String
        Dim strName As String = (txtIn.Text).Replace(" ", "")
        Dim intCommaPos As Integer = strName.IndexOf(",")
        If intCommaPos = -1 Then

        Else
            'take out first and last name and declare them as variables
            strName = strName.Replace(",", "")

            strFirstName = strName.Substring(intCommaPos)

            strName.Replace(strFirstName, "")
            strLastName = strName.Substring(0, intCommaPos)
            'displayes first last
            lblOut.Text = strFirstName + " " + strLastName
        End If


    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()

    End Sub
End Class
