﻿Public Class Form1
    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim dec5 As Decimal = CDec(txtSpeed.Text) * 5
        Dim dec8 As Decimal = CDec(txtSpeed.Text) * 8
        Dim dec12 As Decimal = CDec(txtSpeed.Text) * 12
        lbl5.Text = dec5.ToString + " miles"
        lbl8.Text = dec8.ToString + " miles"
        lbl12.Text = dec12.ToString + " miles"
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtSpeed.TextChanged

    End Sub
End Class
