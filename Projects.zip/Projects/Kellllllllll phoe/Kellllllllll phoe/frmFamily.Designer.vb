﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmFamily
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.grpPhoneModels = New System.Windows.Forms.GroupBox()
        Me.grpSelectPackage = New System.Windows.Forms.GroupBox()
        Me.grpTotals = New System.Windows.Forms.GroupBox()
        Me.grpOptions = New System.Windows.Forms.GroupBox()
        Me.rad101 = New System.Windows.Forms.RadioButton()
        Me.radT1000 = New System.Windows.Forms.RadioButton()
        Me.rad600 = New System.Windows.Forms.RadioButton()
        Me.rad800Month = New System.Windows.Forms.RadioButton()
        Me.rad1500Month = New System.Windows.Forms.RadioButton()
        Me.radUnlimitedMonth = New System.Windows.Forms.RadioButton()
        Me.chkEmail = New System.Windows.Forms.CheckBox()
        Me.chkText = New System.Windows.Forms.CheckBox()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.grpPhoneModels.SuspendLayout()
        Me.grpSelectPackage.SuspendLayout()
        Me.grpOptions.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpPhoneModels
        '
        Me.grpPhoneModels.Controls.Add(Me.rad600)
        Me.grpPhoneModels.Controls.Add(Me.radT1000)
        Me.grpPhoneModels.Controls.Add(Me.rad101)
        Me.grpPhoneModels.Location = New System.Drawing.Point(6, 29)
        Me.grpPhoneModels.Name = "grpPhoneModels"
        Me.grpPhoneModels.Size = New System.Drawing.Size(200, 219)
        Me.grpPhoneModels.TabIndex = 0
        Me.grpPhoneModels.TabStop = False
        Me.grpPhoneModels.Text = "CyberDyne Phone Models"
        '
        'grpSelectPackage
        '
        Me.grpSelectPackage.Controls.Add(Me.radUnlimitedMonth)
        Me.grpSelectPackage.Controls.Add(Me.rad1500Month)
        Me.grpSelectPackage.Controls.Add(Me.rad800Month)
        Me.grpSelectPackage.Location = New System.Drawing.Point(223, 29)
        Me.grpSelectPackage.Name = "grpSelectPackage"
        Me.grpSelectPackage.Size = New System.Drawing.Size(230, 219)
        Me.grpSelectPackage.TabIndex = 0
        Me.grpSelectPackage.TabStop = False
        Me.grpSelectPackage.Text = "Select a Package"
        '
        'grpTotals
        '
        Me.grpTotals.Location = New System.Drawing.Point(223, 254)
        Me.grpTotals.Name = "grpTotals"
        Me.grpTotals.Size = New System.Drawing.Size(230, 219)
        Me.grpTotals.TabIndex = 0
        Me.grpTotals.TabStop = False
        Me.grpTotals.Text = "Totals"
        '
        'grpOptions
        '
        Me.grpOptions.Controls.Add(Me.chkText)
        Me.grpOptions.Controls.Add(Me.chkEmail)
        Me.grpOptions.Location = New System.Drawing.Point(6, 254)
        Me.grpOptions.Name = "grpOptions"
        Me.grpOptions.Size = New System.Drawing.Size(200, 100)
        Me.grpOptions.TabIndex = 0
        Me.grpOptions.TabStop = False
        Me.grpOptions.Text = "Options"
        '
        'rad101
        '
        Me.rad101.AutoSize = True
        Me.rad101.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad101.Location = New System.Drawing.Point(19, 43)
        Me.rad101.Name = "rad101"
        Me.rad101.Size = New System.Drawing.Size(92, 21)
        Me.rad101.TabIndex = 0
        Me.rad101.TabStop = True
        Me.rad101.Text = "Model 101"
        Me.rad101.UseVisualStyleBackColor = True
        '
        'radT1000
        '
        Me.radT1000.AutoSize = True
        Me.radT1000.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radT1000.Location = New System.Drawing.Point(19, 137)
        Me.radT1000.Name = "radT1000"
        Me.radT1000.Size = New System.Drawing.Size(114, 21)
        Me.radT1000.TabIndex = 1
        Me.radT1000.TabStop = True
        Me.radT1000.Text = "Model T-1000"
        Me.radT1000.UseVisualStyleBackColor = True
        '
        'rad600
        '
        Me.rad600.AutoSize = True
        Me.rad600.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad600.Location = New System.Drawing.Point(19, 90)
        Me.rad600.Name = "rad600"
        Me.rad600.Size = New System.Drawing.Size(92, 21)
        Me.rad600.TabIndex = 2
        Me.rad600.TabStop = True
        Me.rad600.Text = "Model 600"
        Me.rad600.UseVisualStyleBackColor = True
        '
        'rad800Month
        '
        Me.rad800Month.AutoSize = True
        Me.rad800Month.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad800Month.Location = New System.Drawing.Point(18, 43)
        Me.rad800Month.Name = "rad800Month"
        Me.rad800Month.Size = New System.Drawing.Size(171, 21)
        Me.rad800Month.TabIndex = 1
        Me.rad800Month.TabStop = True
        Me.rad800Month.Text = "800 Minutes per Month"
        Me.rad800Month.UseVisualStyleBackColor = True
        '
        'rad1500Month
        '
        Me.rad1500Month.AutoSize = True
        Me.rad1500Month.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.rad1500Month.Location = New System.Drawing.Point(18, 90)
        Me.rad1500Month.Name = "rad1500Month"
        Me.rad1500Month.Size = New System.Drawing.Size(179, 21)
        Me.rad1500Month.TabIndex = 2
        Me.rad1500Month.TabStop = True
        Me.rad1500Month.Text = "1500 Minutes per Month"
        Me.rad1500Month.UseVisualStyleBackColor = True
        '
        'radUnlimitedMonth
        '
        Me.radUnlimitedMonth.AutoSize = True
        Me.radUnlimitedMonth.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radUnlimitedMonth.Location = New System.Drawing.Point(18, 137)
        Me.radUnlimitedMonth.Name = "radUnlimitedMonth"
        Me.radUnlimitedMonth.Size = New System.Drawing.Size(205, 21)
        Me.radUnlimitedMonth.TabIndex = 3
        Me.radUnlimitedMonth.TabStop = True
        Me.radUnlimitedMonth.Text = "Unlimited Minutes per Month"
        Me.radUnlimitedMonth.UseVisualStyleBackColor = True
        '
        'chkEmail
        '
        Me.chkEmail.AutoSize = True
        Me.chkEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkEmail.Location = New System.Drawing.Point(19, 19)
        Me.chkEmail.Name = "chkEmail"
        Me.chkEmail.Size = New System.Drawing.Size(65, 20)
        Me.chkEmail.TabIndex = 0
        Me.chkEmail.Text = "E-mail"
        Me.chkEmail.UseVisualStyleBackColor = True
        '
        'chkText
        '
        Me.chkText.AutoSize = True
        Me.chkText.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.chkText.Location = New System.Drawing.Point(19, 53)
        Me.chkText.Name = "chkText"
        Me.chkText.Size = New System.Drawing.Size(123, 20)
        Me.chkText.TabIndex = 1
        Me.chkText.Text = "Text Messaging"
        Me.chkText.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.Location = New System.Drawing.Point(25, 372)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(172, 43)
        Me.btnCalculate.TabIndex = 2
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(25, 428)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(172, 43)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'frmFamily
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(533, 505)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.grpSelectPackage)
        Me.Controls.Add(Me.grpTotals)
        Me.Controls.Add(Me.grpOptions)
        Me.Controls.Add(Me.grpPhoneModels)
        Me.Name = "frmFamily"
        Me.Text = "Family Plan"
        Me.grpPhoneModels.ResumeLayout(False)
        Me.grpPhoneModels.PerformLayout()
        Me.grpSelectPackage.ResumeLayout(False)
        Me.grpSelectPackage.PerformLayout()
        Me.grpOptions.ResumeLayout(False)
        Me.grpOptions.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents grpPhoneModels As GroupBox
    Friend WithEvents grpSelectPackage As GroupBox
    Friend WithEvents grpTotals As GroupBox
    Friend WithEvents grpOptions As GroupBox
    Friend WithEvents rad600 As RadioButton
    Friend WithEvents radT1000 As RadioButton
    Friend WithEvents rad101 As RadioButton
    Friend WithEvents radUnlimitedMonth As RadioButton
    Friend WithEvents rad1500Month As RadioButton
    Friend WithEvents rad800Month As RadioButton
    Friend WithEvents chkText As CheckBox
    Friend WithEvents chkEmail As CheckBox
    Friend WithEvents btnCalculate As Button
    Friend WithEvents btnClose As Button
End Class
