﻿Module WhatIsLove
    Public g_intHighScore As Integer
    Public g_decMultiplier As Decimal
    Public g_decTimer As Decimal = 3
    Public g_intInterval As Integer = 1000
End Module
