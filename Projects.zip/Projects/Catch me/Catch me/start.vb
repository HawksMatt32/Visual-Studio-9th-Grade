﻿Public Class start
    Private Sub btnSoyBoy_Click(sender As Object, e As EventArgs) Handles btnSoyBoy.Click
        g_decMultiplier = 0.1D
        g_intInterval = 1500
        main.Show()
        Me.Hide()
    End Sub

    Private Sub btnWeeb_Click(sender As Object, e As EventArgs) Handles btnWeeb.Click
        g_decMultiplier = 0.5D
        g_intInterval = 1000
        main.Show()
        Me.Hide()
    End Sub

    Private Sub btnAverageEnjoyer_Click(sender As Object, e As EventArgs) Handles btnAverageEnjoyer.Click
        g_decMultiplier = 1D
        g_intInterval = 750
        main.Show()
        Me.Hide()
    End Sub

    Private Sub btnChad_Click(sender As Object, e As EventArgs) Handles btnChad.Click
        g_decMultiplier = 3D
        g_intInterval = 500
        main.Show()
        Me.Hide()
    End Sub

    Private Sub btnOMG_Click(sender As Object, e As EventArgs) Handles btnOMG.Click
        g_decMultiplier = 10D
        g_intInterval = 350
        main.Show()
        Me.Hide()
    End Sub
End Class