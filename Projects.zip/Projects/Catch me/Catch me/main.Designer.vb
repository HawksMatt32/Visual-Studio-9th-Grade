﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class main
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnCatch = New System.Windows.Forms.Button()
        Me.tmrChange = New System.Windows.Forms.Timer(Me.components)
        Me.tmrSeconds = New System.Windows.Forms.Timer(Me.components)
        Me.lblTimer = New System.Windows.Forms.Label()
        Me.lblTimeLeft = New System.Windows.Forms.Label()
        Me.lblScore = New System.Windows.Forms.Label()
        Me.tmrCountdown = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'btnCatch
        '
        Me.btnCatch.Enabled = False
        Me.btnCatch.Location = New System.Drawing.Point(366, 218)
        Me.btnCatch.Name = "btnCatch"
        Me.btnCatch.Size = New System.Drawing.Size(100, 100)
        Me.btnCatch.TabIndex = 0
        Me.btnCatch.Text = "Catch me or suffer the consequences"
        Me.btnCatch.UseVisualStyleBackColor = True
        '
        'tmrChange
        '
        Me.tmrChange.Interval = 1000
        '
        'tmrSeconds
        '
        Me.tmrSeconds.Enabled = True
        Me.tmrSeconds.Interval = 1
        '
        'lblTimer
        '
        Me.lblTimer.AutoSize = True
        Me.lblTimer.Font = New System.Drawing.Font("Microsoft Sans Serif", 32.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTimer.Location = New System.Drawing.Point(12, 9)
        Me.lblTimer.Name = "lblTimer"
        Me.lblTimer.Size = New System.Drawing.Size(46, 51)
        Me.lblTimer.TabIndex = 1
        Me.lblTimer.Text = "3"
        '
        'lblTimeLeft
        '
        Me.lblTimeLeft.AutoSize = True
        Me.lblTimeLeft.Font = New System.Drawing.Font("Microsoft Sans Serif", 32.0!)
        Me.lblTimeLeft.Location = New System.Drawing.Point(1288, 9)
        Me.lblTimeLeft.Name = "lblTimeLeft"
        Me.lblTimeLeft.Size = New System.Drawing.Size(70, 51)
        Me.lblTimeLeft.TabIndex = 2
        Me.lblTimeLeft.Text = "30"
        Me.lblTimeLeft.TextAlign = System.Drawing.ContentAlignment.TopRight
        '
        'lblScore
        '
        Me.lblScore.AutoSize = True
        Me.lblScore.Font = New System.Drawing.Font("Microsoft Sans Serif", 32.0!)
        Me.lblScore.Location = New System.Drawing.Point(992, 460)
        Me.lblScore.Name = "lblScore"
        Me.lblScore.Size = New System.Drawing.Size(46, 51)
        Me.lblScore.TabIndex = 3
        Me.lblScore.Text = "0"
        '
        'tmrCountdown
        '
        Me.tmrCountdown.Interval = 2
        '
        'main
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1370, 749)
        Me.Controls.Add(Me.lblScore)
        Me.Controls.Add(Me.lblTimeLeft)
        Me.Controls.Add(Me.lblTimer)
        Me.Controls.Add(Me.btnCatch)
        Me.Name = "main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCatch As Button
    Friend WithEvents tmrChange As Timer
    Friend WithEvents tmrSeconds As Timer
    Friend WithEvents lblTimer As Label
    Friend WithEvents lblTimeLeft As Label
    Friend WithEvents lblScore As Label
    Friend WithEvents tmrCountdown As Timer
End Class
