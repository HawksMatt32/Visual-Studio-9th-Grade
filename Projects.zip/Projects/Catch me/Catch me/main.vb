﻿Public Class main
    Dim decScore As Decimal = 0
    Dim decTimeLeft As Decimal
    Dim rand As New Random
    Dim intNewLeft, intNewTop As Integer
    Private Sub btnCatch_Click(sender As Object, e As EventArgs) Handles btnCatch.Click
        decScore += (100 * g_decMultiplier)
        lblScore.Text = decScore.ToString
        intNewLeft = rand.Next(Me.Width - btnCatch.Width)
        intNewTop = rand.Next(Me.Height - btnCatch.Height)
        btnCatch.Left = intNewLeft
        btnCatch.Top = intNewTop
    End Sub

    Private Sub tmrPog_Tick(sender As Object, e As EventArgs) Handles tmrChange.Tick
        intNewLeft = rand.Next(Me.Width - btnCatch.Width)
        intNewTop = rand.Next(Me.Height - btnCatch.Height)
        btnCatch.Left = intNewLeft
        btnCatch.Top = intNewTop
    End Sub

    Private Sub main_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        tmrSeconds.Enabled = True
    End Sub

    Private Sub tmrSeconds_Tick(sender As Object, e As EventArgs) Handles tmrSeconds.Tick
        lblScore.Text = "0"
        g_decTimer -= 0.01D
        lblTimer.Text = g_decTimer.ToString
        If g_decTimer = 0 Then
            lblTimer.Visible = False
            tmrSeconds.Enabled = False
            tmrChange.Interval = g_intInterval
            tmrChange.Enabled = True
            btnCatch.Enabled = True
            decScore = 0
            tmrCountdown.Enabled = True
            decTimeLeft = 30
        End If
    End Sub

    Private Sub tmrCountdown_Tick(sender As Object, e As EventArgs) Handles tmrCountdown.Tick
        decTimeLeft -= 0.016D
        lblTimeLeft.Text = decTimeLeft.ToString

    End Sub
End Class