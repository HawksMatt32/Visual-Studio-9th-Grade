﻿Public Class Form1
    Dim intComputerWins As Integer = 0
    Dim intPlayerWins As Integer = 0
    Sub DetermineWinner(ByRef intPlayerNumber As Integer, ByRef intComputerNumber As Integer)
        'decide who wins
        If intComputerNumber = 1 And intPlayerNumber = 1 Then     'start of rotation
            MessageBox.Show("Tie")
        ElseIf intComputerNumber = 2 And intPlayerNumber = 2 Then
            MessageBox.Show("Tie")
        ElseIf intComputerNumber = 3 And intPlayerNumber = 3 Then
            MessageBox.Show("Tie")
        ElseIf intComputerNumber = 4 And intPlayerNumber = 4 Then
            MessageBox.Show("Tie")
        ElseIf intComputerNumber = 5 And intPlayerNumber = 5 Then
            MessageBox.Show("Tie")
        ElseIf intComputerNumber = 1 And intPlayerNumber = 2 Then 'start of rotation
            MessageBox.Show("You win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 2 And intPlayerNumber = 3 Then
            MessageBox.Show("You win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 3 And intPlayerNumber = 4 Then
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 4 And intPlayerNumber = 5 Then
            MessageBox.Show("You win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 5 And intPlayerNumber = 1 Then
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 1 And intPlayerNumber = 3 Then 'start of rotation
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 2 And intPlayerNumber = 4 Then
            MessageBox.Show("You Win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 3 And intPlayerNumber = 5 Then
            MessageBox.Show("You Win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 4 And intPlayerNumber = 1 Then
            MessageBox.Show("You Win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 5 And intPlayerNumber = 2 Then
            MessageBox.Show("You Win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 1 And intPlayerNumber = 4 Then 'start of rotation
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 2 And intPlayerNumber = 5 Then
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 3 And intPlayerNumber = 1 Then
            MessageBox.Show("You win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 4 And intPlayerNumber = 2 Then
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 5 And intPlayerNumber = 3 Then
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 1 And intPlayerNumber = 5 Then 'start of rotation
            MessageBox.Show("You win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 2 And intPlayerNumber = 1 Then
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 3 And intPlayerNumber = 2 Then
            MessageBox.Show("You lose!")
            intComputerWins += 1
            lblComputerWins.Text = CStr(intComputerWins)
        ElseIf intComputerNumber = 4 And intPlayerNumber = 3 Then
            MessageBox.Show("You win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        ElseIf intComputerNumber = 5 And intPlayerNumber = 4 Then
            MessageBox.Show("You win!")
            intPlayerWins += 1
            lblPlayerWins.Text = CStr(intPlayerWins)
        End If
    End Sub
    Sub UpdatePlayerImage(ByRef intPlayerNumber As Integer)
        'if number = number for weapon
        '   show weapon
        If intPlayerNumber = 1 Then
            picPlayerChoice.Image = My.Resources.rock
        ElseIf intPlayerNumber = 2 Then
            picPlayerChoice.Image = My.Resources.paper
        ElseIf intPlayerNumber = 3 Then
            picPlayerChoice.Image = My.Resources.scissors
        ElseIf intPlayerNumber = 4 Then
            picPlayerChoice.Image = My.Resources.lizard
        ElseIf intPlayerNumber = 5 Then
            picPlayerChoice.Image = My.Resources.spock
        End If

    End Sub
    Sub UpdateComputerImage(ByRef intComputerNumber As Integer)
        'if number = number for weapon
        '   show weapon
        If intComputerNumber = 1 Then
            picAiChoice.Image = My.Resources.rock
        ElseIf intComputerNumber = 2 Then
            picAiChoice.Image = My.Resources.paper
        ElseIf intComputerNumber = 3 Then
            picAiChoice.Image = My.Resources.scissors
        ElseIf intComputerNumber = 4 Then
            picAiChoice.Image = My.Resources.lizard
        ElseIf intComputerNumber = 5 Then
            picAiChoice.Image = My.Resources.spock
        End If
    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'closes form
        Me.Close()
    End Sub
    Function ComputerChoice(ByRef intComputerNumber As Integer, ByRef rand As Random) As Integer
        'makes new rand 1 - 5
        intComputerNumber = rand.Next(5) + 1

        Return intComputerNumber
    End Function
    Sub ChoiceName(ByRef intComputerNumber As Integer, ByRef intPlayerNumber As Integer,
                   ByRef strComputerChoice As String, ByRef strPlayerChoice As String)
        'decides the choice for computer
        If intComputerNumber = 1 Then
            strComputerChoice = "Rock"
        ElseIf intComputerNumber = 2 Then
            strComputerChoice = "Paper"
        ElseIf intComputerNumber = 3 Then
            strComputerChoice = "Scissors"
        ElseIf intComputerNumber = 4 Then
            strComputerChoice = "Lizard"
        ElseIf intComputerNumber = 5 Then
            strComputerChoice = "Spock"
        Else
            MessageBox.Show("error aw shucks")
        End If
        'decides the choice for player
        If intPlayerNumber = 1 Then
            strPlayerChoice = "Rock"
        ElseIf intPlayerNumber = 2 Then
            strPlayerChoice = "Paper"
        ElseIf intPlayerNumber = 3 Then
            strPlayerChoice = "Scissors"
        ElseIf intPlayerNumber = 4 Then
            strPlayerChoice = "Lizard"
        ElseIf intPlayerNumber = 5 Then
            strPlayerChoice = "Spock"
        Else
            MessageBox.Show("error aw shucks")
        End If

    End Sub

    Private Sub picRock_Click(sender As Object, e As EventArgs) Handles picRock.Click
        'selects weapon
        Dim intPlayerNumber = 1
        Dim intComputerNumber As Integer
        Dim rand As New Random
        Dim strComputerChoice As String
        Dim strPlayerChoice As String
        'generates computers number
        intComputerNumber = ComputerChoice(intComputerNumber, rand)
        'decodes names
        ChoiceName(intComputerNumber, intPlayerNumber, strComputerChoice, strPlayerChoice)
        'display computer choice
        lblAiChoice.Text = strComputerChoice
        'display player choice
        lblPlayerChoice.Text = strPlayerChoice
        'update images for computer and player
        UpdatePlayerImage(intPlayerNumber)
        UpdateComputerImage(intComputerNumber)
        'decide winner
        DetermineWinner(intPlayerNumber, intComputerNumber)

    End Sub

    Private Sub picScissors_Click(sender As Object, e As EventArgs) Handles picScissors.Click
        'selects weapon
        Dim intPlayerNumber = 3
        Dim intComputerNumber As Integer
        Dim rand As New Random
        Dim strComputerChoice As String
        Dim strPlayerChoice As String
        'generates computers number
        intComputerNumber = ComputerChoice(intComputerNumber, rand)
        'decodes names
        ChoiceName(intComputerNumber, intPlayerNumber, strComputerChoice, strPlayerChoice)
        'display computer choice
        lblAiChoice.Text = strComputerChoice
        'display player choice
        lblPlayerChoice.Text = strPlayerChoice
        'update images for computer and player
        UpdatePlayerImage(intPlayerNumber)
        UpdateComputerImage(intComputerNumber)
        'decide winner
        DetermineWinner(intPlayerNumber, intComputerNumber)

    End Sub

    Private Sub picLizard_Click(sender As Object, e As EventArgs) Handles picLizard.Click
        'selects weapon
        Dim intPlayerNumber = 4
        Dim intComputerNumber As Integer
        Dim rand As New Random
        Dim strComputerChoice As String
        Dim strPlayerChoice As String
        'generates computers number
        intComputerNumber = ComputerChoice(intComputerNumber, rand)
        'decodes names
        ChoiceName(intComputerNumber, intPlayerNumber, strComputerChoice, strPlayerChoice)
        'display computer choice
        lblAiChoice.Text = strComputerChoice
        'display player choice
        lblPlayerChoice.Text = strPlayerChoice
        'update images for computer and player
        UpdatePlayerImage(intPlayerNumber)
        UpdateComputerImage(intComputerNumber)
        'decide winner
        DetermineWinner(intPlayerNumber, intComputerNumber)
    End Sub
    Private Sub picSpock_Click(sender As Object, e As EventArgs) Handles picSpock.Click
        'selects weapon
        Dim intPlayerNumber = 5
        Dim intComputerNumber As Integer
        Dim rand As New Random
        Dim strComputerChoice As String
        Dim strPlayerChoice As String
        'generates computers number
        intComputerNumber = ComputerChoice(intComputerNumber, rand)
        'decodes names
        ChoiceName(intComputerNumber, intPlayerNumber, strComputerChoice, strPlayerChoice)
        'display computer choice
        lblAiChoice.Text = strComputerChoice
        'display player choice
        lblPlayerChoice.Text = strPlayerChoice
        'update images for computer and player
        UpdatePlayerImage(intPlayerNumber)
        UpdateComputerImage(intComputerNumber)
        'decide winner
        DetermineWinner(intPlayerNumber, intComputerNumber)

    End Sub
    Private Sub picPaper_Click(sender As Object, e As EventArgs) Handles picPaper.Click
        'selects weapon
        Dim intPlayerNumber = 2
        Dim intComputerNumber As Integer
        Dim rand As New Random
        Dim strComputerChoice As String
        Dim strPlayerChoice As String
        'generates computers number
        intComputerNumber = ComputerChoice(intComputerNumber, rand)
        'decodes names
        ChoiceName(intComputerNumber, intPlayerNumber, strComputerChoice, strPlayerChoice)
        'display computer choice
        lblAiChoice.Text = strComputerChoice
        'display player choice
        lblPlayerChoice.Text = strPlayerChoice
        'update images for computer and player
        UpdatePlayerImage(intPlayerNumber)
        UpdateComputerImage(intComputerNumber)
        'decide winner
        DetermineWinner(intPlayerNumber, intComputerNumber)
    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        'clear wins
        intComputerWins = 0
        intPlayerWins = 0
    End Sub
End Class
