﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.picLizard = New System.Windows.Forms.PictureBox()
        Me.picRock = New System.Windows.Forms.PictureBox()
        Me.picSpock = New System.Windows.Forms.PictureBox()
        Me.picPaper = New System.Windows.Forms.PictureBox()
        Me.picScissors = New System.Windows.Forms.PictureBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.picPlayerChoice = New System.Windows.Forms.PictureBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblPlayerWins = New System.Windows.Forms.Label()
        Me.lblPlayerChoice = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.picAiChoice = New System.Windows.Forms.PictureBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lblComputerWins = New System.Windows.Forms.Label()
        Me.lblAiChoice = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        CType(Me.picLizard, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picSpock, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picPaper, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picScissors, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.picPlayerChoice, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picAiChoice, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.picLizard)
        Me.GroupBox1.Controls.Add(Me.picRock)
        Me.GroupBox1.Controls.Add(Me.picSpock)
        Me.GroupBox1.Controls.Add(Me.picPaper)
        Me.GroupBox1.Controls.Add(Me.picScissors)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 0)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(223, 654)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Choose your weapon"
        '
        'picLizard
        '
        Me.picLizard.Image = Global.WindowsApplication1.My.Resources.Resources.lizard
        Me.picLizard.Location = New System.Drawing.Point(46, 397)
        Me.picLizard.Name = "picLizard"
        Me.picLizard.Size = New System.Drawing.Size(116, 112)
        Me.picLizard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picLizard.TabIndex = 1
        Me.picLizard.TabStop = False
        '
        'picRock
        '
        Me.picRock.Image = Global.WindowsApplication1.My.Resources.Resources.rock
        Me.picRock.Location = New System.Drawing.Point(46, 19)
        Me.picRock.Name = "picRock"
        Me.picRock.Size = New System.Drawing.Size(116, 112)
        Me.picRock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picRock.TabIndex = 4
        Me.picRock.TabStop = False
        '
        'picSpock
        '
        Me.picSpock.Image = Global.WindowsApplication1.My.Resources.Resources.spock
        Me.picSpock.Location = New System.Drawing.Point(46, 523)
        Me.picSpock.Name = "picSpock"
        Me.picSpock.Size = New System.Drawing.Size(116, 112)
        Me.picSpock.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picSpock.TabIndex = 0
        Me.picSpock.TabStop = False
        '
        'picPaper
        '
        Me.picPaper.Image = Global.WindowsApplication1.My.Resources.Resources.paper
        Me.picPaper.Location = New System.Drawing.Point(46, 145)
        Me.picPaper.Name = "picPaper"
        Me.picPaper.Size = New System.Drawing.Size(116, 112)
        Me.picPaper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPaper.TabIndex = 3
        Me.picPaper.TabStop = False
        '
        'picScissors
        '
        Me.picScissors.Image = Global.WindowsApplication1.My.Resources.Resources.scissors
        Me.picScissors.Location = New System.Drawing.Point(46, 271)
        Me.picScissors.Name = "picScissors"
        Me.picScissors.Size = New System.Drawing.Size(116, 112)
        Me.picScissors.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picScissors.TabIndex = 2
        Me.picScissors.TabStop = False
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnReset)
        Me.GroupBox2.Controls.Add(Me.btnClose)
        Me.GroupBox2.Controls.Add(Me.picPlayerChoice)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.lblPlayerWins)
        Me.GroupBox2.Controls.Add(Me.lblPlayerChoice)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.picAiChoice)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.lblComputerWins)
        Me.GroupBox2.Controls.Add(Me.lblAiChoice)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Location = New System.Drawing.Point(249, 0)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(196, 654)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(6, 288)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'picPlayerChoice
        '
        Me.picPlayerChoice.Location = New System.Drawing.Point(33, 410)
        Me.picPlayerChoice.Name = "picPlayerChoice"
        Me.picPlayerChoice.Size = New System.Drawing.Size(129, 126)
        Me.picPlayerChoice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPlayerChoice.TabIndex = 9
        Me.picPlayerChoice.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(27, 557)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(34, 13)
        Me.Label6.TabIndex = 11
        Me.Label6.Text = "Wins:"
        '
        'lblPlayerWins
        '
        Me.lblPlayerWins.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPlayerWins.Location = New System.Drawing.Point(67, 556)
        Me.lblPlayerWins.Name = "lblPlayerWins"
        Me.lblPlayerWins.Size = New System.Drawing.Size(55, 23)
        Me.lblPlayerWins.TabIndex = 10
        Me.lblPlayerWins.Text = "0"
        '
        'lblPlayerChoice
        '
        Me.lblPlayerChoice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblPlayerChoice.Location = New System.Drawing.Point(47, 367)
        Me.lblPlayerChoice.Name = "lblPlayerChoice"
        Me.lblPlayerChoice.Size = New System.Drawing.Size(100, 23)
        Me.lblPlayerChoice.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(59, 334)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(76, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Your Selection"
        '
        'picAiChoice
        '
        Me.picAiChoice.Location = New System.Drawing.Point(36, 83)
        Me.picAiChoice.Name = "picAiChoice"
        Me.picAiChoice.Size = New System.Drawing.Size(129, 126)
        Me.picAiChoice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picAiChoice.TabIndex = 5
        Me.picAiChoice.TabStop = False
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(33, 230)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(34, 13)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "Wins:"
        '
        'lblComputerWins
        '
        Me.lblComputerWins.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblComputerWins.Location = New System.Drawing.Point(70, 229)
        Me.lblComputerWins.Name = "lblComputerWins"
        Me.lblComputerWins.Size = New System.Drawing.Size(52, 23)
        Me.lblComputerWins.TabIndex = 5
        Me.lblComputerWins.Text = "0"
        '
        'lblAiChoice
        '
        Me.lblAiChoice.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAiChoice.Location = New System.Drawing.Point(50, 40)
        Me.lblAiChoice.Name = "lblAiChoice"
        Me.lblAiChoice.Size = New System.Drawing.Size(100, 23)
        Me.lblAiChoice.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(47, 21)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(106, 13)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Computer's Selection"
        '
        'btnReset
        '
        Me.btnReset.Location = New System.Drawing.Point(102, 288)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(75, 23)
        Me.btnReset.TabIndex = 2
        Me.btnReset.Text = "Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(456, 644)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.picLizard, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picSpock, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picPaper, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picScissors, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.picPlayerChoice, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picAiChoice, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents picRock As PictureBox
    Friend WithEvents picPaper As PictureBox
    Friend WithEvents picScissors As PictureBox
    Friend WithEvents picLizard As PictureBox
    Friend WithEvents picSpock As PictureBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnClose As Button
    Friend WithEvents picPlayerChoice As PictureBox
    Friend WithEvents Label6 As Label
    Friend WithEvents lblPlayerWins As Label
    Friend WithEvents lblPlayerChoice As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents picAiChoice As PictureBox
    Friend WithEvents Label5 As Label
    Friend WithEvents lblComputerWins As Label
    Friend WithEvents lblAiChoice As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnReset As Button
End Class
