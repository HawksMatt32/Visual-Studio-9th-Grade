﻿Public Class AudioBooks
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If lstBooks.SelectedIndex = 0 Then
            AddBook(0, intNothing)
        ElseIf lstBooks.SelectedIndex = 1 Then
            AddBook(1, intNothing)
        ElseIf lstBooks.SelectedIndex = 2 Then
            AddBook(2, intNothing)
        ElseIf lstBooks.SelectedIndex = 3 Then
            AddBook(3, intNothing)
        Else
            MessageBox.Show("error line 12 audio")
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class