﻿Public Class PrintBooks
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        If lstBooks.SelectedIndex = 0 Then
            AddBook(intNothing, 0)
        ElseIf lstBooks.SelectedIndex = 1 Then
            AddBook(intNothing, 1)
        ElseIf lstBooks.SelectedIndex = 2 Then
            AddBook(intNothing, 2)
        ElseIf lstBooks.SelectedIndex = 3 Then
            AddBook(intNothing, 3)
        Else
            MessageBox.Show("error line 12 print")
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub
End Class