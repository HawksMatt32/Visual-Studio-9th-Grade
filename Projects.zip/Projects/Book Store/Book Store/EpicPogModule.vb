﻿Module EpicPogModule
    Public intNothing As Integer = 10
    Public Const decTAX_RATE = 0.07D
    Function BookValue(ByRef intAudioNumber As Integer, ByRef intPrintNumber As Integer) As Decimal
        If intAudioNumber = intNothing Then
            If intPrintNumber = 0 Then
                Return 20.5D
            ElseIf intPrintNumber = 1 Then
                Return 25.75D
            ElseIf intPrintNumber = 2 Then
                Return 15.25D
            ElseIf intPrintNumber = 3 Then
                Return 12.25D
            End If
        ElseIf intPrintNumber = intNothing Then
            If intAudioNumber = 0 Then
                Return 17.75D
            ElseIf intAudioNumber = 1 Then
                Return 10.99D
            ElseIf intAudioNumber = 2 Then
                Return 10.99D
            ElseIf intAudioNumber = 3 Then
                Return 15.99D
            End If
        End If
    End Function
    Sub AddBook(ByRef intAudioNumber As Integer, ByRef intPrintNumber As Integer)
        Dim decSubtotal As Decimal = 0
        Dim decTax As Decimal = 0
        Dim decShipping As Decimal = 0
        Dim decTotal As Decimal = 0
        If intAudioNumber = intNothing Then
            If intPrintNumber = 0 Then
                ShoppingCart.lstProducts.Items.Add("Why Fortnite is Bad (Print)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            ElseIf intPrintNumber = 1 Then
                ShoppingCart.lstProducts.Items.Add("Should you be Eating at the Krusty Krab (Print)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            ElseIf intPrintNumber = 2 Then
                ShoppingCart.lstProducts.Items.Add("Why you Shouldn't Mine at Night (Print)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            ElseIf intPrintNumber = 3 Then
                ShoppingCart.lstProducts.Items.Add("Stop Playing Fortnite (Print)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            Else
                MessageBox.Show("error line 49")
            End If
        ElseIf intPrintNumber = intNothing Then
            If intAudioNumber = 0 Then
                ShoppingCart.lstProducts.Items.Add("How I Met Your Mother (Audio)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            ElseIf intAudioNumber = 1 Then
                ShoppingCart.lstProducts.Items.Add("When do I vote the Imposter? (Audio)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            ElseIf intAudioNumber = 2 Then
                ShoppingCart.lstProducts.Items.Add("The Science Behind Among Us (Audio)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            ElseIf intAudioNumber = 3 Then
                ShoppingCart.lstProducts.Items.Add("How to Stay Calm as a Crewmate (Audio)")
                CalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)
            Else
                MessageBox.Show("error line 51")
            End If
        Else
            MessageBox.Show("error line 54")
        End If
    End Sub
    Sub CalcTotal(ByRef decSubtotal As Decimal, ByRef decTax As Decimal, ByRef decShipping As Decimal,
                  ByRef decTotal As Decimal, intAudioNumber As Integer, ByRef intPrintNumber As Integer)
        decSubtotal = BookValue(intAudioNumber, intPrintNumber) + CDec(ShoppingCart.lblSubtotal.Text)
        ShoppingCart.lblSubtotal.Text = decSubtotal.ToString("C")
        decTax = decSubtotal * decTAX_RATE
        ShoppingCart.lblTax.Text = decTax.ToString("C")
        decShipping = 14.99D
        ShoppingCart.lblShipping.Text = decShipping.ToString("C")
        decTotal = decSubtotal + decTax + decShipping
        ShoppingCart.lblTotal.Text = decTotal.ToString("C")
    End Sub
    Sub ReCalcTotal(ByRef decSubtotal As Decimal, ByRef decTax As Decimal, ByRef decShipping As Decimal,
                  ByRef decTotal As Decimal, intAudioNumber As Integer, ByRef intPrintNumber As Integer)
        decSubtotal = CDec(ShoppingCart.lblSubtotal.Text)
        decTax = decSubtotal * decTAX_RATE
        ShoppingCart.lblTax.Text = decTax.ToString("C")
        If decSubtotal = 0 Then
            decShipping = 0
        Else
            decShipping = 14.99D
        End If
        ShoppingCart.lblShipping.Text = decShipping.ToString("C")
        decTotal = decSubtotal + decTax + decShipping
        ShoppingCart.lblTotal.Text = decTotal.ToString("C")
    End Sub
End Module
