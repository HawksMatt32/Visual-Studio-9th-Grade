﻿Public Class ShoppingCart
    Private Sub mnuProductsPrint_Click(sender As Object, e As EventArgs) Handles mnuProductsPrint.Click
        Dim frmPrint As New PrintBooks
        frmPrint.ShowDialog()
    End Sub
    Private Sub mnuProductsAudio_Click(sender As Object, e As EventArgs) Handles mnuProductsAudio.Click
        Dim frmAudio As New AudioBooks
        frmAudio.ShowDialog()
    End Sub

    Private Sub ShoppingCart_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        Dim intPrintNumber As Integer
        Dim intAudioNumber As Integer
        If lstProducts.GetItemText(lstProducts.SelectedItem) = "Why Fortnite is Bad (Print)" Then
            intPrintNumber = 0
            intAudioNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        ElseIf lstProducts.GetItemText(lstProducts.SelectedItem) = "Should you be Eating at the Krusty Krab (Print)" Then
            intPrintNumber = 1
            intAudioNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        ElseIf lstProducts.GetItemText(lstProducts.SelectedItem) = "Why you Shouldn't Mine at Night (Print)" Then
            intPrintNumber = 2
            intAudioNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        ElseIf lstProducts.GetItemText(lstProducts.SelectedItem) = "Stop Playing Fortnite (Print)" Then
            intPrintNumber = 3
            intAudioNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        ElseIf lstProducts.GetItemText(lstProducts.SelectedItem) = "How I Met Your Mother (Audio)" Then
            intAudioNumber = 0
            intPrintNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        ElseIf lstProducts.GetItemText(lstProducts.SelectedItem) = "When do I vote the Imposter? (Audio)" Then
            intAudioNumber = 1
            intPrintNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        ElseIf lstProducts.GetItemText(lstProducts.SelectedItem) = "The Science Behind Among Us (Audio)" Then
            intAudioNumber = 2
            intPrintNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        ElseIf lstProducts.GetItemText(lstProducts.SelectedItem) = "How to Stay Calm as a Crewmate (Audio)" Then
            intAudioNumber = 3
            intPrintNumber = 10
            lblSubtotal.Text = CStr(CDec(lblSubtotal.Text) - BookValue(intAudioNumber, intPrintNumber))
        End If
        lstProducts.Items.Remove(lstProducts.SelectedItem)
        Dim decSubtotal As Decimal = 0
        Dim decTax As Decimal = 0
        Dim decShipping As Decimal = 0
        Dim decTotal As Decimal = 0
        ReCalcTotal(decSubtotal, decTax, decShipping, decTotal, intAudioNumber, intPrintNumber)

    End Sub

    Private Sub mnuHelpAbout_Click(sender As Object, e As EventArgs) Handles mnuHelpAbout.Click
        MessageBox.Show("pro among us strats")
    End Sub

    Private Sub mnuFileReset_Click(sender As Object, e As EventArgs) Handles mnuFileReset.Click
        lstProducts.Items.Clear()
        lblShipping.Text = "0"
        lblSubtotal.Text = "0"
        lblTax.Text = "0"
        lblTotal.Text = "0"
    End Sub

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()

    End Sub
End Class
