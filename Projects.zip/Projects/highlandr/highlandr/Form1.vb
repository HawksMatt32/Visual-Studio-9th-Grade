﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'display todays date and time to labels
        lblDateToday.Text = Now.ToString("D")
        lblTimeToday.Text = Now.ToString("T")
    End Sub

    Private Sub Label4_Click(sender As Object, e As EventArgs) Handles Label4.Click

    End Sub

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles Label3.Click

    End Sub

    Private Sub lblDateToday_Click(sender As Object, e As EventArgs) Handles lblDateToday.Click

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        'declare variables for calc
        Dim decRoomCharges As Decimal       ' room charges
        Dim decAddCharges As Decimal        ' additional charges
        Dim decSubtotal As Decimal          ' Subtotal
        Dim decTax As Decimal               ' Tax
        Dim decTotal As Decimal             ' Total of ALL
        Dim decTAX_RATE As Decimal = 0.08D  ' Tax rate

        Try
            Try
                'calculate and display room charges
                decRoomCharges = CDec(txtNights.Text) * CDec(txtNightlyCharge.Text)
                lblRoomCharges.Text = decRoomCharges.ToString("c")
            Catch ex As Exception
                MessageBox.Show("Alphanumeric characters in Room Info")
            End Try

            Try
                'calculate additional charges
                decAddCharges = CDec(txtRoomService.Text) + CDec(txtTelephone.Text) + CDec(txtMisc.Text)
                lblAddCharges.Text = decAddCharges.ToString("c")
            Catch ex As Exception
                MessageBox.Show("Alphanumeric characters in Additional Charges")
            End Try

            Try
                'calculate subtotal
                decSubtotal = decRoomCharges + decAddCharges
                lblSubtotal.Text = decSubtotal.ToString("c")
            Catch ex As Exception
                MessageBox.Show("Alphanumeric characters in subtotal Charges")
            End Try

            Try
                'calculate tax
                decTax = decSubtotal * decTAX_RATE
                lblTax.Text = decTax.ToString("c")
            Catch ex As Exception
                MessageBox.Show("Error while Calculating subtotal * tax rate")
            End Try

            Try
                'calculate total
                decTotal = decSubtotal + decTax
                lblTotal.Text = decTotal.ToString("c")
            Catch ex As Exception
                MessageBox.Show("Error while Calculating subtotal + tax")
            End Try

        Catch ex As Exception
            MessageBox.Show("All input must be valid numeric values")
        End Try

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clear room info
        txtNightlyCharge.Clear()
        txtNights.Clear()

        'clear additional charges
        txtMisc.Clear()
        txtTelephone.Clear()
        txtRoomService.Clear()

        'clear dectotal fields
        lblAddCharges.Text = String.Empty
        lblRoomCharges.Text = String.Empty
        lblSubtotal.Text = String.Empty
        lblTotal.Text = String.Empty
        lblTax.Text = String.Empty

        'display date and time
        lblDateToday.Text = Now.ToString("D")
        lblTimeToday.Text = Now.ToString("T")

        'refocus
        txtNights.Focus()
    End Sub
End Class
