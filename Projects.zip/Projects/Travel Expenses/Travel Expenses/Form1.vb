﻿Public Class Form1
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        'closes form 
        Me.Close()

    End Sub
    Function ValidInputs() As Boolean
        'validates all inputs

        ' rules-------------------------------------------------------------

        ' Do not accept negative numbers for any dollar amount or for 

        ' miles driven in a private vehicle.

        ' Do Not accept numbers less than 1 for the number of days.
        Try
            If CInt(txtAirfare.Text) < 0 Or
            CInt(txtCarRental.Text) < 0 Or
            CInt(txtParkingFees.Text) < 0 Or
            CInt(txtTaxiCharges.Text) < 0 Or
            CInt(txtMilesDriven.Text) < 0 Or
            CInt(txtDays.Text) < 1 Or
            CInt(txtMealCount.Text) < 0 Or
            CInt(txtSeminarFees.Text) < 0 Or
            CInt(txtLodgingFees.Text) < 0 Then
                MessageBox.Show("Bruh dont put in negatives")
                Return False
            Else
                Return True
            End If
        Catch ex As Exception
            MessageBox.Show("Bruh put in a number")
            Return False
        End Try
    End Function
    Function CalcMeals(ByRef intDays As Integer) As Integer
        'calculate meals
        Return 37 * intDays
    End Function
    Function CalcMilage(ByRef decMilesDriven As Decimal) As Decimal
        'calculate miles driven
        Return decMilesDriven * 0.27D
    End Function
    Function CalcParkingFees(ByRef intDays As Integer) As Decimal
        'calculate parking fees
        Return intDays * 10
    End Function
    Function CalcLodging(ByRef intDays As Integer) As Decimal
        'calculate lodging
        Return intDays * 95
    End Function
    Function CalcTaxiFees(ByRef intDays As Integer) As Decimal
        'calculate taxi fees
        Return intDays * 20
    End Function
    Function CalcTotalReimbursement(ByRef decReimbursed As Decimal, ByRef decTotalDue As Decimal, ByRef decAllowed As Decimal) As Decimal
        'if under 
        If decTotalDue <= decAllowed Then
            decReimbursed = decTotalDue
            Return decReimbursed
        End If
    End Function
    Function CalcUnallowed(ByRef decTotalDue As Decimal, ByRef decAllowed As Decimal, ByRef decUnallowed As Decimal) As Decimal
        If decTotalDue > decAllowed Then
            decUnallowed = decAllowed - decTotalDue
            Return decUnallowed
        End If
    End Function
    Function CalcSaved(ByRef decTotalDue As Decimal, ByRef decAllowed As Decimal, ByRef decSaved As Decimal) As Decimal
        If decAllowed < decTotalDue Then
            Return 0
        Else
            decSaved = decAllowed - decTotalDue
        End If
        Return decSaved
    End Function
    Function CalcAllowed(ByRef intDays As Integer,
                         ByRef decAllowed As Decimal, ByRef decMilesDriven As Decimal) As Decimal
        decAllowed = 0
        decAllowed += CalcMeals(intDays)
        decAllowed += CalcParkingFees(intDays)
        decAllowed += CalcTaxiFees(intDays)
        decAllowed += CalcLodging(intDays)
        decAllowed += CalcMilage(decMilesDriven)
        Return decAllowed
    End Function
    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        'calculate and output data PUNK!
        If ValidInputs() Then
            'variable declaration
            Dim intDays As Integer = CInt(txtDays.Text)
            Dim intMeals As Integer = CInt(txtMealCount.Text)
            Dim decMilesDriven As Decimal = CInt(txtMilesDriven.Text)
            Dim decParkingFees As Decimal = CInt(txtParkingFees.Text)
            Dim decLodgingFees As Decimal = CInt(txtLodgingFees.Text)
            Dim decTaxiFees As Decimal = CInt(txtTaxiCharges.Text)
            Dim decSeminarFees As Decimal = CInt(txtSeminarFees.Text)
            Dim decAirfareFees As Decimal = CInt(txtAirfare.Text)
            Dim decCarRentalFees As Decimal = CInt(txtCarRental.Text)
            'calculate total
            Dim decTotalDue As Decimal = decLodgingFees + decTaxiFees + decParkingFees + decSeminarFees + decAirfareFees + decCarRentalFees
            Dim decAllowed As Decimal = CalcAllowed(intDays, decAllowed, decMilesDriven)
            Dim decUnallowed As Decimal
            Dim decSaved As Decimal
            'display math
            lblAllowedExpenses.Text = decAllowed.ToString("C")
            lblTotalExpenses.Text = decTotalDue.ToString("C")
            lblSaved.Text = CalcSaved(decTotalDue, decAllowed, decSaved).ToString("C")
            lblExcess.Text = CalcUnallowed(decTotalDue, decAllowed, decUnallowed).ToString("C")


        End If
    End Sub
End Class
