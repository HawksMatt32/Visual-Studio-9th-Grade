﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtCarRental = New System.Windows.Forms.TextBox()
        Me.txtTaxiCharges = New System.Windows.Forms.TextBox()
        Me.txtParkingFees = New System.Windows.Forms.TextBox()
        Me.txtMilesDriven = New System.Windows.Forms.TextBox()
        Me.txtAirfare = New System.Windows.Forms.TextBox()
        Me.txtDays = New System.Windows.Forms.TextBox()
        Me.txtMealCount = New System.Windows.Forms.TextBox()
        Me.txtLodgingFees = New System.Windows.Forms.TextBox()
        Me.txtSeminarFees = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.lblExcess = New System.Windows.Forms.Label()
        Me.lblSaved = New System.Windows.Forms.Label()
        Me.lblAllowedExpenses = New System.Windows.Forms.Label()
        Me.lblTotalExpenses = New System.Windows.Forms.Label()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(122, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Number of Days on Trip:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(68, 49)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Airfare Fees:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(48, 81)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(86, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Car Rental Fees:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(66, 113)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(68, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Miles Driven:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(62, 145)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(72, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Parking Fees:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(62, 177)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(72, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Taxi Charges;"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(70, 209)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Meal Count:"
        '
        'txtCarRental
        '
        Me.txtCarRental.Location = New System.Drawing.Point(139, 78)
        Me.txtCarRental.Name = "txtCarRental"
        Me.txtCarRental.Size = New System.Drawing.Size(100, 20)
        Me.txtCarRental.TabIndex = 2
        '
        'txtTaxiCharges
        '
        Me.txtTaxiCharges.Location = New System.Drawing.Point(139, 174)
        Me.txtTaxiCharges.Name = "txtTaxiCharges"
        Me.txtTaxiCharges.Size = New System.Drawing.Size(100, 20)
        Me.txtTaxiCharges.TabIndex = 5
        '
        'txtParkingFees
        '
        Me.txtParkingFees.Location = New System.Drawing.Point(139, 142)
        Me.txtParkingFees.Name = "txtParkingFees"
        Me.txtParkingFees.Size = New System.Drawing.Size(100, 20)
        Me.txtParkingFees.TabIndex = 4
        '
        'txtMilesDriven
        '
        Me.txtMilesDriven.Location = New System.Drawing.Point(139, 110)
        Me.txtMilesDriven.Name = "txtMilesDriven"
        Me.txtMilesDriven.Size = New System.Drawing.Size(100, 20)
        Me.txtMilesDriven.TabIndex = 3
        '
        'txtAirfare
        '
        Me.txtAirfare.Location = New System.Drawing.Point(139, 46)
        Me.txtAirfare.Name = "txtAirfare"
        Me.txtAirfare.Size = New System.Drawing.Size(100, 20)
        Me.txtAirfare.TabIndex = 1
        '
        'txtDays
        '
        Me.txtDays.Location = New System.Drawing.Point(139, 14)
        Me.txtDays.Name = "txtDays"
        Me.txtDays.Size = New System.Drawing.Size(100, 20)
        Me.txtDays.TabIndex = 0
        '
        'txtMealCount
        '
        Me.txtMealCount.Location = New System.Drawing.Point(139, 206)
        Me.txtMealCount.Name = "txtMealCount"
        Me.txtMealCount.Size = New System.Drawing.Size(100, 20)
        Me.txtMealCount.TabIndex = 6
        '
        'txtLodgingFees
        '
        Me.txtLodgingFees.Location = New System.Drawing.Point(139, 270)
        Me.txtLodgingFees.Name = "txtLodgingFees"
        Me.txtLodgingFees.Size = New System.Drawing.Size(100, 20)
        Me.txtLodgingFees.TabIndex = 8
        '
        'txtSeminarFees
        '
        Me.txtSeminarFees.Location = New System.Drawing.Point(139, 238)
        Me.txtSeminarFees.Name = "txtSeminarFees"
        Me.txtSeminarFees.Size = New System.Drawing.Size(100, 20)
        Me.txtSeminarFees.TabIndex = 7
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(60, 273)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(74, 13)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Lodging Fees:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(60, 241)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(74, 13)
        Me.Label9.TabIndex = 14
        Me.Label9.Text = "Seminar Fees:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(332, 117)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 13)
        Me.Label10.TabIndex = 18
        Me.Label10.Text = "Amount Saved:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(279, 85)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(133, 13)
        Me.Label11.TabIndex = 19
        Me.Label11.Text = "Excess what must be paid:"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(281, 53)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(131, 13)
        Me.Label12.TabIndex = 20
        Me.Label12.Text = "Total Allowable Expenses:"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(329, 21)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(83, 13)
        Me.Label13.TabIndex = 21
        Me.Label13.Text = "Total Expenses:"
        '
        'lblExcess
        '
        Me.lblExcess.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblExcess.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblExcess.Location = New System.Drawing.Point(418, 81)
        Me.lblExcess.Name = "lblExcess"
        Me.lblExcess.Size = New System.Drawing.Size(137, 29)
        Me.lblExcess.TabIndex = 22
        Me.lblExcess.Text = " "
        '
        'lblSaved
        '
        Me.lblSaved.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblSaved.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblSaved.Location = New System.Drawing.Point(418, 113)
        Me.lblSaved.Name = "lblSaved"
        Me.lblSaved.Size = New System.Drawing.Size(137, 29)
        Me.lblSaved.TabIndex = 23
        Me.lblSaved.Text = " "
        '
        'lblAllowedExpenses
        '
        Me.lblAllowedExpenses.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblAllowedExpenses.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAllowedExpenses.Location = New System.Drawing.Point(418, 49)
        Me.lblAllowedExpenses.Name = "lblAllowedExpenses"
        Me.lblAllowedExpenses.Size = New System.Drawing.Size(137, 29)
        Me.lblAllowedExpenses.TabIndex = 24
        Me.lblAllowedExpenses.Text = " "
        '
        'lblTotalExpenses
        '
        Me.lblTotalExpenses.BackColor = System.Drawing.SystemColors.ControlLight
        Me.lblTotalExpenses.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalExpenses.Location = New System.Drawing.Point(418, 16)
        Me.lblTotalExpenses.Name = "lblTotalExpenses"
        Me.lblTotalExpenses.Size = New System.Drawing.Size(137, 29)
        Me.lblTotalExpenses.TabIndex = 25
        Me.lblTotalExpenses.Text = " "
        '
        'btnCalc
        '
        Me.btnCalc.Location = New System.Drawing.Point(282, 229)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(250, 50)
        Me.btnCalc.TabIndex = 11
        Me.btnCalc.Text = "Calculate"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(282, 164)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(250, 50)
        Me.btnClose.TabIndex = 9
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(587, 311)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnCalc)
        Me.Controls.Add(Me.lblTotalExpenses)
        Me.Controls.Add(Me.lblAllowedExpenses)
        Me.Controls.Add(Me.lblSaved)
        Me.Controls.Add(Me.lblExcess)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.txtLodgingFees)
        Me.Controls.Add(Me.txtSeminarFees)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.txtMealCount)
        Me.Controls.Add(Me.txtDays)
        Me.Controls.Add(Me.txtAirfare)
        Me.Controls.Add(Me.txtMilesDriven)
        Me.Controls.Add(Me.txtParkingFees)
        Me.Controls.Add(Me.txtTaxiCharges)
        Me.Controls.Add(Me.txtCarRental)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Travel Expenses"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents txtCarRental As TextBox
    Friend WithEvents txtTaxiCharges As TextBox
    Friend WithEvents txtParkingFees As TextBox
    Friend WithEvents txtMilesDriven As TextBox
    Friend WithEvents txtAirfare As TextBox
    Friend WithEvents txtDays As TextBox
    Friend WithEvents txtMealCount As TextBox
    Friend WithEvents txtLodgingFees As TextBox
    Friend WithEvents txtSeminarFees As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents lblExcess As Label
    Friend WithEvents lblSaved As Label
    Friend WithEvents lblAllowedExpenses As Label
    Friend WithEvents lblTotalExpenses As Label
    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClose As Button
End Class
