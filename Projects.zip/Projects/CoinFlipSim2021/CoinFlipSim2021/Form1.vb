﻿Public Class Form1
    Private Sub PictureBox1_Click(sender As Object, e As EventArgs) Handles picHeads.Click

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles btnTails.Click
        'make picheads invisible, while pictails visible
        picHeads.Visible = False
        picTail.Visible = True
    End Sub

    Private Sub btnHeads_Click(sender As Object, e As EventArgs) Handles btnHeads.Click
        'makes picHeads visible, while picTails invisible
        picHeads.Visible = True
        picTail.Visible = False

    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'extis form
        Me.Close()

    End Sub
End Class
