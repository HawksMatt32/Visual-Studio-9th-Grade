﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnTails = New System.Windows.Forms.Button()
        Me.btnHeads = New System.Windows.Forms.Button()
        Me.picHeads = New System.Windows.Forms.PictureBox()
        Me.picTail = New System.Windows.Forms.PictureBox()
        CType(Me.picHeads, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTail, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(187, 290)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 0
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnTails
        '
        Me.btnTails.Location = New System.Drawing.Point(304, 264)
        Me.btnTails.Name = "btnTails"
        Me.btnTails.Size = New System.Drawing.Size(83, 23)
        Me.btnTails.TabIndex = 1
        Me.btnTails.Text = "ShowTails"
        Me.btnTails.UseVisualStyleBackColor = True
        '
        'btnHeads
        '
        Me.btnHeads.Location = New System.Drawing.Point(62, 264)
        Me.btnHeads.Name = "btnHeads"
        Me.btnHeads.Size = New System.Drawing.Size(83, 23)
        Me.btnHeads.TabIndex = 2
        Me.btnHeads.Text = "Show Heads"
        Me.btnHeads.UseVisualStyleBackColor = True
        '
        'picHeads
        '
        Me.picHeads.Image = CType(resources.GetObject("picHeads.Image"), System.Drawing.Image)
        Me.picHeads.Location = New System.Drawing.Point(79, 77)
        Me.picHeads.Name = "picHeads"
        Me.picHeads.Size = New System.Drawing.Size(100, 90)
        Me.picHeads.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picHeads.TabIndex = 3
        Me.picHeads.TabStop = False
        '
        'picTail
        '
        Me.picTail.Image = CType(resources.GetObject("picTail.Image"), System.Drawing.Image)
        Me.picTail.Location = New System.Drawing.Point(269, 77)
        Me.picTail.Name = "picTail"
        Me.picTail.Size = New System.Drawing.Size(102, 90)
        Me.picTail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picTail.TabIndex = 4
        Me.picTail.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(448, 325)
        Me.Controls.Add(Me.picTail)
        Me.Controls.Add(Me.picHeads)
        Me.Controls.Add(Me.btnHeads)
        Me.Controls.Add(Me.btnTails)
        Me.Controls.Add(Me.btnExit)
        Me.Name = "Form1"
        Me.Text = "Coin Flip Simulator 2021: Platinum Edition"
        CType(Me.picHeads, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTail, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnExit As Button
    Friend WithEvents btnTails As Button
    Friend WithEvents btnHeads As Button
    Friend WithEvents picHeads As PictureBox
    Friend WithEvents picTail As PictureBox
End Class
