﻿Public Class Form1 'vaiable declaration
    Dim lngTryCounter As Long = 0
    Dim lngGuess As Long
    Dim lngMax As Long = 100
    Dim lngToBeGuessed As Long
    Dim rand As New Random

    Private Sub Label3_Click(sender As Object, e As EventArgs) Handles lblOut.Click

    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub btnTry_Click(sender As Object, e As EventArgs) Handles btnTry.Click
        'on load ask for max and set random number
        Try
            If Long.TryParse(InputBox("Range of numbers to guess(Max):", "Input", "100"), lngMax) Then
                lngToBeGuessed = rand.Next(CInt(lngMax))

                'start loop
                Do Until lngGuess = lngToBeGuessed 'tests if guess is equal to random
                    'ask for guess

                    If Long.TryParse(InputBox("Guess: ", "Input"), lngGuess) Then
                        If lngGuess = 123456789 Then
                            MessageBox.Show(CStr(lngToBeGuessed))
                            'add to try counter
                            lngTryCounter += 1
                            lblOut.Text = CStr(lngTryCounter)
                            'if guess is too high or low display it
                            If lngGuess > lngToBeGuessed Then
                                MessageBox.Show("Too high")
                            ElseIf lngGuess < lngToBeGuessed Then
                                MessageBox.Show("Too low")
                            Else
                                MessageBox.Show("correct")
                                lngTryCounter = 0
                                lblOut.Text = "Cleared..."
                            End If
                        Else
                            'add to try counter
                            lngTryCounter += 1
                            lblOut.Text = CStr(lngTryCounter)
                            'if guess is too high or low display it
                            If lngGuess > lngToBeGuessed Then
                                MessageBox.Show("Too high")
                            ElseIf lngGuess < lngToBeGuessed Then
                                MessageBox.Show("Too low")
                            Else
                                MessageBox.Show("correct")
                                lngTryCounter = 0
                                lblOut.Text = "Cleared..."
                            End If
                        End If

                    Else
                    End If
                Loop
            Else
                MessageBox.Show("Please input a number")
            End If
        Catch ex As Exception
            MessageBox.Show("error ")
        End Try







    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnOut.Click
        'closes form
        Me.Close()

    End Sub
End Class
