﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblOut = New System.Windows.Forms.Label()
        Me.btnOut = New System.Windows.Forms.Button()
        Me.btnTry = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(0, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(33, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Tries:"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblOut
        '
        Me.lblOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOut.Location = New System.Drawing.Point(42, 20)
        Me.lblOut.Name = "lblOut"
        Me.lblOut.Size = New System.Drawing.Size(196, 20)
        Me.lblOut.TabIndex = 3
        '
        'btnOut
        '
        Me.btnOut.Location = New System.Drawing.Point(150, 46)
        Me.btnOut.Name = "btnOut"
        Me.btnOut.Size = New System.Drawing.Size(75, 23)
        Me.btnOut.TabIndex = 4
        Me.btnOut.Text = "Get OUT"
        Me.btnOut.UseVisualStyleBackColor = True
        '
        'btnTry
        '
        Me.btnTry.Location = New System.Drawing.Point(26, 46)
        Me.btnTry.Name = "btnTry"
        Me.btnTry.Size = New System.Drawing.Size(75, 23)
        Me.btnTry.TabIndex = 5
        Me.btnTry.Text = "Try"
        Me.btnTry.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(250, 88)
        Me.Controls.Add(Me.btnTry)
        Me.Controls.Add(Me.btnOut)
        Me.Controls.Add(Me.lblOut)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Form1"
        Me.Text = "Number Guesser"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label2 As Label
    Friend WithEvents lblOut As Label
    Friend WithEvents btnOut As Button
    Friend WithEvents btnTry As Button
End Class
