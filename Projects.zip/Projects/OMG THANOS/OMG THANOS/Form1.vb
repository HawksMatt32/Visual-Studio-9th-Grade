﻿Public Class Form1
    Function ValidateInputs(ByRef strFirst As String, ByRef strLast As String, ByRef strPhone As String,
                            ByRef intPanels As Integer, ByRef decDeposit As Decimal,
                            ByRef boolExpressInstall As Boolean) As Boolean
        'if i have something in me continue
        If strFirst.Length > 0 Then
            If strLast.Length > 0 Then
                If strPhone.Length > 0 Then
                    'if i am integer set me as variable
                    If Integer.TryParse(txtPanels.Text, intPanels) Then
                        If Decimal.TryParse(txtDeposit.Text, decDeposit) Then
                            'if i am checked check me 
                            If chkExpress.Checked = True Then
                                boolExpressInstall = True
                                'if i am more than 1 and less than 1000
                                If intPanels > 1 And intPanels < 1000 Then
                                    'if deposit more than 0 return true
                                    If decDeposit > 0 Then
                                        Return True
                                        'error messages
                                    Else
                                        MessageBox.Show("Please put something in the deposit.")
                                        Return False
                                    End If
                                Else
                                    MessageBox.Show("Please put a valid number in panels")
                                    Return False
                                End If
                            Else
                                boolExpressInstall = False
                                If intPanels > 1 And intPanels < 1000 Then
                                    If decDeposit > 0 Then
                                        Return True
                                    Else
                                        MessageBox.Show("Please put something in the deposit.")
                                        Return False
                                    End If
                                Else
                                    MessageBox.Show("Please put a valid number in panels")
                                    Return False
                                End If
                            End If
                        Else
                            MessageBox.Show("Please put a number in deposit")
                            Return False
                        End If
                    Else
                        MessageBox.Show("Please put a number in panels.")
                        Return False
                    End If
                Else
                    MessageBox.Show("Please put something in phone")
                    Return False
                End If
            Else
                MessageBox.Show("Please put something in Last")
                Return False
            End If
        Else
            MessageBox.Show("Please put something in first")
            Return False
        End If
    End Function
    Function CalculateValues(ByVal intPanels As Integer, ByVal decDeposit As Decimal,
                             ByVal decTotal As Decimal, ByVal intAddPanels As Integer) As Decimal
        'additional panels = panels -2
        'total equals 2000 + 300 * additional panels
        'if check express checked then add 5% of self
        intAddPanels = intPanels - 2
        If chkExpress.Checked = True Then
            decTotal = 2000 + (300 * intAddPanels)
            decTotal = decTotal + (decTotal * 0.05D)
            Return decTotal
        Else
            decTotal = 2000 + (300 * intAddPanels)
            Return decTotal
        End If
    End Function
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'make output box invis
        grpOut.Visible = False
    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs)
        'clearslots of stuff
        'clear text boxes
        txtDeposit.Clear()
        txtFirst.Clear()
        txtLast.Clear()
        txtPanels.Clear()
        txtPhone.Clear()
        'clear output labesl
        lblAdditionalPanels.Text = String.Empty
        lblBaseCharge.Text = String.Empty
        lblDepositAmount.Text = String.Empty
        lblRefundDue.Text = String.Empty
        lblTotalCost.Text = String.Empty
    End Sub
    Private Sub ChargesToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuInstallationCharges.Click
        grpOut.Visible = True
        'variable declaration
        Dim strFirst As String = txtFirst.Text
        Dim strLast As String = txtLast.Text
        Dim strPhone As String = txtPhone.Text
        Dim intPanels As Integer
        Dim decDeposit As Decimal
        Dim boolExpressInstall As Boolean
        Dim intAddPanels As Integer
        Dim decTotal As Decimal
        Dim decExpressAmount As Decimal
        'if valid
        If ValidateInputs(strFirst, strLast, strPhone, intPanels, decDeposit, boolExpressInstall) Then
            'set total
            decTotal = CalculateValues(intPanels, decDeposit, decTotal, intAddPanels)
            'display total
            lblTotalCost.Text = decTotal.ToString("C")
            'set additional panels
            intAddPanels = intPanels - 2
            'display charge for additional panels
            lblAdditionalPanels.Text = ((intAddPanels) * 300).ToString("C")
            'display 2000 as dispaly charge
            lblBaseCharge.Text = (2000.ToString("C"))
            'display deposit 
            lblDepositAmount.Text = decDeposit.ToString("C")
            'if deposit is more than total show refund due and diplay total - deposit
            If decDeposit > decTotal Then
                lblDue.Text = "Refund Due:"
                lblRefundDue.Text = (decTotal - decDeposit).ToString("C")
            Else
                'else show balance due and display total - deposit
                lblDue.Text = "Balance Due:"
                lblRefundDue.Text = (decTotal - decDeposit).ToString("C")
            End If
        End If
    End Sub
    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        'closes form
        Me.Close()
    End Sub
    Private Sub ClearToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuFileClear.Click
        'clearslots of stuff
        'clear text boxes
        txtDeposit.Clear()
        txtFirst.Clear()
        txtLast.Clear()
        txtPanels.Clear()
        txtPhone.Clear()
        'clear output labesl
        lblAdditionalPanels.Text = String.Empty
        lblBaseCharge.Text = String.Empty
        lblDepositAmount.Text = String.Empty
        lblRefundDue.Text = String.Empty
        lblTotalCost.Text = String.Empty
    End Sub
    Private Sub OptionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles mnuInstallationOptions.Click
        grpInstallation.Visible = True
        mnuInstallationOptions.Enabled = True
        mnuInstalltionErrors.Enabled = True
    End Sub
    Private Sub mnuInstalltionErrors_Click(sender As Object, e As EventArgs) Handles mnuInstalltionErrors.Click

        Try
            If IsNumeric(txtDeposit.Text) Then
                If txtDeposit.Text.Length > 0 Then
                    If txtFirst.Text.Length > 0 Then
                        If txtLast.Text.Length > 0 Then
                            If txtPanels.Text.Length > 0 And CInt(txtPanels.Text) < 1000 And IsNumeric(txtPanels.Text) Then
                                If txtPhone.Text.Length > 0 Then
                                    MessageBox.Show("is good")
                                    mnuInstallationCharges.Enabled = True
                                Else
                                    MessageBox.Show("error")
                                End If
                            Else
                                MessageBox.Show("error")
                            End If
                        Else
                            MessageBox.Show("error")
                        End If
                    Else
                        MessageBox.Show("error")
                    End If
                Else
                    MessageBox.Show("error")
                End If
            Else
                MessageBox.Show("error")
            End If
        Catch ex As Exception
            MessageBox.Show("error")
        End Try
    End Sub
End Class
