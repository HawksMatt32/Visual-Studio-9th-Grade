﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtFirst = New System.Windows.Forms.TextBox()
        Me.txtLast = New System.Windows.Forms.TextBox()
        Me.txtPhone = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.grpInstallation = New System.Windows.Forms.GroupBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtPanels = New System.Windows.Forms.TextBox()
        Me.txtDeposit = New System.Windows.Forms.TextBox()
        Me.chkExpress = New System.Windows.Forms.CheckBox()
        Me.grpOut = New System.Windows.Forms.GroupBox()
        Me.lblBaseCharge = New System.Windows.Forms.Label()
        Me.lblAdditionalPanels = New System.Windows.Forms.Label()
        Me.lblTotalCost = New System.Windows.Forms.Label()
        Me.lblDepositAmount = New System.Windows.Forms.Label()
        Me.lblRefundDue = New System.Windows.Forms.Label()
        Me.lblDue = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.mnuFile = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCustomer = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuInstallation = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileClear = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuCustomerInfo = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuInstallationOptions = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuInstalltionErrors = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuInstallationCharges = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuHelpHelp = New System.Windows.Forms.ToolStripMenuItem()
        Me.GroupBox1.SuspendLayout()
        Me.grpInstallation.SuspendLayout()
        Me.grpOut.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtFirst)
        Me.GroupBox1.Controls.Add(Me.txtLast)
        Me.GroupBox1.Controls.Add(Me.txtPhone)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 22)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(184, 85)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customer Information"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 19)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "First Name:"
        '
        'txtFirst
        '
        Me.txtFirst.Location = New System.Drawing.Point(70, 16)
        Me.txtFirst.Name = "txtFirst"
        Me.txtFirst.Size = New System.Drawing.Size(100, 20)
        Me.txtFirst.TabIndex = 5
        Me.txtFirst.Text = "joe"
        '
        'txtLast
        '
        Me.txtLast.Location = New System.Drawing.Point(70, 36)
        Me.txtLast.Name = "txtLast"
        Me.txtLast.Size = New System.Drawing.Size(100, 20)
        Me.txtLast.TabIndex = 4
        Me.txtLast.Text = "moe"
        '
        'txtPhone
        '
        Me.txtPhone.Location = New System.Drawing.Point(70, 56)
        Me.txtPhone.Name = "txtPhone"
        Me.txtPhone.Size = New System.Drawing.Size(100, 20)
        Me.txtPhone.TabIndex = 3
        Me.txtPhone.Text = "3165550000"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(61, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Last Name:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(26, 59)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "Phone:"
        '
        'grpInstallation
        '
        Me.grpInstallation.Controls.Add(Me.Label4)
        Me.grpInstallation.Controls.Add(Me.Label5)
        Me.grpInstallation.Controls.Add(Me.Label6)
        Me.grpInstallation.Controls.Add(Me.txtPanels)
        Me.grpInstallation.Controls.Add(Me.txtDeposit)
        Me.grpInstallation.Controls.Add(Me.chkExpress)
        Me.grpInstallation.Location = New System.Drawing.Point(211, 22)
        Me.grpInstallation.Name = "grpInstallation"
        Me.grpInstallation.Size = New System.Drawing.Size(184, 85)
        Me.grpInstallation.TabIndex = 0
        Me.grpInstallation.TabStop = False
        Me.grpInstallation.Text = "Installation Options"
        Me.grpInstallation.Visible = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 65)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(0, 13)
        Me.Label4.TabIndex = 1
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(6, 45)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(46, 13)
        Me.Label5.TabIndex = 2
        Me.Label5.Text = "Deposit:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 25)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "# of Panels:"
        '
        'txtPanels
        '
        Me.txtPanels.Location = New System.Drawing.Point(71, 22)
        Me.txtPanels.Name = "txtPanels"
        Me.txtPanels.Size = New System.Drawing.Size(100, 20)
        Me.txtPanels.TabIndex = 6
        '
        'txtDeposit
        '
        Me.txtDeposit.Location = New System.Drawing.Point(71, 42)
        Me.txtDeposit.Name = "txtDeposit"
        Me.txtDeposit.Size = New System.Drawing.Size(100, 20)
        Me.txtDeposit.TabIndex = 7
        '
        'chkExpress
        '
        Me.chkExpress.Checked = True
        Me.chkExpress.CheckState = System.Windows.Forms.CheckState.Checked
        Me.chkExpress.Location = New System.Drawing.Point(71, 61)
        Me.chkExpress.Name = "chkExpress"
        Me.chkExpress.Size = New System.Drawing.Size(104, 17)
        Me.chkExpress.TabIndex = 8
        Me.chkExpress.Text = "Express Installation"
        Me.chkExpress.UseVisualStyleBackColor = True
        '
        'grpOut
        '
        Me.grpOut.Controls.Add(Me.lblBaseCharge)
        Me.grpOut.Controls.Add(Me.lblAdditionalPanels)
        Me.grpOut.Controls.Add(Me.lblTotalCost)
        Me.grpOut.Controls.Add(Me.lblDepositAmount)
        Me.grpOut.Controls.Add(Me.lblRefundDue)
        Me.grpOut.Controls.Add(Me.lblDue)
        Me.grpOut.Controls.Add(Me.Label10)
        Me.grpOut.Controls.Add(Me.Label9)
        Me.grpOut.Controls.Add(Me.Label8)
        Me.grpOut.Controls.Add(Me.Label7)
        Me.grpOut.Location = New System.Drawing.Point(12, 149)
        Me.grpOut.Name = "grpOut"
        Me.grpOut.Size = New System.Drawing.Size(383, 170)
        Me.grpOut.TabIndex = 3
        Me.grpOut.TabStop = False
        Me.grpOut.Text = "Charges For"
        '
        'lblBaseCharge
        '
        Me.lblBaseCharge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblBaseCharge.Location = New System.Drawing.Point(139, 15)
        Me.lblBaseCharge.Name = "lblBaseCharge"
        Me.lblBaseCharge.Size = New System.Drawing.Size(89, 23)
        Me.lblBaseCharge.TabIndex = 12
        '
        'lblAdditionalPanels
        '
        Me.lblAdditionalPanels.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblAdditionalPanels.Location = New System.Drawing.Point(139, 39)
        Me.lblAdditionalPanels.Name = "lblAdditionalPanels"
        Me.lblAdditionalPanels.Size = New System.Drawing.Size(89, 23)
        Me.lblAdditionalPanels.TabIndex = 11
        '
        'lblTotalCost
        '
        Me.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotalCost.Location = New System.Drawing.Point(139, 62)
        Me.lblTotalCost.Name = "lblTotalCost"
        Me.lblTotalCost.Size = New System.Drawing.Size(89, 23)
        Me.lblTotalCost.TabIndex = 10
        '
        'lblDepositAmount
        '
        Me.lblDepositAmount.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblDepositAmount.Location = New System.Drawing.Point(139, 86)
        Me.lblDepositAmount.Name = "lblDepositAmount"
        Me.lblDepositAmount.Size = New System.Drawing.Size(89, 23)
        Me.lblDepositAmount.TabIndex = 9
        '
        'lblRefundDue
        '
        Me.lblRefundDue.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblRefundDue.Location = New System.Drawing.Point(139, 110)
        Me.lblRefundDue.Name = "lblRefundDue"
        Me.lblRefundDue.Size = New System.Drawing.Size(89, 23)
        Me.lblRefundDue.TabIndex = 8
        '
        'lblDue
        '
        Me.lblDue.AutoSize = True
        Me.lblDue.Location = New System.Drawing.Point(61, 113)
        Me.lblDue.Name = "lblDue"
        Me.lblDue.Size = New System.Drawing.Size(68, 13)
        Me.lblDue.TabIndex = 7
        Me.lblDue.Text = "Refund Due:"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(75, 63)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(58, 13)
        Me.Label10.TabIndex = 6
        Me.Label10.Text = "Total Cost:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(48, 88)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(85, 13)
        Me.Label9.TabIndex = 5
        Me.Label9.Text = "Deposit Amount:"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(42, 41)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(91, 13)
        Me.Label8.TabIndex = 4
        Me.Label8.Text = "Additional Panels:"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(3, 16)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(130, 13)
        Me.Label7.TabIndex = 3
        Me.Label7.Text = "Base Charge for 2 Panels:"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(429, 108)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(138, 13)
        Me.Label11.TabIndex = 4
        Me.Label11.Text = "yoooooo top secret mesage"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFile, Me.mnuCustomer, Me.mnuInstallation, Me.mnuHelp})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(401, 24)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'mnuFile
        '
        Me.mnuFile.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileClear, Me.mnuFileExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Size = New System.Drawing.Size(37, 20)
        Me.mnuFile.Text = "&File"
        '
        'mnuCustomer
        '
        Me.mnuCustomer.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuCustomerInfo})
        Me.mnuCustomer.Name = "mnuCustomer"
        Me.mnuCustomer.Size = New System.Drawing.Size(71, 20)
        Me.mnuCustomer.Text = "Cu&stomer"
        '
        'mnuInstallation
        '
        Me.mnuInstallation.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuInstallationOptions, Me.mnuInstalltionErrors, Me.mnuInstallationCharges})
        Me.mnuInstallation.Name = "mnuInstallation"
        Me.mnuInstallation.Size = New System.Drawing.Size(77, 20)
        Me.mnuInstallation.Text = "I&nstallation"
        '
        'mnuHelp
        '
        Me.mnuHelp.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuHelpHelp})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Size = New System.Drawing.Size(44, 20)
        Me.mnuHelp.Text = "&Help"
        '
        'mnuFileClear
        '
        Me.mnuFileClear.Name = "mnuFileClear"
        Me.mnuFileClear.Size = New System.Drawing.Size(152, 22)
        Me.mnuFileClear.Text = "Clear"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(152, 22)
        Me.mnuFileExit.Text = "Exit"
        '
        'mnuCustomerInfo
        '
        Me.mnuCustomerInfo.Name = "mnuCustomerInfo"
        Me.mnuCustomerInfo.Size = New System.Drawing.Size(152, 22)
        Me.mnuCustomerInfo.Text = "In&formation"
        '
        'mnuInstallationOptions
        '
        Me.mnuInstallationOptions.Name = "mnuInstallationOptions"
        Me.mnuInstallationOptions.Size = New System.Drawing.Size(152, 22)
        Me.mnuInstallationOptions.Text = "Options"
        '
        'mnuInstalltionErrors
        '
        Me.mnuInstalltionErrors.Enabled = False
        Me.mnuInstalltionErrors.Name = "mnuInstalltionErrors"
        Me.mnuInstalltionErrors.Size = New System.Drawing.Size(152, 22)
        Me.mnuInstalltionErrors.Text = "Errors"
        '
        'mnuInstallationCharges
        '
        Me.mnuInstallationCharges.Enabled = False
        Me.mnuInstallationCharges.Name = "mnuInstallationCharges"
        Me.mnuInstallationCharges.Size = New System.Drawing.Size(152, 22)
        Me.mnuInstallationCharges.Text = "Charges"
        '
        'mnuHelpHelp
        '
        Me.mnuHelpHelp.Name = "mnuHelpHelp"
        Me.mnuHelpHelp.Size = New System.Drawing.Size(152, 22)
        Me.mnuHelpHelp.Text = "Help"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(401, 340)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.grpOut)
        Me.Controls.Add(Me.grpInstallation)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Name = "Form1"
        Me.Text = "roof install"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.grpInstallation.ResumeLayout(False)
        Me.grpInstallation.PerformLayout()
        Me.grpOut.ResumeLayout(False)
        Me.grpOut.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtFirst As TextBox
    Friend WithEvents txtLast As TextBox
    Friend WithEvents txtPhone As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents grpInstallation As GroupBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents txtPanels As TextBox
    Friend WithEvents txtDeposit As TextBox
    Friend WithEvents chkExpress As CheckBox
    Friend WithEvents grpOut As GroupBox
    Friend WithEvents lblBaseCharge As Label
    Friend WithEvents lblAdditionalPanels As Label
    Friend WithEvents lblTotalCost As Label
    Friend WithEvents lblDepositAmount As Label
    Friend WithEvents lblRefundDue As Label
    Friend WithEvents lblDue As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents mnuFile As ToolStripMenuItem
    Friend WithEvents mnuFileClear As ToolStripMenuItem
    Friend WithEvents mnuFileExit As ToolStripMenuItem
    Friend WithEvents mnuCustomer As ToolStripMenuItem
    Friend WithEvents mnuCustomerInfo As ToolStripMenuItem
    Friend WithEvents mnuInstallation As ToolStripMenuItem
    Friend WithEvents mnuInstallationOptions As ToolStripMenuItem
    Friend WithEvents mnuInstalltionErrors As ToolStripMenuItem
    Friend WithEvents mnuInstallationCharges As ToolStripMenuItem
    Friend WithEvents mnuHelp As ToolStripMenuItem
    Friend WithEvents mnuHelpHelp As ToolStripMenuItem
End Class
