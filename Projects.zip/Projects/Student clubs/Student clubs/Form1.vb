﻿Public Class Form1
    'global variable decl
    'counter for max removal
    Dim intCounter As Integer = 0
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        'var declare use this
        Dim strAdd As String
        'built in error handling
        If lstGeneral.SelectedIndex = -1 Or lstGeneral.SelectedIndex > 9 Then
            MessageBox.Show("Please select a box with a name in it")
        Else
            'saves selected box and adds to listbox counter
            If lstGeneral.SelectedIndex = 0 Then
                strAdd = CStr(lstGeneral.Items(0))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 1 Then
                strAdd = CStr(lstGeneral.Items(1))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 2 Then
                strAdd = CStr(lstGeneral.Items(2))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 3 Then
                strAdd = CStr(lstGeneral.Items(3))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 4 Then
                strAdd = CStr(lstGeneral.Items(4))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 5 Then
                strAdd = CStr(lstGeneral.Items(5))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 6 Then
                strAdd = CStr(lstGeneral.Items(6))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 7 Then
                strAdd = CStr(lstGeneral.Items(7))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 8 Then
                strAdd = CStr(lstGeneral.Items(8))
                intCounter += 1
            End If
            If lstGeneral.SelectedIndex = 9 Then
                strAdd = CStr(lstGeneral.Items(9))
                intCounter += 1
            End If

            'output to other listbox

            lstClub.Items.Add(strAdd)
            If intCounter = 1 Then
                lblOut.Text = CStr(intCounter) + " Total Student"
            Else
                lblOut.Text = CStr(intCounter) + " Total Students"
            End If

        End If




    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        'clears variables and counter
        intCounter = 0
        lstClub.ClearSelected()
        lstGeneral.ClearSelected()
        lstClub.Items.Clear()
        lblOut.Text = "Cleared Counter"

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        'removes selected item
        lstClub.Items.Remove(lstClub.SelectedItem)
        'lower counter
        intCounter -= 1
        'display counter
        If intCounter = 1 Then
            lblOut.Text = CStr(intCounter) + " Total Student"
        ElseIf intCounter = 0 Then
            lblOut.Text = "No Students Signed Up"
        Else
            lblOut.Text = CStr(intCounter) + " Total Students"
        End If
    End Sub
End Class
