﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstClub = New System.Windows.Forms.ListBox()
        Me.lstGeneral = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.btnAdd = New System.Windows.Forms.Button()
        Me.lblOut = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lstClub
        '
        Me.lstClub.FormattingEnabled = True
        Me.lstClub.Location = New System.Drawing.Point(147, 40)
        Me.lstClub.Name = "lstClub"
        Me.lstClub.Size = New System.Drawing.Size(120, 134)
        Me.lstClub.TabIndex = 0
        '
        'lstGeneral
        '
        Me.lstGeneral.FormattingEnabled = True
        Me.lstGeneral.Items.AddRange(New Object() {"Uchiha, Sasuke", "Uchiha, Itachi", "Uchiha, Madara", "Uchiha, Obito", "Hatake, Kakashi", "Uzumaki, Naruto", "Uzumaki, Hinata", "Uzumaki, Boruto", "Senju, Hashirmama", "Senju, Tobirama"})
        Me.lstGeneral.Location = New System.Drawing.Point(12, 40)
        Me.lstGeneral.Name = "lstGeneral"
        Me.lstGeneral.Size = New System.Drawing.Size(120, 134)
        Me.lstGeneral.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(9, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(130, 13)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Choose students to move."
        '
        'btnRemove
        '
        Me.btnRemove.Location = New System.Drawing.Point(176, 190)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(75, 51)
        Me.btnRemove.TabIndex = 4
        Me.btnRemove.Text = "Remove Selected Student"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(297, 52)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 45)
        Me.Button2.TabIndex = 5
        Me.Button2.Text = "Get OUT"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(297, 165)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 45)
        Me.Button3.TabIndex = 6
        Me.Button3.Text = "CLEAR OUT"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'btnAdd
        '
        Me.btnAdd.Location = New System.Drawing.Point(31, 190)
        Me.btnAdd.Name = "btnAdd"
        Me.btnAdd.Size = New System.Drawing.Size(75, 51)
        Me.btnAdd.TabIndex = 7
        Me.btnAdd.Text = "Add Selected Student"
        Me.btnAdd.UseVisualStyleBackColor = True
        '
        'lblOut
        '
        Me.lblOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOut.Location = New System.Drawing.Point(224, 9)
        Me.lblOut.Name = "lblOut"
        Me.lblOut.Size = New System.Drawing.Size(124, 23)
        Me.lblOut.TabIndex = 8
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(184, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(34, 13)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Total:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(398, 263)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lblOut)
        Me.Controls.Add(Me.btnAdd)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstGeneral)
        Me.Controls.Add(Me.lstClub)
        Me.Name = "Form1"
        Me.Text = "Club Manager"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lstClub As ListBox
    Friend WithEvents lstGeneral As ListBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnRemove As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents Button3 As Button
    Friend WithEvents btnAdd As Button
    Friend WithEvents lblOut As Label
    Friend WithEvents Label3 As Label
End Class
