﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.cmbGrowth = New System.Windows.Forms.ComboBox()
        Me.txtIn = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.cmbDays = New System.Windows.Forms.ComboBox()
        Me.lstOut = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(11, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(175, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Average population growth per day:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(68, 31)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(118, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Starting # of organisms:"
        '
        'cmbGrowth
        '
        Me.cmbGrowth.FormattingEnabled = True
        Me.cmbGrowth.Items.AddRange(New Object() {"02.5%", "05%", "07.5%", "10%", "12.5%", "15%", "17.5%", "20%"})
        Me.cmbGrowth.Location = New System.Drawing.Point(192, 5)
        Me.cmbGrowth.Name = "cmbGrowth"
        Me.cmbGrowth.Size = New System.Drawing.Size(121, 21)
        Me.cmbGrowth.TabIndex = 2
        '
        'txtIn
        '
        Me.txtIn.Location = New System.Drawing.Point(192, 31)
        Me.txtIn.Name = "txtIn"
        Me.txtIn.Size = New System.Drawing.Size(100, 20)
        Me.txtIn.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(72, 60)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(114, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Days of growth (Days):"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(209, 85)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 41)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "GET OUT"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(43, 85)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 41)
        Me.Button2.TabIndex = 7
        Me.Button2.Text = "Start epic population simulation"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'cmbDays
        '
        Me.cmbDays.FormattingEnabled = True
        Me.cmbDays.Items.AddRange(New Object() {"5", "10", "15", "20", "25", "50", "75", "100", "150", "200", "250", "300", "350", "400", "450", "500", "600", "700", "800", "900", "1000"})
        Me.cmbDays.Location = New System.Drawing.Point(192, 57)
        Me.cmbDays.Name = "cmbDays"
        Me.cmbDays.Size = New System.Drawing.Size(121, 21)
        Me.cmbDays.TabIndex = 8
        '
        'lstOut
        '
        Me.lstOut.FormattingEnabled = True
        Me.lstOut.Items.AddRange(New Object() {"Day " & Global.Microsoft.VisualBasic.ChrW(9) & "Aprox. Population", "---------------------------------------------------------------------------------" &
                "--------------------------------------------------------------------"})
        Me.lstOut.Location = New System.Drawing.Point(43, 132)
        Me.lstOut.Name = "lstOut"
        Me.lstOut.Size = New System.Drawing.Size(241, 238)
        Me.lstOut.TabIndex = 9
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(321, 401)
        Me.Controls.Add(Me.lstOut)
        Me.Controls.Add(Me.cmbDays)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtIn)
        Me.Controls.Add(Me.cmbGrowth)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Population Sim"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents cmbGrowth As ComboBox
    Friend WithEvents txtIn As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Button1 As Button
    Friend WithEvents Button2 As Button
    Friend WithEvents cmbDays As ComboBox
    Friend WithEvents lstOut As ListBox
End Class
