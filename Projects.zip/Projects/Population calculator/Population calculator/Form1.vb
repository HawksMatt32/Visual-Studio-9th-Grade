﻿Public Class Form1
    Dim dblorganisms As Double
    Dim intCounter As Integer
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Try
            'format growth input as percent
            Dim dblGrowthSelected As Double = CDbl("0." + (cmbGrowth.Text.Replace("%", "").Replace(".", "")))
            'variable declaration
            dblorganisms = CDbl(txtIn.Text)
            'loop until counter = done
            Do Until intCounter = CInt(cmbDays.SelectedItem)
                'add to counter
                intCounter += 1
                'output counter + orgamisms
                lstOut.Items.Add(CStr(intCounter) + "                       " + CStr(dblorganisms))
                'set organisms as its self but add a percentage 
                dblorganisms = dblorganisms + dblorganisms * dblGrowthSelected
            Loop
        Catch ex As Exception
            MessageBox.Show("error use numbers")
        End Try

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        'closes form
        Me.Close()

    End Sub

    Private Sub cmbGrowth_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cmbGrowth.SelectedIndexChanged

    End Sub
End Class
