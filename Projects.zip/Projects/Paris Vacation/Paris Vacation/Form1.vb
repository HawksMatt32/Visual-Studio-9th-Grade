﻿Public Class Form1
    Private Sub btnShow_Click(sender As Object, e As EventArgs) Handles btnShow.Click
        'variable declaration
        Dim strNeighborhoods As String = String.Empty
        'if something in output add comma then output
        If chkChamps.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Champs-Élysées"
            Else                                                'champs
                'output selected
                lblOut.Text += ", Champs-Élysées"
            End If
        End If
        'id something in output add comma then output
        If chkSacre.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Sacre-Coeur"
            Else                                                'sacre
                'output selected
                lblOut.Text += ", Sacre-Coeur"
            End If
        End If
        'if something in output add comma then output
        If chkMarais.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Marais"
            Else                                                 'marais
                'output selected
                lblOut.Text += ", Marais"
            End If
        End If
        'u know what this does
        If chkLatin.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Latin Quarter"
            Else                                                  'latin
                lblOut.Text += ", Latin Quarter"
            End If
        End If

        If chkLes.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Les Halles"
            Else                                                  'les
                lblOut.Text += ", Les Halles"
            End If
        End If
        'type of residency output
        'same system as before tho
        If chk1.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "1-Bed Apartment"
            Else                                                  '1 bed
                lblOut.Text += ", 1-Bed Apartment"
            End If
        End If

        If chk2.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "2-Bed Apartment"
            Else                                                    '2 bed
                lblOut.Text += ", "
            End If
        End If

        If chkStudio.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Studio Apartment"
            Else                                                        'studio
                lblOut.Text += ", Studio Apartment"
            End If
        End If

        If chkLarge.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Large Hotel"
            Else                                                            'large
                lblOut.Text += ", Large Hotel"
            End If
        End If

        If chkBoutique.Checked = True Then
            If CStr(lblOut.Text) = CStr("") Then
                lblOut.Text = "Boutique Hotel"
            Else                                                            'boutique
                lblOut.Text += ", Boutique Hotel"
            End If
        End If


    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub
End Class
