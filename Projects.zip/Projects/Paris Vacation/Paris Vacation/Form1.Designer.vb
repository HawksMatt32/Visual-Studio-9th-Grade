﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.chkLes = New System.Windows.Forms.CheckBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.chkMarais = New System.Windows.Forms.CheckBox()
        Me.chkLatin = New System.Windows.Forms.CheckBox()
        Me.chkChamps = New System.Windows.Forms.CheckBox()
        Me.chkSacre = New System.Windows.Forms.CheckBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.chkBoutique = New System.Windows.Forms.CheckBox()
        Me.chk1 = New System.Windows.Forms.CheckBox()
        Me.chkStudio = New System.Windows.Forms.CheckBox()
        Me.chk2 = New System.Windows.Forms.CheckBox()
        Me.chkLarge = New System.Windows.Forms.CheckBox()
        Me.btnShow = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.lblOut = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'chkLes
        '
        Me.chkLes.AutoSize = True
        Me.chkLes.Location = New System.Drawing.Point(6, 19)
        Me.chkLes.Name = "chkLes"
        Me.chkLes.Size = New System.Drawing.Size(75, 17)
        Me.chkLes.TabIndex = 0
        Me.chkLes.Text = "Les Halles"
        Me.chkLes.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.chkSacre)
        Me.GroupBox1.Controls.Add(Me.chkChamps)
        Me.GroupBox1.Controls.Add(Me.chkLatin)
        Me.GroupBox1.Controls.Add(Me.chkMarais)
        Me.GroupBox1.Controls.Add(Me.chkLes)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(168, 154)
        Me.GroupBox1.TabIndex = 1
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Where are you interested in?"
        '
        'chkMarais
        '
        Me.chkMarais.AutoSize = True
        Me.chkMarais.Location = New System.Drawing.Point(6, 135)
        Me.chkMarais.Name = "chkMarais"
        Me.chkMarais.Size = New System.Drawing.Size(57, 17)
        Me.chkMarais.TabIndex = 1
        Me.chkMarais.Text = "Marais"
        Me.chkMarais.UseVisualStyleBackColor = True
        '
        'chkLatin
        '
        Me.chkLatin.AutoSize = True
        Me.chkLatin.Location = New System.Drawing.Point(6, 106)
        Me.chkLatin.Name = "chkLatin"
        Me.chkLatin.Size = New System.Drawing.Size(87, 17)
        Me.chkLatin.TabIndex = 2
        Me.chkLatin.Text = "Latin Quarter"
        Me.chkLatin.UseVisualStyleBackColor = True
        '
        'chkChamps
        '
        Me.chkChamps.AutoSize = True
        Me.chkChamps.Location = New System.Drawing.Point(6, 77)
        Me.chkChamps.Name = "chkChamps"
        Me.chkChamps.Size = New System.Drawing.Size(103, 17)
        Me.chkChamps.TabIndex = 3
        Me.chkChamps.Text = "Champs-Élysées"
        Me.chkChamps.UseVisualStyleBackColor = True
        '
        'chkSacre
        '
        Me.chkSacre.AutoSize = True
        Me.chkSacre.Location = New System.Drawing.Point(6, 48)
        Me.chkSacre.Name = "chkSacre"
        Me.chkSacre.Size = New System.Drawing.Size(85, 17)
        Me.chkSacre.TabIndex = 4
        Me.chkSacre.Text = "Sacre-Coeur"
        Me.chkSacre.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.chkLarge)
        Me.GroupBox2.Controls.Add(Me.chk2)
        Me.GroupBox2.Controls.Add(Me.chkStudio)
        Me.GroupBox2.Controls.Add(Me.chk1)
        Me.GroupBox2.Controls.Add(Me.chkBoutique)
        Me.GroupBox2.Location = New System.Drawing.Point(186, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(168, 154)
        Me.GroupBox2.TabIndex = 5
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "What Type of Residency?"
        '
        'chkBoutique
        '
        Me.chkBoutique.AutoSize = True
        Me.chkBoutique.Location = New System.Drawing.Point(6, 23)
        Me.chkBoutique.Name = "chkBoutique"
        Me.chkBoutique.Size = New System.Drawing.Size(96, 17)
        Me.chkBoutique.TabIndex = 6
        Me.chkBoutique.Text = "Boutique Hotel"
        Me.chkBoutique.UseVisualStyleBackColor = True
        '
        'chk1
        '
        Me.chk1.AutoSize = True
        Me.chk1.Location = New System.Drawing.Point(6, 131)
        Me.chk1.Name = "chk1"
        Me.chk1.Size = New System.Drawing.Size(105, 17)
        Me.chk1.TabIndex = 7
        Me.chk1.Text = "1-Bed Apartment"
        Me.chk1.UseVisualStyleBackColor = True
        '
        'chkStudio
        '
        Me.chkStudio.AutoSize = True
        Me.chkStudio.Location = New System.Drawing.Point(6, 77)
        Me.chkStudio.Name = "chkStudio"
        Me.chkStudio.Size = New System.Drawing.Size(56, 17)
        Me.chkStudio.TabIndex = 8
        Me.chkStudio.Text = "Studio"
        Me.chkStudio.UseVisualStyleBackColor = True
        '
        'chk2
        '
        Me.chk2.AutoSize = True
        Me.chk2.Location = New System.Drawing.Point(6, 104)
        Me.chk2.Name = "chk2"
        Me.chk2.Size = New System.Drawing.Size(105, 17)
        Me.chk2.TabIndex = 9
        Me.chk2.Text = "2-Bed Apartment"
        Me.chk2.UseVisualStyleBackColor = True
        '
        'chkLarge
        '
        Me.chkLarge.AutoSize = True
        Me.chkLarge.Location = New System.Drawing.Point(6, 50)
        Me.chkLarge.Name = "chkLarge"
        Me.chkLarge.Size = New System.Drawing.Size(81, 17)
        Me.chkLarge.TabIndex = 10
        Me.chkLarge.Text = "Large Hotel"
        Me.chkLarge.UseVisualStyleBackColor = True
        '
        'btnShow
        '
        Me.btnShow.Location = New System.Drawing.Point(12, 170)
        Me.btnShow.Name = "btnShow"
        Me.btnShow.Size = New System.Drawing.Size(168, 48)
        Me.btnShow.TabIndex = 11
        Me.btnShow.Text = "Show"
        Me.btnShow.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(186, 170)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(168, 48)
        Me.btnExit.TabIndex = 12
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'lblOut
        '
        Me.lblOut.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOut.Location = New System.Drawing.Point(12, 233)
        Me.lblOut.Name = "lblOut"
        Me.lblOut.Size = New System.Drawing.Size(342, 48)
        Me.lblOut.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 220)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(90, 13)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Searching Criteria"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(394, 309)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblOut)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnShow)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "France Vacation"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents chkLes As CheckBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents chkSacre As CheckBox
    Friend WithEvents chkChamps As CheckBox
    Friend WithEvents chkLatin As CheckBox
    Friend WithEvents chkMarais As CheckBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents chkLarge As CheckBox
    Friend WithEvents chk2 As CheckBox
    Friend WithEvents chkStudio As CheckBox
    Friend WithEvents chk1 As CheckBox
    Friend WithEvents chkBoutique As CheckBox
    Friend WithEvents btnShow As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents lblOut As Label
    Friend WithEvents Label1 As Label
End Class
