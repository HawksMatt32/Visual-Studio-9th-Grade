﻿Public Class form1
    Function validateinputs(ByRef decDays As Decimal, ByRef decMeds As Decimal, ByRef decSurgery As Decimal, ByRef decLab As Decimal, ByRef decRehab As Decimal) As Boolean
        If Decimal.TryParse(txtDays.Text, decDays) Then
            If Decimal.TryParse(txtMeds.Text, decMeds) Then
                If Decimal.TryParse(txtSurgery.Text, decSurgery) Then
                    If Decimal.TryParse(txtLab.Text, decLab) Then
                        If Decimal.TryParse(txtRehab.Text, decRehab) Then
                            Return True
                        Else
                            lblTotal.Text = "please enter a valid number for rehab"
                            txtRehab.Clear()
                            txtRehab.Focus()
                            Return False
                        End If
                    Else
                        lblTotal.Text = "please enter a valid number for lab"
                        txtLab.Clear()
                        txtLab.Focus()
                        Return False
                    End If
                Else
                    lblTotal.Text = "please enter a valid number for surgery"
                    txtSurgery.Clear()
                    txtSurgery.Focus()
                    Return False
                End If
            Else
                lblTotal.Text = "please enter a valid number for meds"
                txtMeds.Clear()
                txtMeds.Focus()
                Return False
            End If
        Else
            lblTotal.Text = "please enter a valid number for days"
            txtDays.Clear()
            txtDays.Focus()
            Return False
        End If
    End Function

    Function calctotalcharges(decStay As Decimal, decMisc As Decimal) As Decimal
        Return decStay + decMisc
    End Function
    Private Sub txtmeds_textchanged(sender As Object, e As EventArgs) Handles txtDays.TextChanged
    End Sub
    Private Sub btncalculate_click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Dim decDays, decMeds, decSurgery, decLab, decRehab As Decimal
        Dim decTotal, decStay, decMisc As Decimal
        'call validateinputs() to validate all inputs as decimal value
        If validateinputs(decDays, decMeds, decSurgery, decLab, decRehab) Then
            decStay = calcstaycharges(decDays)
            decMisc = calcmisccharges(decMeds, decSurgery, decLab, decRehab)
            decTotal = calctotalcharges(decStay, decMisc)
            lblTotal.Text = calctotalcharges(decStay, decMisc).ToString("C")
        End If
    End Sub
    Function calcmisccharges(decMeds As Decimal, decSurgery As Decimal, decLab As Decimal, decRehab As Decimal) As Decimal
        Dim decTotalMisc As Decimal = decMeds + decSurgery + decLab + decRehab
        Return decTotalMisc
    End Function
    Function calcstaycharges(decDays As Decimal) As Decimal
        'recieves 1 arg 
        'calcs,returns stay amount
        Const dec_DAILY_CHARGE = 350D
        Dim decDaysTotal As Decimal
        decDaysTotal = decDays * dec_DAILY_CHARGE
        Return decDaysTotal
    End Function
    Sub clearall()

    End Sub

    Private Sub btnclear_click(sender As Object, e As EventArgs) Handles btnClear.Click
        'clears all using procedure
        clearall()
    End Sub

    Private Sub btnexit_click(sender As Object, e As EventArgs) Handles btnExit.Click
        'closes form
        Me.Close()

    End Sub
End Class