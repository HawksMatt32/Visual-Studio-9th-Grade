﻿Public Class Form1
    Private Sub btnChange_Click(sender As Object, e As EventArgs) Handles btnChange.Click
        'replaces comma with space
        Dim intBigNumber As String = txtIn.Text
        intBigNumber = intBigNumber.Replace(",", "")
        lblOut.Text = CStr(intBigNumber)
    End Sub

    Private Sub btnOut_Click(sender As Object, e As EventArgs)
        'closes form
        Me.Close()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

    End Sub
End Class
